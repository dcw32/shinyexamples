import polars as pl
import pytest

from raw2ufs.formula import FormulaError, compile_formula, parse, to_polars_source
from raw2ufs.formula.ast import columns_used

DF = pl.DataFrame({
    "A": [1, 5, None], "B": [3, 2, 1], "TIV": [2e6, 5e5, 1e3],
    "Country": ["SE", "NO", "FI"], "Occ": [" res ", "com", None],
    "Postcode": ["ABC12", "DEF", "X"], "D": ["2024-01-31", "bad", None],
})


def ev(text):
    return DF.select(compile_formula(text).alias("r"))["r"].to_list()


@pytest.mark.parametrize("text,expected", [
    ("IF [A] > [B] THEN 1 ELSE 0 ENDIF", [0, 1, 0]),
    ("IF [TIV] > 1000000 AND [Country] = 'SE' THEN 'Large' ELSEIF [TIV] > 100000 THEN 'Mid' ELSE 'Small' ENDIF",
     ["Large", "Mid", "Small"]),
    ("Round([A] * 1000, 0) + IfNull([B], 0)", [1003, 5002, None]),
    ("Upper(Trim([Occ]))", ["RES", "COM", None]),
    ("[Country] IN ('SE','NO') AND NOT IsNull([A])", [True, True, False]),
    ("[Country] NOT IN ('SE')", [False, True, True]),
    ("-[A] ^ 2 + 3 * (2 - [B]) % 4", [0, -25, None]),
    ("Concat([Country], '-', [Postcode])", ["SE-ABC12", "NO-DEF", "FI-X"]),
    ("1 + 2", [3]),
    ("Left([Postcode], 3) <> 'ABC'", [False, True, True]),
    ("Right([Postcode], 2) + '!'", ["12!", "EF!", "X!"]),
    ("Contains([Occ], 'o') OR IsEmpty([Occ])", [False, True, True]),
    ("Year(ToDate([D], '%Y-%m-%d'))", [2024, None, None]),
    ("ToNumber(Replace('1 000', ' ', '')) * 2", [2000.0]),
    ("Max([A], [B]) - Min([A], [B])", [2, 3, 0]),   # horizontal min/max ignore nulls
    ("IF IsNull([A]) THEN NULL ELSE [A] / 2 ENDIF", [0.5, 2.5, None]),
    ("Length([Postcode]) >= 3 AND StartsWith([Postcode], 'A')", [True, False, False]),
    ("IIF([A] > 2, 'hi', 'lo')", ["lo", "hi", "lo"]),
    ("Switch([Country], 0, 'SE', 46, 'NO', 47)", [46, 47, 0]),
    ("[a] + 1", None),   # column names are case-sensitive: this must raise at eval time
])
def test_evaluates(text, expected):
    if expected is None:
        with pytest.raises(pl.exceptions.ColumnNotFoundError):
            ev(text)
    else:
        assert ev(text) == expected


def test_source_is_plain_polars():
    src = to_polars_source("IF [A] > [B] THEN 1 ELSE 0 ENDIF")
    assert src == "pl.when((pl.col('A') > pl.col('B'))).then(pl.lit(1)).otherwise(pl.lit(0))"
    assert "pl.lit" not in to_polars_source("Replace([X], ' ', '')").split("replace_all")[1]


def test_columns_used():
    assert columns_used(parse("IF [A] > [B] THEN [A] ELSE Upper([C]) ENDIF")) == ["A", "B", "C"]


@pytest.mark.parametrize("bad", [
    "", "IF [A] THEN 1", "[A] +", "Foo([A])", "Round()", "[A] IN ([B])",
    "1 2", "IF [A] > 1 THEN 1 ELSE 0", "'unterminated", "[A] ?? 1",
])
def test_errors(bad):
    with pytest.raises(FormulaError):
        to_polars_source(bad)


def test_constants():
    assert to_polars_source("[a] * [$Scale]") == "(pl.col('a') * pl.lit(K_Scale))"
    assert DF.select(compile_formula("[A] * [$Scale]", {"Scale": 10}).alias("r"))["r"].to_list() == [10, 50, None]
    with pytest.raises(FormulaError):
        to_polars_source("Switch([A], 1, 2)")


def test_functions_case_insensitive_and_keywords_too():
    assert ev("upper('a')") == ["A"]
    assert ev("if 1 > 0 then 'y' else 'n' endif") == ["y"]
