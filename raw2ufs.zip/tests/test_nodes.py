"""Per-node behaviour tests. Each builds a tiny graph, runs it through the
engine and checks the result; every node therefore also exercises its emitted
code, since that is all the engine executes."""

import polars as pl
import pytest
import shapely

from raw2ufs.engine.graph import Graph
from raw2ufs.engine.registry import NodeConfigError
from raw2ufs.engine.runner import RunError, build_plans, preview, run, schema


@pytest.fixture
def csv(tmp_path):
    def make(name, df, **kw):
        p = tmp_path / name
        df.write_csv(p, **kw)
        return str(p)
    return make


def single(node_type, cfg, src_path, extra_nodes=None):
    """Graph: input(src) -> node -> (no sink). Returns the node's collected frame."""
    g = Graph()
    g.add_node("src", "input", {"path": src_path})
    g.add_node("n", node_type, cfg)
    g.add_edge("src", "n")
    return build_plans(g)["n"].collect()


BASE = pl.DataFrame({
    "id": [1, 2, 3, 4],
    "name": [" Alice ", "bob", "Carol\tX", None],
    "grp": ["a", "a", "b", "b"],
    "val": [10.0, None, 30.0, 40.0],
})


def test_select_rename_cast(csv):
    out = single("select", {"columns": [
        {"name": "id", "rename": "ID", "dtype": "string"},
        {"name": "val", "dtype": "int"},
    ]}, csv("b.csv", BASE))
    assert out.columns == ["ID", "val"]
    assert out["ID"].dtype == pl.String and out["val"].dtype == pl.Int64
    out = single("select", {"columns": [{"name": "id", "rename": "ID"}], "keep_others": True},
                 csv("b2.csv", BASE))
    assert out.columns == ["ID", "name", "grp", "val"]


def test_cleanse(csv):
    out = single("cleanse", {"trim": True, "collapse_whitespace": True, "case": "upper",
                             "null_to_blank": True, "null_to_zero": True}, csv("b.csv", BASE))
    assert out["name"].to_list() == ["ALICE", "BOB", "CAROL X", ""]
    assert out["val"].to_list() == [10.0, 0.0, 30.0, 40.0]
    out = single("cleanse", {"columns": ["name"], "remove_letters": True, "remove_whitespace": True},
                 csv("b3.csv", pl.DataFrame({"name": ["ab 12-c"], "other": ["ab 12"]})))
    assert out.row(0) == ("12-", "ab 12")
    out = single("cleanse", {"drop_null_columns": True, "drop_null_rows": True},
                 csv("b4.csv", pl.DataFrame({"a": [1, None], "b": [None, None]})))
    assert out.columns == ["a"] and out.height == 1


def test_filter_simple_and_formula(csv):
    p = csv("b.csv", BASE)
    out = single("filter", {"conditions": [{"column": "val", "op": ">", "value": "20"},
                                           {"column": "grp", "op": "=", "value": "b"}]}, p)
    assert out["id"].to_list() == [3, 4]
    out = single("filter", {"combine": "or", "conditions": [
        {"column": "id", "op": "in list", "value": "1, 2"}, {"column": "name", "op": "is null"}]}, p)
    assert out["id"].to_list() == [1, 2, 4]
    out = single("filter", {"mode": "formula", "formula": "IsNull([val]) OR Contains([name], 'Carol')"}, p)
    assert out["id"].to_list() == [2, 3]
    with pytest.raises(NodeConfigError, match="formula"):
        single("filter", {"mode": "formula", "formula": "[val] >"}, p)


def test_formula_sequential(csv):
    out = single("formula", {"columns": [
        {"name": "double", "formula": "[val] * 2"},
        {"name": "label", "formula": "IF [double] > 50 THEN 'big' ELSE 'small' ENDIF"},
        {"name": "val", "formula": "IfNull([val], -1)", "dtype": "int"},
    ]}, csv("b.csv", BASE))
    assert out["label"].to_list() == ["small", "small", "big", "big"]  # null condition -> ELSE
    assert out["val"].to_list() == [10, -1, 30, 40] and out["val"].dtype == pl.Int64


def test_record_id_and_sort(csv):
    p = csv("b.csv", BASE)
    out = single("record_id", {"name": "rid", "start": 100, "group_by": ["grp"]}, p)
    assert out["rid"].to_list() == [100, 101, 100, 101]
    out = single("sort", {"by": [{"column": "grp", "descending": True}, {"column": "val"}]}, p)
    assert out["id"].to_list() == [3, 4, 1, 2]  # nulls last within grp a


def test_unique(csv):
    p = csv("u.csv", pl.DataFrame({"k": [1, 1, 2], "v": ["a", "b", "c"]}))
    assert single("unique", {"columns": ["k"], "keep": "last"}, p)["v"].to_list() == ["b", "c"]
    assert single("unique", {}, p).height == 3


def test_join_union(csv):
    left = csv("l.csv", pl.DataFrame({"k": [1, 2, 3], "x": ["a", "b", "c"]}))
    right = csv("r.csv", pl.DataFrame({"key": [1, 3, 3], "x": ["A", "C1", "C2"]}))
    g = Graph()
    g.add_node("l", "input", {"path": left}); g.add_node("r", "input", {"path": right})
    g.add_node("j", "join", {"how": "left", "keys": [{"left": "k", "right": "key"}]})
    g.add_edge("l", "j", "left"); g.add_edge("r", "j", "right")
    out = build_plans(g)["j"].collect().sort("k")
    assert out.columns == ["k", "x", "Right_x"]                   # Alteryx-style clash prefix
    assert out["Right_x"].to_list() == ["A", None, "C1", "C2"]
    g.node("j").config["fields"] = [{"column": "k"}, {"column": "Right_x", "rename": "rx"}]
    assert build_plans(g)["j"].collect().columns == ["k", "rx"]
    g.add_node("u", "union", {"match": "by name"})
    g.add_edge("l", "u"); g.add_edge("r", "u")
    out = build_plans(g)["u"].collect()
    assert out.columns == ["k", "x", "key"] and out.height == 6


def test_join_type_mismatch_is_reported(csv):
    left = csv("l.csv", pl.DataFrame({"k": [1, 2]}))
    right = csv("r.csv", pl.DataFrame({"k": ["a", "b"]}))
    g = Graph()
    g.add_node("l", "input", {"path": left}); g.add_node("r", "input", {"path": right})
    g.add_node("j", "join", {"keys": [{"left": "k", "right": "k"}]})
    g.add_edge("l", "j", "left"); g.add_edge("r", "j", "right")
    with pytest.raises(RunError, match="join 'j'.*join keys don't match"):
        preview(g, "j")


def test_summarise_transpose_crosstab(csv):
    p = csv("b.csv", BASE)
    out = single("summarise", {"group_by": ["grp"], "row_count": "n", "aggregations": [
        {"column": "val", "function": "sum"}, {"column": "name", "function": "concat", "alias": "names"}]}, p)
    assert out.to_dicts() == [{"grp": "a", "n": 2, "val_sum": 10.0, "names": " Alice , bob"},
                              {"grp": "b", "n": 2, "val_sum": 70.0, "names": "Carol\tX"}]
    assert single("summarise", {"aggregations": [{"column": "val", "function": "max"}]}, p).row(0) == (40.0,)

    long = single("transpose", {"index": ["id"], "on": ["name", "val"], "as_text": True,
                                "variable_name": "field", "value_name": "v"}, p)
    assert long.columns == ["id", "field", "v"] and long.height == 8
    wide_src = csv("long.csv", long)
    wide = single("crosstab", {"index": ["id"], "on": "field", "values": "v"}, wide_src).sort("id")
    assert wide.columns == ["id", "name", "val"]
    assert wide["val"].to_list() == ["10.0", None, "30.0", "40.0"]


def test_spatial(tmp_path, csv):
    pts = csv("p.csv", pl.DataFrame({"id": [1, 2, 3], "lat": [59.33, 57.7, None], "lon": [18.06, 11.97, 1.0]}))
    polys = tmp_path / "z.parquet"
    pl.DataFrame({
        "zone": ["sthlm", "gbg"],
        "geometry": pl.Series([shapely.to_wkb(shapely.box(17.5, 59, 18.5, 59.7)),
                               shapely.to_wkb(shapely.box(11.5, 57.4, 12.3, 58))], dtype=pl.Binary),
    }).write_parquet(polys)
    g = Graph()
    g.add_node("p", "input", {"path": pts})
    g.add_node("pt", "create_points", {"lat": "lat", "lon": "lon"})
    g.add_node("z", "input", {"path": str(polys)})
    g.add_node("m", "spatial_match", {"how": "left"})
    g.add_node("o", "output", {"path": str(tmp_path / "out.parquet"), "format": "geoparquet"})
    g.add_edge("p", "pt"); g.add_edge("pt", "m", "points"); g.add_edge("z", "m", "polygons"); g.add_edge("m", "o")
    assert schema(g, "pt")["geometry"] == pl.Binary
    out = build_plans(g)["m"].collect().sort("id")
    assert out["zone"].to_list() == ["sthlm", "gbg", None]
    run(g)
    import pyarrow.parquet as pq
    meta = pq.read_metadata(tmp_path / "out.parquet").metadata
    assert b"geo" in meta and b"EPSG:4326" in meta[b"geo"]


def test_inputs_excel_and_encodings(tmp_path):
    import xlsxwriter
    xp = tmp_path / "t.xlsx"
    wb = xlsxwriter.Workbook(str(xp)); ws = wb.add_worksheet("Data")
    ws.write(0, 0, "title row"); ws.write(1, 0, "a"); ws.write(1, 1, "b")
    ws.write(2, 0, 1); ws.write(2, 1, "x"); ws.write(3, 0, 2); ws.write(3, 1, "y")
    wb.close()
    g = Graph(); g.add_node("i", "input", {"path": str(xp), "sheet": "Data", "header_row": 1, "all_strings": True})
    out = build_plans(g)["i"].collect()
    assert out.columns == ["a", "b"] and out["a"].dtype == pl.String and out.height == 2

    cp = tmp_path / "t.csv"
    cp.write_bytes("a;b\n1;Åland\n".encode("cp1252"))
    g = Graph(); g.add_node("i", "input", {"path": str(cp), "encoding": "cp1252", "delimiter": ";"})
    assert build_plans(g)["i"].collect()["b"].to_list() == ["Åland"]


def test_validation_and_run_errors(csv):
    p = csv("b.csv", BASE)
    with pytest.raises(NodeConfigError, match="required"):
        single("sort", {}, p)
    with pytest.raises(NodeConfigError, match="unknown node type"):
        single("nope", {}, p)
    g = Graph()
    g.add_node("src", "input", {"path": p})
    g.add_node("n", "filter", {"conditions": [{"column": "missing", "op": "=", "value": "1"}]})
    g.add_edge("src", "n")
    with pytest.raises(RunError, match="filter 'n'.*'missing' does not exist"):
        preview(g, "n")


def test_comment_node_and_excel_range(tmp_path):
    from raw2ufs.export.to_script import export_script
    g = Graph()
    g.add_node("note", "comment", {"text": "Client X mapping\nvalues in kSEK"}, name="Note")
    g.add_node("i", "input", {"path": "in.csv"})
    text = export_script(g)
    assert "# Raw2UFS_COMMENT: note" in text and "# Client X mapping\n# values in kSEK" in text
    run(g)   # a comment executes as a no-op

    import xlsxwriter
    xp = tmp_path / "r.xlsx"
    wb = xlsxwriter.Workbook(str(xp)); ws = wb.add_worksheet("S")
    ws.write(0, 0, "junk"); ws.write(2, 1, "a"); ws.write(2, 2, "b"); ws.write(2, 3, "c")
    for r in range(3, 8):
        ws.write(r, 1, r); ws.write(r, 2, "x"); ws.write(r, 3, 1.5)
    wb.close()
    g = Graph(); g.add_node("i", "input", {"path": str(xp), "range": "B3:C6"})
    out = build_plans(g)["i"].collect()
    assert out.columns == ["a", "b"] and out.height == 3
    with pytest.raises(NodeConfigError, match="cell range"):
        g.node("i").config["range"] = "3B"; build_plans(g)


def test_select_records_multi_field_append(csv):
    p = csv("b.csv", BASE)
    assert single("select_records", {"ranges": "1"}, p)["id"].to_list() == [1]
    assert single("select_records", {"ranges": "2-"}, p)["id"].to_list() == [2, 3, 4]
    assert single("select_records", {"ranges": "-2, 4-4"}, p)["id"].to_list() == [1, 2, 4]
    with pytest.raises(NodeConfigError, match="row range"):
        single("select_records", {"ranges": "x"}, p)
    out = single("multi_field_formula", {"columns": ["id", "val"], "formula": "IfNull([_CurrentField_], 0) * 10",
                                         "output": "new columns", "prefix": "", "suffix": "_x10"}, p)
    assert out["val_x10"].to_list() == [100.0, 0.0, 300.0, 400.0] and out["id_x10"].to_list() == [10, 20, 30, 40]
    out = single("multi_field_formula", {"columns": ["name"], "formula": "Concat([_CurrentFieldName_], ':', Trim([_CurrentField_]))"}, p)
    assert out["name"].to_list()[0] == "name:Alice"
    with pytest.raises(NodeConfigError, match="_CurrentField_"):
        single("multi_field_formula", {"columns": ["id"], "formula": "[id] + 1"}, p)
    src = csv("p.csv", pl.DataFrame({"rate": [0.5], "grp": ["z"]}))
    g = Graph()
    g.add_node("t", "input", {"path": p}); g.add_node("s", "input", {"path": src})
    g.add_node("a", "append_fields", {"prefix": "p_"})
    g.add_edge("t", "a", "target"); g.add_edge("s", "a", "source")
    out = build_plans(g)["a"].collect()
    assert out.columns == ["id", "name", "grp", "val", "p_rate", "p_grp"] and out.height == 4
    g.node("a").config["max_source_rows"] = 0
    with pytest.raises(RunError, match="above the limit"):
        preview(g, "a")


def test_constants_in_formula_and_paths(tmp_path):
    import os
    pl.DataFrame({"a": [1, 2]}).write_csv(tmp_path / "in.csv")
    g = Graph(); g.base_dir = str(tmp_path)
    g.set_constant("Scale", 1000); g.set_constant("Client", "acme")
    g.add_node("i", "input", {"path": "in.csv"})
    g.add_node("f", "formula", {"columns": [{"name": "b", "formula": "[a] * [$Scale]"}, {"name": "c", "formula": "IIF([a] > 1, [$Client], 'none')"}]})
    g.add_node("o", "output", {"path": "out/${Client}.csv"})
    g.add_edge("i", "f"); g.add_edge("f", "o")
    assert build_plans(g)["f"].collect()["b"].to_list() == [1000, 2000]
    run(g); assert (tmp_path / "out" / "acme.csv").exists()
    run(g, constants={"Client": "other"}); assert (tmp_path / "out" / "other.csv").exists()
    g.node("o").enabled = False
    assert g.disabled_nodes() == {"o"}
    g.node("o").enabled = True; g.run_outputs = False
    assert g.disabled_nodes() == {"o"}
    g.constants.pop("Scale")
    with pytest.raises(NodeConfigError, match="unknown constant"):
        build_plans(g)
    g2 = Graph.from_json(g.to_json()); assert g2.constants["Client"]["value"] == "acme" and not g2.run_outputs


def test_dynamic_rename_text_to_columns_typed_filter(csv, tmp_path):
    p = csv("h.csv", pl.DataFrame({"c1": ["Site", "A", "B"], "c2": ["Value", "1", "2"], "c3": ["Value", "x", "y"]}))
    g = Graph(); g.add_node("src", "input", {"path": p, "all_strings": True})
    g.add_node("n", "dynamic_rename", {"mode": "first row"}); g.add_edge("src", "n")
    out = build_plans(g)["n"].collect()
    assert out.columns == ["Site", "Value", "Value_2"] and out.height == 2
    g.node("n").config = {"mode": "add prefix/suffix", "prefix": "src_", "columns": ["c1"]}
    assert build_plans(g)["n"].collect().columns == ["src_c1", "c2", "c3"]
    g.node("n").config = {"mode": "remove prefix/suffix", "prefix": "c"}
    assert build_plans(g)["n"].collect().columns == ["1", "2", "3"]

    t = csv("t.csv", pl.DataFrame({"addr": ['Main St 1, "Stockholm, SE", 111 57', "Kungsg 5, Oslo, 0150, extra", "x", None]}))
    out = single("text_to_columns", {"column": "addr", "delimiter": ",", "n_columns": 3, "root": "Part",
                                     "ignore_quoted": True, "keep_original": False}, t)
    assert out.columns == ["Part_1", "Part_2", "Part_3"]
    assert out.row(0) == ("Main St 1", "Stockholm", "SE") and out.row(2) == ("x", None, None)
    out = single("text_to_columns", {"column": "addr", "delimiter": ",", "n_columns": 3, "root": "P", "extra": "keep in last"}, t)
    assert out["P_3"].to_list()[1] == " 0150, extra" and out.columns[0] == "addr"
    out = single("text_to_columns", {"column": "addr", "delimiter": ",", "mode": "to rows", "root": "piece"}, t)
    assert out.height == 9   # 4 + 4 + 1 pieces (quotes not honoured without ignore_quoted); null row dropped
    with pytest.raises(NodeConfigError, match="at least 1"):
        single("text_to_columns", {"column": "addr", "delimiter": ",", "n_columns": 0}, t)

    f = csv("f.csv", pl.DataFrame({"n": ["1", "2", "3"], "d": ["2024-01-01", "2024-06-01", "2023-01-01"], "s": ["9", "20", "x"]}))
    g = Graph(); g.add_node("src", "input", {"path": f, "all_strings": True})
    g.add_node("fl", "filter", {"conditions": [{"column": "d", "op": ">", "value": "2024-01-01", "dtype": "date"},
                                               {"column": "n", "op": "<=", "value": "2", "dtype": "int"}]}); g.add_edge("src", "fl")
    assert build_plans(g)["fl"].collect()["n"].to_list() == ["2"]
    g.node("fl").config = {"conditions": [{"column": "s", "op": ">", "value": "10", "dtype": "int"}]}
    assert build_plans(g)["fl"].collect()["s"].to_list() == ["20"]              # numeric compare on text column
    g.node("fl").config = {"conditions": [{"column": "s", "op": ">", "value": "10", "dtype": "string"}]}
    assert build_plans(g)["fl"].collect()["s"].to_list() == ["9", "20", "x"]    # text compare


def test_run_cancel(csv):
    from raw2ufs.engine.runner import RunCancelled
    p = csv("b.csv", BASE)
    g = Graph(); g.add_node("src", "input", {"path": p}); g.add_node("s", "sort", {"by": [{"column": "id"}]}); g.add_edge("src", "s")
    seen = []
    with pytest.raises(RunCancelled):
        run(g, on_node=lambda spec, st, d: seen.append((spec.id, st)), should_stop=lambda: len(seen) >= 2)
    assert [s for s in seen if s[1] == "done"] == [("src", "done")]
