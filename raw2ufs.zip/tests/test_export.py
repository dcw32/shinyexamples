"""The exported script must reproduce the engine's outputs exactly."""

import copy
import runpy
from pathlib import Path

import polars as pl
import pytest
from polars.testing import assert_frame_equal

from raw2ufs.engine.graph import Graph, load_graph
from raw2ufs.engine.runner import run
from raw2ufs.export.to_script import export_script

ROOT = Path(__file__).resolve().parent.parent
EXAMPLE = ROOT / "examples" / "sov_to_oed.json"


def _retarget_outputs(graph: Graph, folder: Path) -> Graph:
    g = Graph.from_dict(copy.deepcopy(graph.to_dict()))
    for spec in g:
        if spec.type == "output":
            spec.config["path"] = str(folder / Path(spec.config["path"]).name)
    return g


def _read(path: Path) -> pl.DataFrame:
    return pl.read_csv(path) if path.suffix == ".csv" else pl.read_parquet(path)


@pytest.mark.skipif(not (ROOT / "examples" / "data" / "sov_main.xlsx").exists(),
                    reason="run examples/make_sample_data.py first")
def test_example_engine_and_script_agree(tmp_path, monkeypatch):
    monkeypatch.chdir(EXAMPLE.parent)  # relative paths resolve next to the workflow file
    base = load_graph(EXAMPLE)

    a, b = tmp_path / "engine", tmp_path / "script"
    a.mkdir(); b.mkdir()
    run(_retarget_outputs(base, a))

    script = export_script(_retarget_outputs(base, b), source=EXAMPLE)
    script_path = EXAMPLE.parent / "_test_export_tmp.py"   # beside the workflow: relative paths resolve
    script_path.write_text(script, encoding="utf-8")
    try:
        runpy.run_path(str(script_path), run_name="__main__")
    finally:
        script_path.unlink()

    outputs = sorted(p.name for p in a.iterdir())
    assert outputs == sorted(p.name for p in b.iterdir()) and len(outputs) == 3
    for name in outputs:
        assert_frame_equal(_read(a / name), _read(b / name))

    # the script is plain polars: no raw2ufs import, every node tagged
    assert not any(l.startswith(("import raw2ufs", "from raw2ufs")) for l in script.splitlines())
    for spec in base:
        assert f"# Raw2UFS_{spec.type.upper()}: {spec.id}" in script

    # and the content is right
    loc = pl.read_csv(a / "location.csv")
    assert loc["LocNumber"].to_list() == list(range(1, 8))
    assert loc["LocUserDef1"].to_list() == ["SE-01", "SE-01", "SE-03", "SE-02", None, "SE-01", "SE-02"]
    assert loc.filter(pl.col("LocName") == "A-001").row(0, named=True)["LocDed6All"] == 0.01


def test_export_minimal_script_has_no_helpers(tmp_path):
    g = Graph(name="mini")
    g.add_node("i", "input", {"path": "in.csv"})
    g.add_node("o", "output", {"path": "out.csv"})
    g.add_edge("i", "o")
    text = export_script(g)
    assert "_r2u_" not in text and "selectors" not in text
    assert "Requires: polars\n" in text


def test_disabled_container_skips_run_and_comments_export(tmp_path):
    import polars as pl
    from raw2ufs.engine.runner import RunError, run, preview
    src = tmp_path / "in.csv"; pl.DataFrame({"a": [1, 2]}).write_csv(src)
    g = Graph(name="c")
    g.add_node("i", "input", {"path": str(src)})
    g.add_node("f", "formula", {"columns": [{"name": "b", "formula": "[a] * 2"}]})
    g.add_node("o", "output", {"path": str(tmp_path / "out.csv")})
    g.add_node("o2", "output", {"path": str(tmp_path / "out2.csv")})
    g.add_edge("i", "f"); g.add_edge("f", "o"); g.add_edge("i", "o2")
    g.add_container("c1", "Doubling", ["f"], enabled=False)
    run(g)
    assert (tmp_path / "out2.csv").exists() and not (tmp_path / "out.csv").exists()
    with pytest.raises(RunError, match="disabled"):
        preview(g, "f")
    text = export_script(g)
    assert '# Raw2UFS_FORMULA: f - DISABLED (container "Doubling" is disabled)' in text
    assert "# Raw2UFS_OUTPUT: o - DISABLED (downstream of a disabled container)" in text
    assert "# df_f = (" in text and "\ndf_f = (" not in text          # code kept, but commented out
    assert "Requires: polars\n" in text                                # disabled helpers don't count
    # re-enable: everything runs
    g.containers[0].enabled = True
    run(g); assert (tmp_path / "out.csv").exists()
