import polars as pl

from raw2ufs.engine.cache import Cache
from raw2ufs.engine.graph import Graph
from raw2ufs.engine.runner import build_plans, preview


def _graph(path):
    g = Graph()
    g.add_node("i", "input", {"path": str(path)})
    g.add_node("f", "formula", {"columns": [{"name": "b", "formula": "[a] * 2"}]})
    g.add_edge("i", "f")
    return g


def test_cache_hit_invalidate_on_config_and_file_change(tmp_path):
    src = tmp_path / "in.csv"
    pl.DataFrame({"a": [1, 2, 3]}).write_csv(src)
    cache = Cache(tmp_path / "cache")
    g = _graph(src)
    assert cache.status(g) == {"i": False, "f": False}
    info = cache.materialise(g, "f")
    assert info["rows"] == 3 and cache.has(g, "f")
    # downstream plans now start from the parquet, not the csv
    plan = build_plans(g, cache=cache)["f"].explain()
    assert "parquet" in plan.lower() and "csv" not in plan.lower()
    assert preview(g, "f", cache=cache)["b"].to_list() == [2, 4, 6]
    # config change upstream -> miss
    g.node("f").config["columns"][0]["formula"] = "[a] * 3"
    assert not cache.has(g, "f")
    # file change -> miss
    g.node("f").config["columns"][0]["formula"] = "[a] * 2"
    assert cache.has(g, "f")
    pl.DataFrame({"a": [1, 2, 3, 4]}).write_csv(src)
    import os, time
    os.utime(src, (time.time() + 5, time.time() + 5))
    assert not cache.has(g, "f")
    assert build_plans(g, cache=cache)["f"].collect().height == 4
    assert cache.clear() >= 1 and cache.size_bytes() == 0


def test_infer_and_profile_api(tmp_path):
    from ui.api import Api
    src = tmp_path / "in.csv"
    pl.DataFrame({"n": ["1 000", "2", ""], "d": ["2024-01-01", "2024-02-01", None], "t": ["a", "b", "c"]}).write_csv(src)
    api = Api(str(tmp_path / "cache"))
    g = Graph(); g.add_node("i", "input", {"path": str(src), "all_strings": True})
    r = api.infer_types(g.to_dict(), "i")
    assert r["ok"] and r["types"] == {"n": "int", "d": "date", "t": "string"}
    p = api.profile(g.to_dict(), "i")
    assert p["rows"] == 3 and (p["columns"][0]["nulls"] + p["columns"][0]["blank"]) == 1 and p["columns"][2]["distinct"] == 3
    x = api.excel_info(str(tmp_path / "missing.xlsx"))
    assert not x["ok"]
