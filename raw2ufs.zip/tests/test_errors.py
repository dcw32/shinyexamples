"""Error attribution (lazy errors blamed on the right tool) and warning capture."""

import polars as pl
import pytest

import raw2ufs  # noqa: F401  registers nodes
import raw2ufs.engine.runner as runner_mod
from raw2ufs.engine.graph import Graph
from raw2ufs.engine.runner import RunError, explain, preview, run, schema


def _graph(tmp_path, formula="[nope] + 1"):
    pl.DataFrame({"a": ["1", "x"], "b": [1, 2]}).write_csv(tmp_path / "in.csv")
    g = Graph.from_dict({"version": 1, "nodes": [
        {"id": "src", "type": "input", "config": {"path": "in.csv"}},
        {"id": "f", "type": "formula", "name": "derive", "config": {"columns": [{"name": "c", "formula": formula}]}},
        {"id": "s", "type": "sort", "config": {"by": [{"column": "b"}]}},
        {"id": "out", "type": "output", "config": {"path": "o.csv"}}],
        "edges": [{"from": "src", "to": "f"}, {"from": "f", "to": "s"}, {"from": "s", "to": "out"}]})
    g.base_dir = str(tmp_path)
    return g


def test_run_error_is_attributed_upstream(tmp_path):
    g = _graph(tmp_path)
    log = []
    with pytest.raises(RunError) as ei:
        run(g, on_node=lambda s, st, d: log.append((s.id, st)))
    e = ei.value
    assert e.node_id == "f" and e.surfaced_at == "out"
    text = str(e)
    assert "formula 'f' (derive)" in text and "'nope'" in text and "Columns available: a, b" in text
    assert "upstream at 'f'" in text
    assert ("out", "error") in log            # the sink's log entry still records the failure


def test_preview_and_schema_attribute_too(tmp_path):
    g = _graph(tmp_path)
    with pytest.raises(RunError) as ei:
        preview(g, "s")
    assert (ei.value.node_id, ei.value.surfaced_at) == ("f", "s")
    with pytest.raises(RunError) as ei:
        schema(g, "s")
    assert ei.value.node_id == "f"


def test_error_at_the_failing_node_itself_has_no_surfaced_at(tmp_path):
    g = _graph(tmp_path)
    with pytest.raises(RunError) as ei:
        preview(g, "f")
    assert ei.value.node_id == "f" and ei.value.surfaced_at is None


def test_explain_suggests_close_column():
    try:
        pl.LazyFrame({"TIV": [1]}).select(pl.col("tiv")).collect_schema()
    except Exception as e:  # noqa: BLE001
        text = explain(e, ["TIV", "Country"])
    assert "did you mean 'TIV'" in text and "Columns available: TIV, Country" in text


def test_python_warnings_go_to_the_log(tmp_path, monkeypatch):
    g = _graph(tmp_path, formula="[b] + 1")
    orig = runner_mod.compile_graph

    def noisy(graph, only=None, include_disabled=False):
        blocks = orig(graph, only, include_disabled)
        blocks[0].code = "import warnings; warnings.warn('dodgy cell', UserWarning)\n" + blocks[0].code
        return blocks

    monkeypatch.setattr(runner_mod, "compile_graph", noisy)
    log = []
    run(g, on_node=lambda s, st, d: log.append((s.id, st, d)))
    assert [(i, d) for i, st, d in log if st == "warning"] == [("src", "UserWarning: dodgy cell")]
