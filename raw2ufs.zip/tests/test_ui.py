"""Browser smoke test of the front end (needs playwright + chromium; skipped otherwise).

Starts the dev HTTP server in-process, opens the example workflow through the
UI, exercises the canvas, inspector, preview, run and script export.
"""

import socket
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
EXAMPLE = ROOT / "examples" / "sov_to_oed.json"

playwright = pytest.importorskip("playwright.sync_api")


def _free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


@pytest.fixture(scope="module")
def server():
    from ui.api import Api
    from ui.server import serve
    port = _free_port()
    httpd = serve(port=port, api=Api(), background=True)
    yield f"http://127.0.0.1:{port}"
    httpd.shutdown()


@pytest.fixture(scope="module")
def page(server):
    with playwright.sync_playwright() as p:
        browser = p.chromium.launch()
        pg = browser.new_page(viewport={"width": 1400, "height": 900})
        errors = []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.on("dialog", lambda d: d.accept())      # "discard unsaved changes?" confirms
        pg.goto(server)
        pg.wait_for_selector(".pal-item")
        pg.errors = errors
        yield pg
        browser.close()


def _open_example(page):
    # fresh tab every time; blank the canvas first so the wait below cannot match the previous graph's nodes
    page.evaluate("localStorage.clear(); tabs = []; activeTab = null; graph = {version: 1, name: '', nodes: [], edges: [], containers: []}; render()")
    page.click("#btn-open")
    page.fill("#modal-input", str(EXAMPLE))
    page.click("#modal-ok")
    page.wait_for_selector(".node[data-id='derive']")


@pytest.mark.skipif(not EXAMPLE.exists(), reason="example missing")
def test_palette_and_open(page):
    assert page.locator(".pal-item").count() >= 16
    _open_example(page)
    assert page.locator(".node").count() == 21
    assert page.locator("#edges path").count() == 20
    assert "sov_to_oed.json" in page.inner_text("#status")
    assert not page.errors


def test_inspector_renders_fields_and_schema_pickers(page):
    _open_example(page)
    page.click(".node[data-id='derive'] .head")
    page.wait_for_selector("#inspector table.tbl")
    assert page.locator("#inspector table.tbl tr").count() == 12   # header + 11 formulas
    # join picks columns from both ports
    page.click(".node[data-id='map_occ'] .head")
    page.wait_for_selector("#inspector h3:has-text('Join')")
    page.wait_for_function("document.querySelectorAll('#inspector datalist option').length > 0")
    opts = page.evaluate("[...document.querySelectorAll('#inspector datalist option')].map(o => o.value)")
    assert "OccupancyKey" in opts and "OccupancyCode" in opts
    assert not page.errors


def test_edit_validate_preview(page):
    _open_example(page)
    page.click(".node[data-id='has_ref'] .head")
    page.wait_for_selector("#inspector textarea")
    page.fill("#inspector textarea", "[LocName] <>")          # broken formula
    page.keyboard.press("Tab")                                # problems only show once you leave the field
    page.wait_for_selector(".node[data-id='has_ref'].problem", timeout=5000)
    assert "problem" in page.inner_text("#status")
    page.fill("#inspector textarea", "NOT IsNull([LocName])")
    page.wait_for_function("!document.querySelector('.node[data-id=\"has_ref\"].problem')", timeout=5000)
    page.click("#btn-preview")
    page.wait_for_selector("#panes table.grid")
    header = page.inner_text("#panes table.grid tr")
    assert "OccupancyCode" in header and "LocName" in header
    assert page.locator("#panes table.grid tr").count() == 8     # header + 7 rows
    assert not page.errors


def test_add_connect_delete(page):
    _open_example(page)
    before = page.locator(".node").count()
    page.click(".pal-item:has-text('Sort')")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {before + 1}")
    new_id = page.evaluate("document.querySelector('.node.selected').dataset.id")
    assert new_id.startswith("sort")
    # wire sov_main -> new sort by dragging from the output dot to the input dot (both on screen)
    page.evaluate(f"nodeById('{new_id}').ui = {{x: 300, y: 400}}; view = {{x: 20, y: 20, scale: 1}}; applyView(); render()")
    src = page.locator(".node[data-id='sov_main'] [data-out]")
    dst = page.locator(f".node[data-id='{new_id}'] [data-in]")
    sb, db = src.bounding_box(), dst.bounding_box()
    page.mouse.move(sb["x"] + 6, sb["y"] + 6); page.mouse.down()
    page.mouse.move(db["x"] + 6, db["y"] + 6, steps=5); page.mouse.up()
    assert page.evaluate(f"graph.edges.some(e => e.from === 'sov_main' && e.to === '{new_id}')")
    page.keyboard.press("Delete")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {before}")
    assert not page.errors


def test_run_and_script(page, tmp_path):
    _open_example(page)
    # retarget outputs into tmp so the test never writes into examples/
    page.evaluate(f"graph.nodes.filter(n => n.type === 'output').forEach(n => n.config.path = '{tmp_path.as_posix()}/' + n.config.path.split('/').pop())")
    page.click("#btn-run")
    page.wait_for_selector("#panes .log-line.done:has-text('Done')", timeout=30000)
    assert (tmp_path / "location.csv").exists() and (tmp_path / "location.parquet").exists()
    page.click("#tabs button[data-tab='script']")
    page.click("#btn-export")
    page.wait_for_selector("#modal")
    page.fill("#modal-input", str(tmp_path / "wf.py")); page.click("#modal-ok")
    page.wait_for_function("document.querySelector('#status').textContent.includes('Exported')")
    text = (tmp_path / "wf.py").read_text()
    assert "# Raw2UFS_SPATIAL_MATCH: zone_match" in text
    assert not page.errors


def test_typing_keeps_focus_and_column_datalist(page):
    _open_example(page)
    page.click(".node[data-id='derive'] .head")
    page.wait_for_selector("#inspector table.tbl")
    ta = page.locator("#inspector table.tbl textarea").first
    ta.click(); ta.fill("")
    page.keyboard.type("Upper([Count", delay=60)      # slow typing: validation fires mid-way
    page.wait_for_timeout(700)
    assert page.evaluate("document.activeElement && document.activeElement.tagName") == "TEXTAREA"
    assert ta.input_value() == "Upper([Count"
    assert not page.locator(".node[data-id='derive'].problem").count()   # no red while typing
    # the output-column box lists existing columns but accepts new names
    opts = page.evaluate("[...document.querySelectorAll('#inspector table.tbl datalist option')].map(o => o.value)")
    assert "LocName" in opts
    assert not page.errors


def test_zoom_duplicate_comment_profile_runto(page, tmp_path):
    _open_example(page)
    before = page.evaluate("view.scale")
    page.click("#zoom-in"); assert page.evaluate("view.scale") > before
    page.click("#zoom-fit")
    # duplicate
    page.click(".node[data-id='order'] .head")
    n0 = page.locator(".node").count()
    page.keyboard.press("Control+d")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0 + 1}")
    assert page.evaluate("nodeById('order_2').config.by[0].column") == "LocName"
    page.keyboard.press("Delete")                     # remove the (unconnected) copy again
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0}")
    # comment node renders as a note
    page.click(".pal-item:has-text('Comment')")
    page.wait_for_selector(".node.note")
    page.fill("#inspector textarea.plain", "hello note")
    page.wait_for_function("document.querySelector('.node.note .text').textContent === 'hello note'")
    # profile
    page.click(".node[data-id='derive'] .head")
    page.click("#btn-profile")
    page.wait_for_selector("#panes table.grid")
    assert "7" in page.inner_text("#panes")
    # run to here -> cached marker on the node
    page.click("#btn-runto")
    page.wait_for_selector(".node[data-id='derive'] .cached", timeout=30000)
    page.click("#btn-clearcache")
    page.wait_for_function("!document.querySelector('.node[data-id=\"derive\"] .cached')")
    assert not page.errors


def test_excel_picker(page):
    _open_example(page)
    page.click(".node[data-id='sov_main'] .head")
    page.wait_for_selector("#xl table.xlgrid")
    assert page.locator("#xl tr.hdr th").first.inner_text() == "3"      # header row highlighted (1-based)
    page.click("#xl td[data-cell='B3']")
    page.wait_for_function("nodeById('sov_main').config.range === 'B3'")
    page.wait_for_selector("#inspector [data-path='range']")
    page.click("#xl th.rn[data-row='2']")
    page.wait_for_function("nodeById('sov_main').config.range === '' && nodeById('sov_main').config.header_row === 2")
    assert not page.errors


def test_marquee_group_ops_and_undo(page):
    _open_example(page)
    page.evaluate("view = {x: 20, y: 20, scale: 1}; applyView()")
    n0 = page.locator(".node").count()
    # rubber-band around the two inputs at (40,40) and (40,160): world -> screen is +20
    c = page.locator("#canvas").bounding_box()
    page.mouse.move(c["x"] + 30, c["y"] + 30); page.mouse.down()
    page.mouse.move(c["x"] + 300, c["y"] + 300, steps=6); page.mouse.up()
    assert set(page.evaluate("[...multi]")) == {"sov_main", "sov_extra"}
    assert "2 nodes selected" in page.inner_text("#inspector")
    # shift-click adds a third
    page.click(".node[data-id='stack'] .head", modifiers=["Shift"])
    assert page.evaluate("multi.size") == 3
    # group drag moves all three together
    before = page.evaluate("[...multi].map(id => nodeById(id).ui.x)")
    h = page.locator(".node[data-id='stack'] .head").bounding_box()
    page.mouse.move(h["x"] + 10, h["y"] + 10); page.mouse.down(); page.mouse.move(h["x"] + 110, h["y"] + 10, steps=5); page.mouse.up()
    after = page.evaluate("[...multi].map(id => nodeById(id).ui.x)")
    assert all(b - a == 100 for a, b in zip(before, after))
    # duplicate keeps the internal connections (2 inputs -> union)
    page.keyboard.press("Control+d")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0 + 3}")
    new_ids = page.evaluate("[...multi]")
    assert len(new_ids) == 3 and page.evaluate(f"graph.edges.filter(e => {new_ids!r}.includes(e.to) && {new_ids!r}.includes(e.from)).length") == 2
    # delete the copies, then undo brings them back, redo removes again
    page.keyboard.press("Delete")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0}")
    page.keyboard.press("Control+z")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0 + 3}")
    page.keyboard.press("Control+y")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0}")
    # copy / paste
    page.keyboard.press("Control+a"); assert page.evaluate("multi.size") == n0
    page.keyboard.press("Escape"); assert page.evaluate("multi.size") == 0
    page.click(".node[data-id='derive'] .head"); page.keyboard.press("Control+c"); page.keyboard.press("Control+v")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0 + 1}")
    assert page.evaluate("nodeById(selected).config.columns.length") == 11
    # wheel scrolls, ctrl+wheel zooms
    vx = page.evaluate("view.x"); page.mouse.move(c["x"] + 400, c["y"] + 300); page.mouse.wheel(0, 120)
    assert page.evaluate("view.y") < 20 and page.evaluate("view.x") == vx
    page.keyboard.down("Control"); page.mouse.wheel(0, -120); page.keyboard.up("Control")
    assert page.evaluate("view.scale") > 1
    assert not page.errors


def test_containers_and_palette_search(page, tmp_path):
    _open_example(page)
    page.evaluate("view = {x: 20, y: 20, scale: 1}; applyView()")
    # group the two inputs + union into a container
    page.evaluate("multi = new Set(['sov_main', 'sov_extra', 'stack']); selected = null; renderInspector(); render()")
    page.keyboard.press("Control+g")
    page.wait_for_selector(".container")
    assert page.evaluate("graph.containers.length") == 1 and page.evaluate("graph.containers[0].nodes.length") == 3
    assert page.evaluate("document.activeElement.id") == "c-name"
    page.keyboard.type("Sources"); page.keyboard.press("Tab")
    assert page.inner_text(".container .cname") == "Sources"
    page.click(".swatch[data-color='green']")
    assert page.evaluate("graph.containers[0].color") == "green"
    # container drag moves its members
    x0 = page.evaluate("nodeById('sov_main').ui.x")
    page.wait_for_timeout(1000)                       # let the debounced validate re-render settle
    h = page.evaluate("document.querySelector('.container .chead').getBoundingClientRect().toJSON()")
    page.mouse.move(h["x"] + 120, h["y"] + 8); page.mouse.down(); page.mouse.move(h["x"] + 220, h["y"] + 8, steps=5); page.mouse.up()
    assert page.evaluate("nodeById('sov_main').ui.x") == x0 + 100
    # disable: members and everything downstream grey out, validation ignores them
    page.click(".container .ctoggle")
    page.wait_for_selector(".container.off")
    page.wait_for_function("document.querySelectorAll('.node.off').length > 10")
    assert page.evaluate("disabledNodes().has('out_loc') && !disabledNodes().has('occ_lookup')")
    page.click("#btn-validate")
    page.wait_for_function("document.querySelector('#status').textContent.includes('valid')")
    # script shows them commented out
    page.click("#tabs button[data-tab='script']"); page.click("#btn-export")
    page.wait_for_selector("#modal"); page.fill("#modal-input", str(tmp_path / "wf.py")); page.click("#modal-ok")
    page.wait_for_function("document.querySelector('#status').textContent.includes('Exported')")
    text = (tmp_path / "wf.py").read_text()
    assert 'DISABLED (container "Sources" is disabled)' in text and "# df_stack = pl.concat" in text
    # re-enable via the inspector, drag a node out of the container, ungroup
    page.click(".container .chead")
    page.check("#c-on")
    page.wait_for_function("!document.querySelector('.container.off')")
    page.evaluate("nodeById('stack').ui.x = 1500; updateMembership(['stack']); render()")
    assert page.evaluate("graph.containers[0].nodes.length") == 2
    page.click(".container .chead"); page.keyboard.press("Control+Shift+g")
    page.wait_for_function("graph.containers.length === 0")
    assert page.evaluate("multi.size") == 2
    # palette search
    page.keyboard.press("Escape"); page.keyboard.press("/")
    assert page.evaluate("document.activeElement.id") == "pal-q"
    page.keyboard.type("spatial m")
    page.wait_for_function("document.querySelectorAll('.pal-item').length === 1")
    assert page.inner_text(".pal-item") == "Spatial Match"
    n0 = page.locator(".node").count()
    page.keyboard.press("Enter")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0 + 1}")
    assert page.evaluate("nodeById(selected).type") == "spatial_match"
    page.keyboard.press("Escape")
    assert page.locator(".pal-item").count() > 10
    assert not page.errors


def test_edges_above_containers_and_container_copy_paste(page):
    _open_example(page)
    page.evaluate("view = {x: 20, y: 20, scale: 1}; applyView()")
    page.evaluate("multi = new Set(['sov_main', 'sov_extra', 'stack']); selected = null; renderInspector(); render()")
    page.keyboard.press("Control+g"); page.wait_for_selector(".container"); page.keyboard.press("Tab")
    # the edge sov_main -> stack must be hit-testable above the container fill
    a = page.evaluate("portPos(nodeById('sov_main'), null, true)"); b = page.evaluate("portPos(nodeById('stack'), 'in', false)")
    mx, my = (a["x"] + b["x"]) / 2 + 20, (a["y"] + b["y"]) / 2 + 20
    c = page.locator("#canvas").bounding_box()
    tag = page.evaluate(f"document.elementFromPoint({c['x'] + mx}, {c['y'] + my}).tagName")
    assert tag.lower() == "path"
    # duplicate the container: new container with 3 tools and their 2 internal edges
    n0, e0 = page.locator(".node").count(), page.evaluate("graph.edges.length")
    page.click(".container .chead"); page.keyboard.press("Control+d")
    page.wait_for_function("graph.containers.length === 2")
    assert page.locator(".node").count() == n0 + 3 and page.evaluate("graph.edges.length") == e0 + 2
    assert page.evaluate("graph.containers[1].nodes.length") == 3 and page.evaluate("selectedContainer") == "c2"
    assert "Container" in page.inner_text("#inspector h3")
    # copy / paste the same way
    page.keyboard.press("Control+c"); page.keyboard.press("Control+v")
    page.wait_for_function("graph.containers.length === 3")
    page.keyboard.press("Control+z"); page.wait_for_function("graph.containers.length === 2")
    assert not page.errors


def test_dark_mode_toggle_persists(page):
    _open_example(page)
    page.evaluate("applyTheme('light')")
    assert page.evaluate("document.documentElement.getAttribute('data-theme')") is None
    page.click("#btn-theme")
    assert page.evaluate("document.documentElement.getAttribute('data-theme')") == "dark"
    assert page.evaluate("getComputedStyle(document.body).backgroundColor") == "rgb(20, 23, 28)"
    assert page.evaluate("localStorage.getItem('raw2ufs.theme')") == "dark"
    page.reload(); page.wait_for_selector(".pal-item")
    assert page.evaluate("document.documentElement.getAttribute('data-theme')") == "dark"
    page.evaluate("applyTheme('light')")
    assert not page.errors


def test_tabs_constants_and_output_toggles(page, tmp_path):
    _open_example(page)
    assert page.locator("#tabbar .tab").count() == 1
    # a second workflow in a new tab; switch back and forth without losing state
    page.click("#btn-new")
    page.wait_for_function("tabs.length === 2 && graph.nodes.length === 0")
    page.click(".pal-item:has-text('Comment')")
    page.wait_for_selector(".node.note")
    page.click("#tabbar .tab >> nth=0")
    page.wait_for_selector(".node[data-id='derive']")
    assert page.evaluate("graph.base_dir").endswith("examples")
    page.keyboard.press("Control+Tab")
    page.wait_for_selector(".node.note")
    assert page.locator("#tabbar .tab.active .dot").count() == 1          # unsaved marker on the new tab
    # close the scratch tab (dialog auto-accepted), back to the example
    page.click("#tabbar .tab.active .x")
    page.wait_for_selector(".node[data-id='derive']")
    assert page.evaluate("tabs.length") == 1
    # constants: add one, use it in a formula, see it in the script
    page.click("#btn-consts")
    page.wait_for_selector("#c-add"); page.click("#c-add")
    page.fill("[data-cname='Const1']", "Scale"); page.keyboard.press("Tab")
    page.select_option("[data-ctype='Scale']", "number")
    page.fill("[data-cval='Scale']", "1000")
    page.click("#c-close")
    page.click(".node[data-id='derive'] .head")
    page.wait_for_selector("#inspector table.tbl")
    page.evaluate("nodeById('derive').config.columns[2].formula = 'IfNull([BuildingRaw], 0) * [$Scale]'; onConfigChanged(nodeById('derive'), 'columns', true)")
    page.click("#btn-preview"); page.wait_for_selector("#panes table.grid")
    assert "12500000" in page.inner_text("#panes")
    page.click("#tabs button[data-tab='script']"); page.click("#btn-export")
    page.wait_for_selector("#modal"); page.fill("#modal-input", str(tmp_path / "wf.py")); page.click("#modal-ok")
    page.wait_for_function("document.querySelector('#status').textContent.includes('Exported')")
    text = (tmp_path / "wf.py").read_text()
    assert "K_Scale = 1000" in text and "pl.lit(K_Scale)" in text and "BASE_DIR = os.path.dirname" in text
    # unknown constant is reported
    page.evaluate("delete graph.constants.Scale; scheduleValidate()")
    page.wait_for_selector(".node[data-id='derive'].problem", timeout=5000)
    page.evaluate("graph.constants = {Scale: {type: 'number', value: 1000}}; scheduleValidate()")
    page.wait_for_function("!document.querySelector('.node[data-id=\"derive\"].problem')", timeout=5000)
    # per-output toggle and workflow-level switch
    page.click(".node[data-id='out_loc'] .otoggle")
    page.wait_for_selector(".node[data-id='out_loc'].off")
    assert page.evaluate("nodeById('out_loc').enabled") is False and not page.locator(".node[data-id='out_geo'].off").count()
    page.click("#btn-outputs")
    page.wait_for_function("document.querySelectorAll('.node.off').length === 3")
    assert "OFF" in page.inner_text("#btn-outputs") and page.evaluate("graph.run_outputs") is False
    page.click("#btn-outputs")
    page.wait_for_function("document.querySelectorAll('.node.off').length === 1")
    assert not page.errors


def test_join_out_picker_filter_types_container_fit_and_cancel_button(page):
    _open_example(page)
    # join output-field picker lists left columns and Right_-prefixed right ones
    page.click(".node[data-id='map_occ'] .head")
    page.wait_for_selector("#inspector h3:has-text('Join')")
    page.click("[data-addrow='fields']")
    page.wait_for_selector("[data-path='fields.0.column']")
    opts = page.evaluate("[...document.querySelector('[data-path=\"fields.0.column\"]').list.options].map(o => o.value)")
    assert "LocName" in opts and "OccupancyCode" in opts and "Right_OccupancyRaw" not in opts   # right key is consumed, no clash
    assert page.evaluate("joinOutputColumns({config: {keys: [{left: 'k', right: 'k'}], right_prefix: 'Right_'}}, {left: ['k', 'x'], right: ['k', 'x', 'y']})") == ["k", "x", "Right_x", "y"]
    page.click("[data-delrow='fields']")
    # filter: picking a column fills in its type
    page.click(".node[data-id='has_ref'] .head")
    page.wait_for_selector("#inspector select[data-path='mode']")
    page.select_option("#inspector select[data-path='mode']", "simple")
    page.wait_for_selector("[data-addrow='conditions']"); page.click("[data-addrow='conditions']")
    page.wait_for_selector("[data-path='conditions.0.column']")
    page.fill("[data-path='conditions.0.column']", "BuildingTIV")
    page.wait_for_function("nodeById('has_ref').config.conditions[0].dtype === 'float'")
    page.fill("[data-path='conditions.0.value']", "800000")
    page.keyboard.press("Tab")
    page.click("#btn-preview"); page.wait_for_selector("#panes table.grid")
    assert page.locator("#panes table.grid tr").count() == 1 + 1     # header + the one location with BuildingTIV = 800000
    # container grows when a member is dragged beyond its edge
    page.evaluate("view = {x: 20, y: 20, scale: 1}; applyView(); multi = new Set(['sov_main', 'sov_extra']); selected = null; renderInspector(); render()")
    page.keyboard.press("Control+g"); page.wait_for_selector(".container"); page.keyboard.press("Tab")
    w0 = page.evaluate("graph.containers[0].ui.w")
    page.evaluate("nodeById('sov_extra').ui.x += 100; updateMembership(['sov_extra']); render()")   # centre still inside -> box grows
    assert page.evaluate("graph.containers[0].ui.w") > w0 and page.evaluate("graph.containers[0].nodes.length") == 2
    page.click(".container .chead"); page.click("#c-fit")
    assert page.evaluate("graph.containers[0].ui.w") == 100 + 180 + 40
    # marquee fully around the container (and nothing else) selects it
    page.evaluate("nodeById('stack').ui.x = 900; nodeById('tidy_numbers').ui.x = 1100; render()")
    c = page.locator("#canvas").bounding_box()
    page.mouse.move(c["x"] + 10, c["y"] + 10); page.mouse.down(); page.mouse.move(c["x"] + 700, c["y"] + 400, steps=5); page.mouse.up()
    assert page.evaluate("selectedContainer") == "c1"
    # the Run button turns into Cancel while a job runs, and back
    page.keyboard.press("Escape")
    page.evaluate("graph.run_outputs = false")            # dry run: nothing written
    page.click("#btn-run")
    page.wait_for_function("document.querySelector('#btn-run').textContent === 'Run' && document.querySelector('#status').textContent.includes('complete')", timeout=30000)
    assert "s." in page.inner_text("#panes") or "Done" in page.inner_text("#panes")
    assert not page.errors


def test_run_error_highlights_upstream_culprit(page, tmp_path):
    _open_example(page)
    page.evaluate(f"graph.nodes.filter(n => n.type === 'output').forEach(n => n.config.path = '{tmp_path.as_posix()}/' + n.config.path.split('/').pop())")
    # break the 'derive' Formula: reference a column that does not exist; the error is raised at an Output
    page.evaluate("graph.nodes.find(n => n.id === 'derive').config.columns[0].formula = '[NoSuchColumn] * 2'")
    page.click("#btn-run")
    page.wait_for_selector(".node.failed[data-id='derive']", timeout=30000)
    assert page.locator(".node.surfaced").count() == 1          # the Output that raised is marked lighter
    status = page.locator("#status").text_content()
    assert "formula 'derive'" in status and "NoSuchColumn" in status
    assert not page.errors


def test_nested_containers(page):
    _open_example(page)
    page.evaluate("view = {x: 20, y: 20, scale: 1}; applyView()")
    # inner group: the two inputs
    page.evaluate("multi = new Set(['sov_main', 'sov_extra']); selected = null; renderInspector(); render()")
    page.keyboard.press("Control+g"); page.wait_for_selector(".container"); page.keyboard.press("Escape")
    inner = page.evaluate("graph.containers[0].id")
    # outer group: the inner container's tools plus 'stack' -> nests rather than stealing the inner container's members
    page.evaluate("multi = new Set(['sov_main', 'sov_extra', 'stack']); selected = null; selectedContainer = null; renderInspector(); render()")
    page.keyboard.press("Control+g"); page.wait_for_function("graph.containers.length === 2"); page.keyboard.press("Escape")
    outer = page.evaluate(f"graph.containers.find(c => c.id !== {inner!r}).id")
    assert page.evaluate(f"containerById({inner!r}).nodes.length") == 2   # inner keeps just its own two
    assert page.evaluate(f"containerById({outer!r}).nodes.length") == 3   # outer lists all three (nested ones included)
    assert page.evaluate(f"childContainers(containerById({outer!r})).map(c => c.id)") == [inner]
    assert page.evaluate(f"parentContainer(containerById({inner!r})).id") == outer
    # a node is off if either its own container or an ancestor container is off
    page.evaluate(f"setContainerEnabled({outer!r}, false)")
    page.wait_for_selector(".node.off[data-id='sov_main']")
    assert page.evaluate("disabledNodes().has('sov_main') && disabledNodes().has('stack')")
    page.evaluate(f"setContainerEnabled({outer!r}, true)")
    # dragging the outer container's header carries the nested container and its members along
    page.wait_for_timeout(1000)
    x0 = page.evaluate(f"containerById({inner!r}).ui.x")
    outer_head = page.evaluate(f"document.querySelector('.container[data-cid=\"{outer}\"] .chead').getBoundingClientRect().toJSON()")
    # click past the inner container's header, which overlaps the left part of the outer one (same top-left corner)
    gx = outer_head["x"] + outer_head["width"] - 20
    page.mouse.move(gx, outer_head["y"] + 8); page.mouse.down()
    page.mouse.move(gx + 100, outer_head["y"] + 8, steps=5); page.mouse.up()
    assert page.evaluate(f"containerById({inner!r}).ui.x") == x0 + 100
    assert not page.errors


def test_context_menu_node_and_canvas(page):
    _open_example(page)
    page.click(".node[data-id='derive'] .head", button="right")
    page.wait_for_selector(".ctxmenu")
    assert "derive" in page.inner_text(".ctxmenu .head").lower()
    labels = page.locator(".ctxmenu .item span:first-child").all_inner_texts()
    assert "Duplicate" in labels and "Delete" in labels and "Pin preview here" in labels
    n0 = page.locator(".node").count()
    page.click(".ctxmenu .item:has-text('Duplicate')")
    page.wait_for_function(f"document.querySelectorAll('.node').length == {n0 + 1}")
    assert page.evaluate("!document.querySelector('.ctxmenu')")   # closes after an action
    # canvas empty-space menu offers paste / add note
    page.click("#canvas", position={"x": 700, "y": 500}, button="right")
    page.wait_for_selector(".ctxmenu")
    assert "Add note here" in page.inner_text(".ctxmenu")
    page.keyboard.press("Escape")
    assert not page.errors


def test_recent_files_and_json_drop(page, tmp_path):
    _open_example(page)
    p = tmp_path / "recent_test.json"
    page.fill("#modal-input", "") if False else None
    page.click("#btn-saveas")
    page.wait_for_selector("#modal"); page.fill("#modal-input", str(p)); page.click("#modal-ok")
    page.wait_for_function("document.querySelector('#status').textContent.includes('Saved')")
    recent = page.evaluate("recentList()")
    assert recent and recent[0]["path"] == str(p)
    page.click("#btn-recent")
    page.wait_for_selector(".ctxmenu")
    assert "recent_test.json" in page.inner_text(".ctxmenu")
    page.keyboard.press("Escape")
    # dropping a .json workflow programmatically opens it rather than creating an Input node
    n0 = page.locator(".node").count()
    page.evaluate(f"openDroppedWorkflow({{name: 'recent_test.json', pywebviewFullPath: {str(p)!r}}})")
    page.wait_for_function("currentPath !== null")
    assert page.evaluate("currentPath").endswith("recent_test.json")
    assert not page.errors


def test_preview_grid_sort_copy_and_pin(page):
    _open_example(page)
    page.click(".node[data-id='derive'] .head")
    page.click("#btn-preview")
    page.wait_for_selector("#panes table.grid")
    header = page.locator("#panes th.sortable").first
    header.click()
    assert page.evaluate("preview.sortCol") == 0 and page.evaluate("preview.dir") == 1
    header.click()
    assert page.evaluate("preview.dir") == -1
    cell = page.locator("#panes td.copyable").first
    cell.click()
    page.wait_for_function("document.querySelector('#status').textContent.length > 0")
    assert "Copied" in page.locator("#status").text_content() or "Clipboard" in page.locator("#status").text_content()
    # pin follows edits to an upstream node
    page.click("#btn-pin")
    assert page.evaluate("pinned") == "derive"
    assert "Unpin" in page.inner_text("#btn-pin")
    page.evaluate("nodeById('sov_main').config.header_row = 2; onConfigChanged(nodeById('sov_main'), 'header_row', false)")
    page.wait_for_timeout(600)
    assert not page.errors
    page.click("#btn-pin")
    assert page.evaluate("pinned") is None
