import json

import pytest

from raw2ufs.engine.graph import Graph, GraphError


def test_round_trip_and_topo_order():
    g = Graph(name="t")
    g.add_node("out", "output", {"path": "x.csv"})
    g.add_node("a", "input", {"path": "a.csv"}, name="A", ui={"x": 1})
    g.add_node("b", "sort", {"by": [{"column": "c"}]})
    g.add_edge("a", "b")
    g.add_edge("b", "out")
    assert g.topo_order() == ["a", "b", "out"]
    g2 = Graph.from_json(g.to_json())
    assert g2.to_dict() == g.to_dict()
    assert g2.node("a").ui == {"x": 1}
    assert json.loads(g.to_json())["edges"][0] == {"from": "a", "to": "b"}


def test_named_ports_and_ancestors():
    g = Graph()
    for n in ("l", "r", "z"):
        g.add_node(n, "input", {"path": f"{n}.csv"})
    g.add_node("j", "join", {"keys": [{"left": "k", "right": "k"}]})
    g.add_edge("l", "j", "left")
    g.add_edge("r", "j", "right")
    assert g.inputs_of("j") == {"left": ["l"], "right": ["r"]}
    assert g.ancestors("j") == ["l", "r", "j"]


def test_cycle_and_dangling_edges():
    g = Graph()
    g.add_node("a", "sort"); g.add_node("b", "sort")
    g.add_edge("a", "b"); g.add_edge("b", "a")
    with pytest.raises(GraphError, match="cycle"):
        g.topo_order()
    g = Graph()
    g.add_node("a", "sort")
    g.add_edge("a", "ghost")
    with pytest.raises(GraphError, match="unknown node"):
        g.topo_order()


def test_var_names_are_valid_python():
    g = Graph()
    g.add_node("1st node-é", "input")
    assert g.node("1st node-é").var.isidentifier()


def test_containers_round_trip_and_disable_propagation():
    g = Graph()
    for n in ("a", "b", "c", "d", "x"):
        g.add_node(n, "sort", {"by": [{"column": "k"}]})
    g.add_edge("a", "b"); g.add_edge("b", "c"); g.add_edge("c", "d"); g.add_edge("x", "d")
    g.add_container("c1", "Middle", ["b"], "blue", enabled=False, ui={"x": 0, "y": 0, "w": 100, "h": 50})
    assert g.disabled_nodes() == {"b", "c", "d"}          # b off, c and d downstream; a and x untouched
    g2 = Graph.from_json(g.to_json())
    assert g2.containers[0].name == "Middle" and not g2.containers[0].enabled and g2.container_of("b").id == "c1"
    g2.containers[0].enabled = True
    assert g2.disabled_nodes() == set()
    with pytest.raises(GraphError, match="duplicate container"):
        g.add_container("c1")
