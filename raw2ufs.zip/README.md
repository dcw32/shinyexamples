# Raw2UFS

A low-code workflow engine for turning raw schedules of values (Excel, CSV,
Parquet, GeoParquet, lookups) into OED / UFS exposure files. This repository is
the **engine and node library** — the drag-and-drop front end sits on top of it
and talks to it only through JSON, so it can be swapped or rebuilt later.

## The three ideas

**1. A workflow is a JSON file.** Nodes with a type and a config, edges between
ports. The UI edits that JSON; the engine runs it; the exporter turns it into a
script. Saved workflows are reusable "client X mapping" templates.

**2. A node emits polars source code — it never runs polars itself.** The
runner `exec`s the emitted code; the exporter writes the same code to a `.py`
file. The app and the exported script cannot disagree because they are the
same code. Adding a tool is one class with an `emit()` method and a list of
config fields, and the UI renders the config panel from those fields.

**3. The exported script is plain polars.** Every block is tagged
`# Raw2UFS_<TOOL>: <node id> "<name>" - <summary>` so an analyst or an AI
assistant can find the tool it came from, edit it in place, or add steps
between blocks. Helper functions (spatial, GeoParquet) are inlined; the script
needs only polars (+ fastexcel / shapely where used).

## Quick start

```bash
pip install -e ".[spatial,excel-out,ui,dev]"
python examples/make_sample_data.py          # messy sample inputs
python -m ui                                 # desktop app (pywebview); or:
python -m ui --serve                         # same UI at http://127.0.0.1:8765 in a browser
python -m raw2ufs validate examples/sov_to_oed.json
python -m raw2ufs schema   examples/sov_to_oed.json derive      # columns/types at a node, no data read
python -m raw2ufs preview  examples/sov_to_oed.json map_occ -n 5
python -m raw2ufs run      examples/sov_to_oed.json             # writes examples/output/*
python -m raw2ufs run      examples/sov_to_oed.json --set Client=acme   # override a workflow constant
python -m raw2ufs export   examples/sov_to_oed.json -o examples/sov_to_oed.py
python examples/sov_to_oed.py                                   # same result, no raw2ufs needed
python -m raw2ufs docs -o docs/tools.md                         # tool reference (skill source)
python -m raw2ufs nodes                                         # node catalogue as JSON for a UI
pytest                                                          # engine tests + headless browser UI tests
```

Relative paths in a workflow resolve next to the workflow file, so
`examples/sov_to_oed.json` refers to `data/...` and `output/...`.

## The front end

![Raw2UFS UI](docs/ui.png)

`ui/index.html` is a single self-contained page (no framework, no build step):
a tool palette, a pan/zoom canvas with drag-to-wire ports, an inspector whose
config panel is generated from each tool's field specs, and a bottom pane with
data preview, column profile, schema, run log and the exported script.
Column pickers are fed by the engine's schema resolution, so they always list
what is actually upstream. Excel inputs get a sheet picker with the first rows
shown so the header row / cell range can be clicked rather than guessed;
Select can infer column types from the data; *Run to here* caches a node's
result (a parquet file keyed on everything upstream, so it self-invalidates)
and later previews start from the cache instead of re-reading the inputs.
Drop a data file on the canvas to create an Input, or a saved workflow
(`.json`) to open it in a new tab. Drag on empty canvas to rubber-band select
(Shift adds), then move, Delete, Ctrl+D duplicate or Ctrl+C/V copy-paste the
group with its internal connections; Ctrl+Z / Ctrl+Y undo and redo; Ctrl+G
wraps the selection in a named, coloured **container** that can be switched
off (its tools and everything downstream are skipped and exported as
commented-out blocks) - containers can **nest** (drag the outer one's header
to carry inner ones along, group a selection an existing container already
encloses to grow around it instead of stealing its tools); `/` searches the
palette; scroll pans, Ctrl+scroll zooms, middle-drag or Space+drag pans;
Ctrl+S saves and unsaved changes are guarded. **Right-click** a tool,
container, connection or empty canvas for a context menu (preview, profile,
run to here, pin, duplicate, delete, group/ungroup, remove from container,
paste at point, add a note, open recent). A **recent-files list** lives under
the toolbar dropdown and the canvas menu's "Open recent…". The preview grid
supports **column sort** (click a header; client-side, no re-fetch), **copy
cell**, and **show more rows**; **Pin** keeps the bottom preview on a chosen
tool so it refreshes automatically as you edit anything upstream of it. Dark
mode follows the OS and can be toggled (☾/☀). Several workflows can be open
in tabs (Ctrl+Tab switches); each Output tool has its own on/off switch and
the toolbar can switch all outputs off for a dry run. Runs happen on a worker
thread with a live log (with warnings under the tool that raised them) and
per-tool timings; the Run button becomes Cancel while one is in flight. A run
error is attributed to the tool actually at fault even when it only surfaces
downstream (lazy polars), and marks both on the canvas. It talks to
`ui/api.py` either through pywebview's JS bridge (`python -m ui`) or the
stdlib HTTP server (`python -m ui --serve`); the same `Api` methods are the
contract for any future front end.

## Layout

```
raw2ufs/
  engine/     graph.py (JSON model, topo order)  registry.py (Node base, Field, @node)
              runner.py (compile -> exec; run / preview / schema)  dtypes.py
              cache.py (run-to-here parquet cache)  analysis.py (type inference, profiles)
  formula/    lexer.py  parser.py  ast.py  emit.py   - the formula language -> polars source
  nodes/      io.py  prepare.py  combine.py  reshape.py  spatial.py  annotate.py
  export/     to_script.py (standalone script)  docs.py (tool reference markdown)
  helpers.py  functions inlined into exported scripts
  cli.py
ui/           index.html (canvas app)  api.py (JSON contract)  app.py (pywebview)  server.py (dev http)
examples/     sov_to_oed.json + sample data generator
tests/        per-node tests, engine-vs-exported-script golden test, playwright UI smoke test
docs/         OVERVIEW.md (human guide + how to add a tool)  CODEBASE.md (machine-oriented summary)
              tools.md (generated reference)  TODO.md (open work and ideas)  ui.png
```

## Tools (v0.1)

Input (CSV / Excel with sheet + cell range / Parquet / GeoParquet), Output
(CSV / Excel / Parquet / GeoParquet, with an OED format tag and an on/off
switch), Select (keep / rename / type), Select Records (row ranges), Cleanse, Dynamic Rename (names
from the first row, prefix/suffix), Text To Columns (to columns or rows),
Filter (simple or formula), Formula, Multi-Field Formula (`[_CurrentField_]`),
Record ID (optionally per group), Sort, Unique, Join (with `Right_` clash
prefix and output-field selection), Union, Append Fields (cartesian), Summarise,
Transpose (wide→long), Cross Tab (long→wide), Create Points, Spatial Match
(point-in-polygon via shapely STRtree), Comment (a note that is written into
the exported script).

## Formula language

Alteryx-style, for Formula and Filter tools:

```
IF [TIV] > 1000000 AND [Country] = 'SE' THEN 'Large' ELSEIF [TIV] > 100000 THEN 'Mid' ELSE 'Small' ENDIF
IfNull(ToNumber(Replace([Building (kSEK)], ' ', '')), 0) * 1000
Upper(Trim([Occupancy])) IN ('OFFICE', 'RETAIL')
```

`[Column]` references, `[$Constant]` references, `+ - * / % ^`, `= <> < <= > >=`,
`AND OR NOT`, `IN (...)`, single-quoted text, `IIF(cond, x, y)`,
`Switch(value, default, case1, result1, ...)` and the functions listed in
`docs/tools.md`. Formulas are parsed to an AST and emitted as polars
expressions — no `eval` of user text.

## Constants and paths

A workflow can carry named constants (toolbar → Constants): `[$Scale]` in
formulas, `${Client}` inside file paths and text options. They are written as
`K_Scale = 1000` at the top of the exported script and can be overridden on the
CLI: `python -m raw2ufs run wf.json --set Client=acme`. Relative paths resolve
against `BASE_DIR` — the workflow's folder in the app and CLI, the script's own
folder once exported — never against the process working directory, so several
workflows can be open in tabs at once.

## Adding a tool

```python
from raw2ufs.engine.registry import Field, Node, lit, node

@node
class Head(Node):
    type = "head"
    category = "Prepare"
    description = "Keep the first N rows."
    fields = [Field("n", "int", default=100, required=True)]

    def summary(self, cfg): return f"first {cfg['n']} rows"
    def emit(self, cfg, ins, out): return f"{out} = {ins['in']}.head({int(cfg['n'])})\n"
```

Import the module before compiling a graph and it appears in the catalogue,
the docs, and the exported scripts. Functions that must be inlined into scripts
go in `helpers.py` and are listed in the node's `helpers`.

## Workflow JSON

```json
{
  "version": 1,
  "name": "Client X - SOV to OED",
  "nodes": [
    {"id": "sov", "type": "input", "name": "Main SOV", "config": {"path": "sov.xlsx", "header_row": 2, "all_strings": true}},
    {"id": "out", "type": "output", "config": {"path": "location.csv", "format_tag": "OED-Loc"}}
  ],
  "edges": [{"from": "sov", "to": "out"}]
}
```

Edges name the target port when a node has several (`"to_port": "left"` /
`"right"` for Join, `"points"` / `"polygons"` for Spatial Match). Relative
paths resolve next to the workflow file (the CLI and the UI both switch the
working directory to it; exported scripts do the same relative to themselves).
`ui` on a node is reserved for the front end. An optional `containers` list
groups nodes (`{id, name, color, enabled, nodes, ui}`); a disabled container
switches its nodes and their descendants off.

## Building the Windows app

```bat
pip install -e ".[spatial,excel-out,ui,build]"
build.bat                      # = python -m PyInstaller raw2ufs.spec --noconfirm
dist\Raw2UFS\Raw2UFS.exe        # desktop app;  Raw2UFS.exe --serve  for browser mode
dist\Raw2UFS\raw2ufs-cli.exe run examples\sov_to_oed.json
```

`raw2ufs.spec` produces a one-folder build (faster start-up and friendlier to
antivirus than one-file) with two executables sharing one `_internal/`: a
windowed `Raw2UFS.exe` and a console `raw2ufs-cli.exe`. The desktop window
needs the Edge WebView2 runtime, which Windows 10/11 already have. Expect
roughly 250-300 MB, most of it polars. `build.sh` does the same on Linux/macOS.

## Roadmap

See `docs/TODO.md` for the full list. Highlights:

- Front end polish: resizable panes, align/distribute selection, container auto-fit.
- SQL input connector (`pl.read_database`) — one more `Input` format.
- Column mapper with fuzzy / LLM-assisted suggestions against the OED field list.
- OED validator as an external script over the tagged output files.
- PyInstaller packaging for Windows.
