"""Single entry point for the packaged app.

    Raw2UFS.exe                    desktop window (pywebview)
    Raw2UFS.exe --serve [--port N] browser mode at http://127.0.0.1:N
    raw2ufs-cli.exe run wf.json    any CLI command (run, export, validate, schema, preview, nodes, docs)
"""

from __future__ import annotations

import multiprocessing
import sys

CLI_COMMANDS = {"run", "export", "validate", "schema", "preview", "nodes", "docs"}


def main() -> int:
    multiprocessing.freeze_support()
    import warnings
    warnings.filterwarnings("ignore", category=FutureWarning, module="polars")   # fastexcel/arrow deprecation chatter
    args = sys.argv[1:]
    if args and args[0] in CLI_COMMANDS:
        from raw2ufs.cli import main as cli_main
        return cli_main(args)
    if "--serve" in args:
        from ui.server import serve
        port = 8765
        if "--port" in args:
            port = int(args[args.index("--port") + 1])
        serve(port=port)
        return 0
    if args and args[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    from ui.app import main as ui_main
    ui_main(debug="--debug" in args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
