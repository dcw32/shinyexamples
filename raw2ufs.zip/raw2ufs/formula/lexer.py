from __future__ import annotations

import re
from dataclasses import dataclass


class FormulaError(ValueError):
    def __init__(self, message: str, pos: int | None = None):
        self.pos = pos
        super().__init__(message if pos is None else f"{message} (at position {pos})")


@dataclass(frozen=True)
class Token:
    kind: str    # NUMBER STRING COLUMN CONST IDENT KEYWORD OP LPAREN RPAREN COMMA EOF
    value: str
    pos: int


KEYWORDS = {"IF", "THEN", "ELSEIF", "ELSE", "ENDIF", "AND", "OR", "NOT", "NULL", "TRUE", "FALSE", "IN"}

# Longest operators first so `<=` wins over `<`.
_OPS = ["<>", "<=", ">=", "==", "!=", "=", "<", ">", "+", "-", "*", "/", "%", "^"]

_TOKEN_RE = re.compile(r"""
    (?P<ws>\s+)
  | (?P<number>\d+(?:\.\d*)?(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?)
  | (?P<string>'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*")
  | (?P<const>\[\$[A-Za-z_][A-Za-z0-9_]*\])
  | (?P<column>\[[^\]]+\])
  | (?P<ident>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op>""" + "|".join(re.escape(o) for o in _OPS) + r""")
  | (?P<lparen>\()
  | (?P<rparen>\))
  | (?P<comma>,)
""", re.VERBOSE)


def tokenize(text: str) -> list[Token]:
    tokens: list[Token] = []
    pos = 0
    n = len(text)
    while pos < n:
        m = _TOKEN_RE.match(text, pos)
        if not m:
            raise FormulaError(f"unexpected character {text[pos]!r}", pos)
        kind = m.lastgroup
        raw = m.group()
        if kind == "ws":
            pass
        elif kind == "number":
            tokens.append(Token("NUMBER", raw, pos))
        elif kind == "string":
            inner = raw[1:-1].replace("\\'", "'").replace('\\"', '"').replace("\\\\", "\\")
            tokens.append(Token("STRING", inner, pos))
        elif kind == "const":
            tokens.append(Token("CONST", raw[2:-1], pos))
        elif kind == "column":
            tokens.append(Token("COLUMN", raw[1:-1], pos))
        elif kind == "ident":
            up = raw.upper()
            tokens.append(Token("KEYWORD" if up in KEYWORDS else "IDENT", up if up in KEYWORDS else raw, pos))
        elif kind == "op":
            tokens.append(Token("OP", raw, pos))
        elif kind == "lparen":
            tokens.append(Token("LPAREN", raw, pos))
        elif kind == "rparen":
            tokens.append(Token("RPAREN", raw, pos))
        elif kind == "comma":
            tokens.append(Token("COMMA", raw, pos))
        pos = m.end()
    tokens.append(Token("EOF", "", pos))
    return tokens
