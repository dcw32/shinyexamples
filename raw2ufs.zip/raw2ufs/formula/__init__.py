"""Raw2UFS formula language.

An Alteryx-flavoured expression syntax that non-programmers can learn in a
few minutes, e.g.

    IF [TIV] > 1000000 AND [Country] = 'SE' THEN 'Large' ELSE 'Small' ENDIF
    Round([Building] * 1000, 0) + IfNull([Contents], 0)
    Upper(Trim([Occupancy]))

Pipeline:  text --lexer--> tokens --parser--> AST --emit--> polars source
The polars source string is what goes into emitted node code, so the app and
the exported script evaluate exactly the same expression.
"""

from raw2ufs.formula.parser import FormulaError, parse  # noqa: F401
from raw2ufs.formula.emit import to_polars_source, compile_formula, FUNCTIONS  # noqa: F401
