"""AST -> polars source code.

`to_polars_source` returns a Python expression string such as
    pl.when((pl.col("A") > pl.col("B"))).then(1).otherwise(0)
that evaluates to a `pl.Expr` in a namespace where `pl` is polars.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import polars as pl

from raw2ufs.formula import ast
from raw2ufs.formula.lexer import FormulaError
from raw2ufs.formula.parser import parse

# ---------------------------------------------------------------------------
# Function table.  Each entry renders already-emitted argument sources.
# `E(src)` guarantees the source is a pl.Expr (wraps literals in pl.lit).
# ---------------------------------------------------------------------------

Src = tuple[str, bool]   # (source, is_expr)


def _lit(src: Src) -> str:
    return src[0] if src[1] else f"pl.lit({src[0]})"


@dataclass
class Func:
    name: str
    signature: str
    description: str
    min_args: int
    max_args: int | None
    render: Callable[[list[Src]], str]


FUNCTIONS: dict[str, Func] = {}


def _fn(name: str, signature: str, description: str, min_args: int, max_args: int | None = None):
    def deco(render: Callable[[list[Src]], str]):
        FUNCTIONS[name] = Func(name, signature, description, min_args,
                               min_args if max_args is None else max_args, render)
        return render
    return deco


def _raw(src: Src) -> str:
    """Argument passed through as a plain python value/expr (e.g. counts, patterns)."""
    return src[0]


# ---- strings ---------------------------------------------------------------
_fn("upper", "Upper(text)", "Convert to upper case.", 1)(lambda a: f"{_lit(a[0])}.str.to_uppercase()")
_fn("lower", "Lower(text)", "Convert to lower case.", 1)(lambda a: f"{_lit(a[0])}.str.to_lowercase()")
_fn("title", "Title(text)", "Convert to Title Case.", 1)(lambda a: f"{_lit(a[0])}.str.to_titlecase()")
_fn("trim", "Trim(text)", "Remove leading and trailing whitespace.", 1)(lambda a: f"{_lit(a[0])}.str.strip_chars()")
_fn("ltrim", "LTrim(text)", "Remove leading whitespace.", 1)(lambda a: f"{_lit(a[0])}.str.strip_chars_start()")
_fn("rtrim", "RTrim(text)", "Remove trailing whitespace.", 1)(lambda a: f"{_lit(a[0])}.str.strip_chars_end()")
_fn("length", "Length(text)", "Number of characters.", 1)(lambda a: f"{_lit(a[0])}.str.len_chars()")
_fn("left", "Left(text, n)", "First n characters.", 2)(lambda a: f"{_lit(a[0])}.str.slice(0, {_raw(a[1])})")
_fn("right", "Right(text, n)", "Last n characters.", 2)(lambda a: f"{_lit(a[0])}.str.slice(-({_raw(a[1])}))")
_fn("substring", "Substring(text, start, length)", "Characters from 0-based `start`, `length` long.", 3)(
    lambda a: f"{_lit(a[0])}.str.slice({_raw(a[1])}, {_raw(a[2])})")
_fn("contains", "Contains(text, part)", "True if `part` occurs in text (case-sensitive).", 2)(
    lambda a: f"{_lit(a[0])}.str.contains({_raw(a[1])}, literal=True)")
_fn("startswith", "StartsWith(text, prefix)", "True if text starts with prefix.", 2)(
    lambda a: f"{_lit(a[0])}.str.starts_with({_raw(a[1])})")
_fn("endswith", "EndsWith(text, suffix)", "True if text ends with suffix.", 2)(
    lambda a: f"{_lit(a[0])}.str.ends_with({_raw(a[1])})")
_fn("replace", "Replace(text, find, replacement)", "Replace every occurrence of `find` (plain text).", 3)(
    lambda a: f"{_lit(a[0])}.str.replace_all({_raw(a[1])}, {_raw(a[2])}, literal=True)")
_fn("regexreplace", "RegexReplace(text, pattern, replacement)", "Replace every regex match.", 3)(
    lambda a: f"{_lit(a[0])}.str.replace_all({_raw(a[1])}, {_raw(a[2])})")
_fn("regexmatch", "RegexMatch(text, pattern)", "True if the regex matches anywhere in text.", 2)(
    lambda a: f"{_lit(a[0])}.str.contains({_raw(a[1])})")
_fn("padleft", "PadLeft(text, width, char)", "Left-pad with `char` to `width` characters.", 3)(
    lambda a: f"{_lit(a[0])}.str.pad_start({_raw(a[1])}, {_raw(a[2])})")
_fn("padright", "PadRight(text, width, char)", "Right-pad with `char` to `width` characters.", 3)(
    lambda a: f"{_lit(a[0])}.str.pad_end({_raw(a[1])}, {_raw(a[2])})")
_fn("concat", "Concat(a, b, ...)", "Join values as text (null if any part is null).", 1, 99)(
    lambda a: "pl.concat_str([" + ", ".join(_lit(x) for x in a) + "])")

# ---- conversion --------------------------------------------------------------
_fn("tostring", "ToString(value)", "Convert to text.", 1)(lambda a: f"{_lit(a[0])}.cast(pl.String)")
_fn("tonumber", "ToNumber(value)", "Convert to a decimal number; unparseable values become null.", 1)(
    lambda a: f"{_lit(a[0])}.cast(pl.Float64, strict=False)")
_fn("toint", "ToInt(value)", "Convert to a whole number; unparseable values become null.", 1)(
    lambda a: f"{_lit(a[0])}.cast(pl.Float64, strict=False).cast(pl.Int64, strict=False)")
_fn("todate", "ToDate(text, format)", "Parse text to a date using a strftime format such as '%Y-%m-%d'.", 2)(
    lambda a: f"{_lit(a[0])}.str.to_date({_raw(a[1])}, strict=False)")
_fn("todatetime", "ToDateTime(text, format)", "Parse text to a date-time using a strftime format.", 2)(
    lambda a: f"{_lit(a[0])}.str.to_datetime({_raw(a[1])}, strict=False)")

# ---- conditional -------------------------------------------------------------
_fn("iif", "IIF(condition, x, y)", "x where the condition is true, otherwise y (a compact IF ... THEN ... ELSE ... ENDIF).", 3)(
    lambda a: f"pl.when({_lit(a[0])}).then({_lit(a[1])}).otherwise({_lit(a[2])})")


def _switch(a: list[Src]) -> str:
    if len(a) < 4 or len(a) % 2 != 0:
        raise FormulaError("Switch(value, default, case1, result1, ..., caseN, resultN) needs pairs of case/result after the default")
    value, default, pairs = _lit(a[0]), _lit(a[1]), a[2:]
    src = "pl"
    for i in range(0, len(pairs), 2):
        src += f".when({value} == {_raw(pairs[i])}).then({_lit(pairs[i + 1])})"
    return src + f".otherwise({default})"


_fn("switch", "Switch(value, default, case1, result1, ..., caseN, resultN)",
    "Compare `value` with each case in turn and return the matching result; `default` when none match.", 4, 99)(_switch)

# ---- nulls -------------------------------------------------------------------
_fn("isnull", "IsNull(value)", "True where the value is null.", 1)(lambda a: f"{_lit(a[0])}.is_null()")
_fn("isempty", "IsEmpty(value)", "True where the value is null or an empty string.", 1)(
    lambda a: f"({_lit(a[0])}.is_null() | ({_lit(a[0])}.cast(pl.String) == ''))")
_fn("ifnull", "IfNull(value, fallback)", "The value, or `fallback` where it is null.", 2)(
    lambda a: f"pl.coalesce([{_lit(a[0])}, {_lit(a[1])}])")
_fn("coalesce", "Coalesce(a, b, ...)", "First non-null value.", 1, 99)(
    lambda a: "pl.coalesce([" + ", ".join(_lit(x) for x in a) + "])")
_fn("null", "Null()", "A null value.", 0)(lambda a: "pl.lit(None)")

# ---- maths -------------------------------------------------------------------
_fn("abs", "Abs(x)", "Absolute value.", 1)(lambda a: f"{_lit(a[0])}.abs()")
_fn("round", "Round(x, decimals)", "Round to `decimals` places (default 0).", 1, 2)(
    lambda a: f"{_lit(a[0])}.round({_raw(a[1]) if len(a) > 1 else 0})")
_fn("floor", "Floor(x)", "Round down.", 1)(lambda a: f"{_lit(a[0])}.floor()")
_fn("ceil", "Ceil(x)", "Round up.", 1)(lambda a: f"{_lit(a[0])}.ceil()")
_fn("sqrt", "Sqrt(x)", "Square root.", 1)(lambda a: f"{_lit(a[0])}.sqrt()")
_fn("pow", "Pow(x, y)", "x to the power y.", 2)(lambda a: f"{_lit(a[0])}.pow({_raw(a[1])})")
_fn("mod", "Mod(x, y)", "Remainder of x / y.", 2)(lambda a: f"({_lit(a[0])} % {_raw(a[1])})")
_fn("min", "Min(a, b, ...)", "Smallest of the values, per row.", 1, 99)(
    lambda a: "pl.min_horizontal([" + ", ".join(_lit(x) for x in a) + "])")
_fn("max", "Max(a, b, ...)", "Largest of the values, per row.", 1, 99)(
    lambda a: "pl.max_horizontal([" + ", ".join(_lit(x) for x in a) + "])")

# ---- dates -------------------------------------------------------------------
_fn("year", "Year(date)", "Year of a date.", 1)(lambda a: f"{_lit(a[0])}.dt.year()")
_fn("month", "Month(date)", "Month of a date (1-12).", 1)(lambda a: f"{_lit(a[0])}.dt.month()")
_fn("day", "Day(date)", "Day of month.", 1)(lambda a: f"{_lit(a[0])}.dt.day()")
_fn("datediffdays", "DateDiffDays(later, earlier)", "Whole days between two dates.", 2)(
    lambda a: f"({_lit(a[0])} - {_lit(a[1])}).dt.total_days()")


# ---------------------------------------------------------------------------
# Emitter
# ---------------------------------------------------------------------------

_BIN_OPS = {
    "+": "+", "-": "-", "*": "*", "/": "/", "%": "%",
    "=": "==", "<>": "!=", "<": "<", "<=": "<=", ">": ">", ">=": ">=",
    "AND": "&", "OR": "|",
}


def _emit(e: ast.Expr) -> Src:
    if isinstance(e, ast.Number):
        return repr(e.value), False
    if isinstance(e, ast.String):
        return repr(e.value), False
    if isinstance(e, ast.Bool):
        return repr(e.value), False
    if isinstance(e, ast.Null):
        return "pl.lit(None)", True
    if isinstance(e, ast.Column):
        return f"pl.col({e.name!r})", True
    if isinstance(e, ast.Const):
        return f"pl.lit(K_{e.name})", True
    if isinstance(e, ast.Unary):
        inner = _emit(e.operand)
        if e.op == "NOT":
            return f"(~{_lit(inner)})", True
        return f"(-{_lit(inner)})", True
    if isinstance(e, ast.Binary):
        left, right = _emit(e.left), _emit(e.right)
        if e.op == "^":
            return f"{_lit(left)}.pow({right[0]})", True
        # at least one side must be a pl.Expr so the python operator dispatches to polars
        lsrc = left[0] if (left[1] or right[1]) else _lit(left)
        return f"({lsrc} {_BIN_OPS[e.op]} {right[0]})", True
    if isinstance(e, ast.In):
        opts = []
        for o in e.options:
            if isinstance(o, (ast.Number, ast.String, ast.Bool)):
                opts.append(repr(o.value))
            else:
                raise FormulaError("IN (...) options must be plain numbers or text")
        src = f"{_lit(_emit(e.value))}.is_in([{', '.join(opts)}])"
        return (f"(~{src})" if e.negated else src), True
    if isinstance(e, ast.Call):
        fn = FUNCTIONS.get(e.name)
        if fn is None:
            raise FormulaError(f"unknown function {e.name!r}")
        if len(e.args) < fn.min_args or (fn.max_args is not None and len(e.args) > fn.max_args):
            raise FormulaError(f"{fn.signature} takes {fn.min_args}"
                               + ("" if fn.max_args == fn.min_args else f"-{fn.max_args}")
                               + f" arguments, got {len(e.args)}")
        return fn.render([_emit(a) for a in e.args]), True
    if isinstance(e, ast.If):
        parts = []
        for cond, val in e.branches:
            parts.append(f"when({_lit(_emit(cond))})")
            parts.append(f"then({_lit(_emit(val))})")
        parts.append(f"otherwise({_lit(_emit(e.otherwise))})")
        return "pl." + ".".join(parts), True
    raise FormulaError(f"cannot emit {type(e).__name__}")


def to_polars_source(text: str) -> str:
    """Formula text -> polars expression source (always a pl.Expr)."""
    return _lit(_emit(parse(text)))


def compile_formula(text: str, constants: dict | None = None) -> pl.Expr:
    """Formula text -> live pl.Expr (used by the app for validation/preview)."""
    src = to_polars_source(text)
    ns = {"pl": pl}
    for k, v in (constants or {}).items():
        ns[f"K_{k}"] = v
    return eval(src, ns)  # noqa: S307 - source generated by our own emitter
