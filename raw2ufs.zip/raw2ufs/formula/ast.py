from __future__ import annotations

from dataclasses import dataclass, field


class Expr:
    pass


@dataclass
class Number(Expr):
    value: float | int


@dataclass
class String(Expr):
    value: str


@dataclass
class Bool(Expr):
    value: bool


@dataclass
class Null(Expr):
    pass


@dataclass
class Column(Expr):
    name: str


@dataclass
class Const(Expr):
    name: str        # workflow constant, written [$Name]


@dataclass
class Unary(Expr):
    op: str          # "-" or "NOT"
    operand: Expr


@dataclass
class Binary(Expr):
    op: str          # + - * / % ^  = <> < <= > >=  AND OR
    left: Expr
    right: Expr


@dataclass
class In(Expr):
    value: Expr
    options: list[Expr]
    negated: bool = False


@dataclass
class Call(Expr):
    name: str        # lower-cased function name
    args: list[Expr] = field(default_factory=list)


@dataclass
class If(Expr):
    branches: list[tuple[Expr, Expr]]   # (condition, value) for IF and each ELSEIF
    otherwise: Expr


def columns_used(expr: Expr) -> list[str]:
    """Distinct column names referenced by an expression, in first-seen order."""
    seen: list[str] = []

    def walk(e: Expr) -> None:
        if isinstance(e, Column):
            if e.name not in seen:
                seen.append(e.name)
        elif isinstance(e, Unary):
            walk(e.operand)
        elif isinstance(e, Binary):
            walk(e.left); walk(e.right)
        elif isinstance(e, In):
            walk(e.value)
            for o in e.options:
                walk(o)
        elif isinstance(e, Call):
            for a in e.args:
                walk(a)
        elif isinstance(e, If):
            for c, v in e.branches:
                walk(c); walk(v)
            walk(e.otherwise)

    walk(expr)
    return seen
