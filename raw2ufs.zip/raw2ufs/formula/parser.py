"""Recursive-descent parser for the Raw2UFS formula language.

Precedence (lowest to highest):
    OR
    AND
    NOT
    comparison  = == <> != < <= > >=  IN (...)
    + -
    * / %
    unary -
    ^
    primary: number, 'string', [Column], [$Constant], NULL, TRUE, FALSE, Func(args), (expr),
             IF c THEN v [ELSEIF c THEN v]* ELSE v ENDIF
"""

from __future__ import annotations

from raw2ufs.formula import ast
from raw2ufs.formula.lexer import FormulaError, Token, tokenize

_COMPARE = {"=", "==", "<>", "!=", "<", "<=", ">", ">="}


class _Parser:
    def __init__(self, tokens: list[Token]):
        self.toks = tokens
        self.i = 0

    # ---- token helpers --------------------------------------------------------
    @property
    def cur(self) -> Token:
        return self.toks[self.i]

    def advance(self) -> Token:
        t = self.toks[self.i]
        self.i += 1
        return t

    def at(self, kind: str, value: str | None = None) -> bool:
        t = self.cur
        return t.kind == kind and (value is None or t.value == value)

    def expect(self, kind: str, value: str | None = None) -> Token:
        if not self.at(kind, value):
            want = value or kind.lower()
            got = self.cur.value or "end of formula"
            raise FormulaError(f"expected {want!r} but found {got!r}", self.cur.pos)
        return self.advance()

    # ---- grammar --------------------------------------------------------------
    def parse(self) -> ast.Expr:
        e = self.or_expr()
        if not self.at("EOF"):
            raise FormulaError(f"unexpected {self.cur.value!r}", self.cur.pos)
        return e

    def or_expr(self) -> ast.Expr:
        left = self.and_expr()
        while self.at("KEYWORD", "OR"):
            self.advance()
            left = ast.Binary("OR", left, self.and_expr())
        return left

    def and_expr(self) -> ast.Expr:
        left = self.not_expr()
        while self.at("KEYWORD", "AND"):
            self.advance()
            left = ast.Binary("AND", left, self.not_expr())
        return left

    def not_expr(self) -> ast.Expr:
        if self.at("KEYWORD", "NOT"):
            self.advance()
            return ast.Unary("NOT", self.not_expr())
        return self.comparison()

    def comparison(self) -> ast.Expr:
        left = self.additive()
        if self.at("OP") and self.cur.value in _COMPARE:
            op = self.advance().value
            op = {"==": "=", "!=": "<>"}.get(op, op)
            return ast.Binary(op, left, self.additive())
        negated = False
        if self.at("KEYWORD", "NOT") and self.toks[self.i + 1].kind == "KEYWORD" \
                and self.toks[self.i + 1].value == "IN":
            self.advance()
            negated = True
        if self.at("KEYWORD", "IN"):
            self.advance()
            self.expect("LPAREN")
            options = [self.or_expr()]
            while self.at("COMMA"):
                self.advance()
                options.append(self.or_expr())
            self.expect("RPAREN")
            return ast.In(left, options, negated)
        if negated:
            raise FormulaError("expected IN after NOT", self.cur.pos)
        return left

    def additive(self) -> ast.Expr:
        left = self.multiplicative()
        while self.at("OP") and self.cur.value in ("+", "-"):
            op = self.advance().value
            left = ast.Binary(op, left, self.multiplicative())
        return left

    def multiplicative(self) -> ast.Expr:
        left = self.unary()
        while self.at("OP") and self.cur.value in ("*", "/", "%"):
            op = self.advance().value
            left = ast.Binary(op, left, self.unary())
        return left

    def unary(self) -> ast.Expr:
        if self.at("OP", "-"):
            self.advance()
            return ast.Unary("-", self.unary())
        if self.at("OP", "+"):
            self.advance()
            return self.unary()
        return self.power()

    def power(self) -> ast.Expr:
        base = self.primary()
        if self.at("OP", "^"):
            self.advance()
            return ast.Binary("^", base, self.unary())   # right-associative
        return base

    def primary(self) -> ast.Expr:
        t = self.cur
        if t.kind == "NUMBER":
            self.advance()
            txt = t.value
            return ast.Number(float(txt) if any(c in txt for c in ".eE") else int(txt))
        if t.kind == "STRING":
            self.advance()
            return ast.String(t.value)
        if t.kind == "COLUMN":
            self.advance()
            return ast.Column(t.value)
        if t.kind == "CONST":
            self.advance()
            return ast.Const(t.value)
        if t.kind == "KEYWORD":
            if t.value == "NULL":
                self.advance(); return ast.Null()
            if t.value == "TRUE":
                self.advance(); return ast.Bool(True)
            if t.value == "FALSE":
                self.advance(); return ast.Bool(False)
            if t.value == "IF":
                return self.if_expr()
            raise FormulaError(f"unexpected keyword {t.value}", t.pos)
        if t.kind == "IDENT":
            self.advance()
            self.expect("LPAREN")
            args: list[ast.Expr] = []
            if not self.at("RPAREN"):
                args.append(self.or_expr())
                while self.at("COMMA"):
                    self.advance()
                    args.append(self.or_expr())
            self.expect("RPAREN")
            return ast.Call(t.value.lower(), args)
        if t.kind == "LPAREN":
            self.advance()
            e = self.or_expr()
            self.expect("RPAREN")
            return e
        got = t.value or "end of formula"
        raise FormulaError(f"unexpected {got!r}", t.pos)

    def if_expr(self) -> ast.Expr:
        self.expect("KEYWORD", "IF")
        branches = []
        cond = self.or_expr()
        self.expect("KEYWORD", "THEN")
        branches.append((cond, self.or_expr()))
        while self.at("KEYWORD", "ELSEIF"):
            self.advance()
            cond = self.or_expr()
            self.expect("KEYWORD", "THEN")
            branches.append((cond, self.or_expr()))
        self.expect("KEYWORD", "ELSE")
        otherwise = self.or_expr()
        self.expect("KEYWORD", "ENDIF")
        return ast.If(branches, otherwise)


def parse(text: str) -> ast.Expr:
    if not text or not text.strip():
        raise FormulaError("formula is empty")
    return _Parser(tokenize(text)).parse()
