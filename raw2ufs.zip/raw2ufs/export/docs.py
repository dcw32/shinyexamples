"""Generate the tool reference (markdown) from the node registry and formula table.

This is the document that later becomes the analyst/AI skill: one section per
tool with its `# Raw2UFS_<TOOL>` tag, what it does, and every config option.
"""

from __future__ import annotations

from raw2ufs.engine.registry import Field, all_nodes
from raw2ufs.formula.emit import FUNCTIONS


def _field_rows(fields: list[Field], indent: str = "") -> list[str]:
    rows = []
    for f in fields:
        bits = [f"`{f.name}`", f"*{f.kind}*"]
        if f.choices:
            bits.append("one of " + ", ".join(f"`{c}`" for c in f.choices if c != "") + (" or blank" if "" in f.choices else ""))
        if f.default not in (None, "", [], False):
            bits.append(f"default `{f.default}`")
        if f.required:
            bits.append("**required**")
        if f.kind in ("column", "columns") and f.port != "in":
            bits.append(f"from port `{f.port}`")
        line = f"{indent}- " + " - ".join(bits[:1]) + " (" + ", ".join(bits[1:]) + ")"
        if f.help:
            line += f": {f.help}"
        rows.append(line)
        if f.columns:
            rows.append(f"{indent}  Each row has:")
            rows.extend(_field_rows(f.columns, indent + "  "))
    return rows


def tools_markdown() -> str:
    out = ["# Raw2UFS tool reference", "",
           "Every tool in a workflow becomes one code block in the exported script, tagged "
           "`# Raw2UFS_<TOOL>: <node id> \"<node name>\" - <summary>`. Data flows between tools "
           "as polars LazyFrames named `df_<node id>`.", ""]
    current = None
    for cls in all_nodes():
        if cls.category != current:
            current = cls.category
            out += [f"## {current}", ""]
        out += [f"### {cls.label}  `Raw2UFS_{cls.type.upper()}`", "", cls.description, ""]
        ports = ", ".join(f"`{p}`" + (" (many)" if cls.variadic and p == cls.inputs[-1] else "")
                          for p in cls.inputs) or "none"
        out += [f"Input ports: {ports}. " + ("Writes a file; no output." if cls.is_sink else "One output."), ""]
        if cls.fields:
            out += ["Options:", ""] + _field_rows(list(cls.fields)) + [""]
    out += ["## Formula functions", "",
            "Used by **Formula** and **Filter** (formula mode). Column references are written "
            "`[Column Name]`, text in single quotes. Operators: `+ - * / % ^`, comparisons "
            "`= <> < <= > >=`, logic `AND OR NOT`, membership `IN ('a', 'b')`, and "
            "`IF cond THEN a ELSEIF cond THEN b ELSE c ENDIF`. Function names are not case-sensitive.", ""]
    for fn in FUNCTIONS.values():
        out.append(f"- `{fn.signature}` - {fn.description}")
    out.append("")
    return "\n".join(out)
