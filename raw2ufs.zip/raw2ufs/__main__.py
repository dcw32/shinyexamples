from raw2ufs.cli import main

raise SystemExit(main())
