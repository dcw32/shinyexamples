"""Command-line interface.

    python -m raw2ufs run workflow.json [--set Client=Y]
    python -m raw2ufs export workflow.json -o workflow.py
    python -m raw2ufs validate workflow.json
    python -m raw2ufs schema workflow.json [node_id]
    python -m raw2ufs preview workflow.json node_id [-n 20]
    python -m raw2ufs nodes            # node catalogue as JSON (for a front end)
    python -m raw2ufs docs [-o tools.md]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import polars as pl


def _load(path: str, args: argparse.Namespace | None = None):
    """Load a workflow (relative paths resolve next to the file) and apply --set overrides."""
    from raw2ufs.engine.graph import load_graph
    g = load_graph(path)
    for item in (getattr(args, "set", None) or []):
        if "=" not in item:
            raise SystemExit(f"--set expects NAME=VALUE, got {item!r}")
        name, value = item.split("=", 1)
        current = g.constants.get(name)
        g.set_constant(name, value, current["type"] if current else None)
    return g


def cmd_run(args: argparse.Namespace) -> int:
    from raw2ufs.engine.runner import run

    def progress(spec, status, detail):
        if status == "start":
            print(f"  {spec.type:<14} {spec.id}{(' ' + spec.name) if spec.name else ''} ...", end="", flush=True)
        elif status == "done":
            print(" ok")
        elif status == "warning":
            print(f"\n      warning: {detail}", end="", flush=True)
        else:
            print(" FAILED")

    g = _load(args.workflow, args)
    print(f"Running {g.name}")
    run(g, on_node=progress)
    print("Done.")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    from raw2ufs.export.to_script import export_script
    output = Path(args.output).resolve() if args.output else None
    g = _load(args.workflow, args)
    text = export_script(g, source=args.workflow)
    if output:
        output.write_text(text, encoding="utf-8")
        print(f"Wrote {output}")
    else:
        sys.stdout.write(text)
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    from raw2ufs.engine.runner import compile_graph
    g = _load(args.workflow, args)
    try:
        blocks = compile_graph(g)
    except Exception as e:  # noqa: BLE001
        print(f"INVALID: {e}")
        return 1
    print(f"OK: {len(blocks)} nodes compile")
    return 0


def cmd_schema(args: argparse.Namespace) -> int:
    from raw2ufs.engine.dtypes import friendly_dtype
    from raw2ufs.engine.runner import build_plans
    g = _load(args.workflow, args)
    plans = build_plans(g, upto=args.node)
    ids = [args.node] if args.node else list(plans)
    for nid in ids:
        spec = g.node(nid)
        print(f"{nid} ({spec.type}){(' ' + spec.name) if spec.name else ''}")
        for name, dt in plans[nid].collect_schema().items():
            print(f"    {name:<30} {friendly_dtype(dt)}")
    return 0


def cmd_preview(args: argparse.Namespace) -> int:
    from raw2ufs.engine.runner import preview
    g = _load(args.workflow, args)
    with pl.Config(tbl_rows=args.n, tbl_cols=-1, fmt_str_lengths=40):
        print(preview(g, args.node, n=args.n))
    return 0


def cmd_nodes(args: argparse.Namespace) -> int:
    from raw2ufs.engine.registry import all_nodes
    print(json.dumps([c.to_dict() for c in all_nodes()], indent=2))
    return 0


def cmd_docs(args: argparse.Namespace) -> int:
    from raw2ufs.export.docs import tools_markdown
    text = tools_markdown()
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(f"Wrote {args.output}")
    else:
        sys.stdout.write(text)
    return 0


def main(argv: list[str] | None = None) -> int:
    import raw2ufs  # noqa: F401  (registers nodes)

    p = argparse.ArgumentParser(prog="raw2ufs", description="Raw2UFS workflow engine")
    sub = p.add_subparsers(dest="cmd", required=True)

    def wf(parser):
        parser.add_argument("workflow")
        parser.add_argument("--set", action="append", metavar="NAME=VALUE",
                            help="override a workflow constant (repeatable)")
        return parser

    s = wf(sub.add_parser("run", help="execute a workflow")); s.set_defaults(fn=cmd_run)
    s = wf(sub.add_parser("export", help="export a workflow as a standalone polars script"))
    s.add_argument("-o", "--output"); s.set_defaults(fn=cmd_export)
    s = wf(sub.add_parser("validate", help="check a workflow compiles")); s.set_defaults(fn=cmd_validate)
    s = wf(sub.add_parser("schema", help="show output columns/types per node"))
    s.add_argument("node", nargs="?"); s.set_defaults(fn=cmd_schema)
    s = wf(sub.add_parser("preview", help="show the first rows at a node"))
    s.add_argument("node"); s.add_argument("-n", type=int, default=20); s.set_defaults(fn=cmd_preview)
    s = sub.add_parser("nodes", help="node catalogue as JSON"); s.set_defaults(fn=cmd_nodes)
    s = sub.add_parser("docs", help="tool reference as markdown"); s.add_argument("-o", "--output"); s.set_defaults(fn=cmd_docs)

    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
