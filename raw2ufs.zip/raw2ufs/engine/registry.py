"""Node registry and the Node base class.

Design rule: a node *emits polars source code*, it does not execute polars
itself. The runner executes the emitted code, and the script exporter writes
the same code to a file. This guarantees the app and the exported script can
never disagree, and keeps every node to a single implementation.

Adding a node type = one class with a @node decorator. No UI changes are
needed: the front end renders the config panel from `fields`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, ClassVar, Iterable


class NodeConfigError(ValueError):
    """A node's config is invalid (missing column, bad option...)."""


# Field kinds understood by a generic config-panel renderer.
FIELD_KINDS = {
    "string",       # free text (single line)
    "text",         # free text (multi-line)
    "int",
    "float",
    "bool",
    "choice",       # one of `choices`
    "path",         # file path (open or save depending on node)
    "column",       # single column from input port `port`
    "columns",      # list of columns from input port `port`
    "formula",      # Raw2UFS formula text
    "dtype",        # a Raw2UFS dtype name (see engine/dtypes.py)
    "table",        # list of dicts; `columns` describes each sub-field
    "json",         # anything else, edited raw
}


@dataclass
class Field:
    """Describes one config entry so a UI can render it and validate it."""
    name: str
    kind: str
    label: str = ""
    help: str = ""
    required: bool = False
    default: Any = None
    choices: list[str] | None = None
    port: str = "in"                      # which input port column pickers read from
    columns: list["Field"] | None = None  # sub-fields for kind == "table"

    def __post_init__(self) -> None:
        if self.kind not in FIELD_KINDS:
            raise ValueError(f"unknown field kind {self.kind!r} for {self.name}")
        if not self.label:
            self.label = self.name.replace("_", " ").capitalize()

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name, "kind": self.kind, "label": self.label,
            "help": self.help, "required": self.required, "default": self.default,
        }
        if self.choices is not None:
            d["choices"] = self.choices
        if self.kind in ("column", "columns"):
            d["port"] = self.port
        if self.columns:
            d["columns"] = [c.to_dict() for c in self.columns]
        return d


class Node:
    """Base class for every node type.

    Subclasses set the class attributes and implement `emit`.

    emit(cfg, ins, out) must return Python source that assigns a
    `pl.LazyFrame` to the variable named `out`. `ins` maps port name to the
    variable name(s) holding the upstream LazyFrame(s): a str for normal ports,
    a list[str] for variadic ports. Sinks (is_sink=True) write files instead and
    need not assign `out`.
    """

    type: ClassVar[str] = ""
    label: ClassVar[str] = ""
    category: ClassVar[str] = "Transform"   # Input / Output / Transform / Spatial ...
    description: ClassVar[str] = ""         # markdown; used for docs/skill generation
    inputs: ClassVar[list[str]] = ["in"]    # port names, in order
    variadic: ClassVar[bool] = False        # last port accepts many edges (e.g. union)
    is_sink: ClassVar[bool] = False         # writes files, produces no frame
    fields: ClassVar[list[Field]] = []
    helpers: ClassVar[list[str]] = []       # names from raw2ufs.helpers to inline in scripts

    # ---- to implement ---------------------------------------------------------
    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        raise NotImplementedError

    # ---- optional hooks -------------------------------------------------------
    def validate(self, cfg: dict[str, Any]) -> list[str]:
        """Return a list of human-readable problems (empty = OK).

        The default checks required fields; override to add node-specific rules
        and call super().validate(cfg) first.
        """
        problems = []
        for f in self.fields:
            v = cfg.get(f.name, f.default)
            if f.required and (v is None or v == "" or v == []):
                problems.append(f"'{f.label}' is required")
            if f.kind == "choice" and v is not None and f.choices and v not in f.choices:
                problems.append(f"'{f.label}' must be one of {f.choices}, got {v!r}")
        return problems

    def summary(self, cfg: dict[str, Any]) -> str:
        """One-line human description of this configured node (used in script comments)."""
        return ""

    # ---- utilities ------------------------------------------------------------
    def cfg_with_defaults(self, cfg: dict[str, Any]) -> dict[str, Any]:
        full = {f.name: f.default for f in self.fields}
        full.update(cfg)
        return full

    @classmethod
    def to_dict(cls) -> dict[str, Any]:
        return {
            "type": cls.type, "label": cls.label, "category": cls.category,
            "description": cls.description, "inputs": cls.inputs,
            "variadic": cls.variadic, "is_sink": cls.is_sink,
            "fields": [f.to_dict() for f in cls.fields],
        }


REGISTRY: dict[str, type[Node]] = {}


def node(cls: type[Node]) -> type[Node]:
    """Class decorator registering a Node subclass by its `type`."""
    if not cls.type:
        raise ValueError(f"{cls.__name__} must define a `type`")
    if cls.type in REGISTRY and REGISTRY[cls.type] is not cls:
        raise ValueError(f"node type {cls.type!r} already registered")
    if not cls.label:
        cls.label = cls.type.replace("_", " ").title()
    REGISTRY[cls.type] = cls
    return cls


def get_node(type_: str) -> Node:
    try:
        return REGISTRY[type_]()
    except KeyError:
        raise NodeConfigError(f"unknown node type {type_!r}") from None


CATEGORY_ORDER = ["Input", "Prepare", "Combine", "Reshape", "Spatial", "Output", "Annotate"]


def all_nodes() -> Iterable[type[Node]]:
    def key(c: type[Node]):
        idx = CATEGORY_ORDER.index(c.category) if c.category in CATEGORY_ORDER else len(CATEGORY_ORDER)
        return (idx, c.category, c.type)
    return sorted(REGISTRY.values(), key=key)


# ---- source-code helpers for emit() implementations --------------------------

def lit(value: Any) -> str:
    """Render a Python literal safely (strings, numbers, lists, dicts, None)."""
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(lit(v) for v in value) + "]"
    if isinstance(value, dict):
        return "{" + ", ".join(f"{lit(k)}: {lit(v)}" for k, v in value.items()) + "}"
    if isinstance(value, (str, int, float, bool)) or value is None:
        return repr(value)
    raise TypeError(f"cannot render {type(value).__name__} as a literal")


_CONST_REF = re.compile(r"\$\{(\w+)\}")


def strlit(text: str) -> str:
    """Render a text option; `${Name}` references become the constant variable K_Name."""
    text = "" if text is None else str(text)
    if not _CONST_REF.search(text):
        return repr(text)
    parts, pos = [], 0
    for m in _CONST_REF.finditer(text):
        if m.start() > pos:
            parts.append(repr(text[pos:m.start()]))
        parts.append(f"str(K_{m.group(1)})")
        pos = m.end()
    if pos < len(text):
        parts.append(repr(text[pos:]))
    return "(" + " + ".join(parts) + ")"


def pathlit(path: str) -> str:
    """Render a file path relative to BASE_DIR (absolute paths pass through os.path.join unchanged)."""
    return f"os.path.join(BASE_DIR, {strlit(path)})"


def constants_used(text: str) -> list[str]:
    return sorted(set(_CONST_REF.findall(text or "")))


def col(name: str) -> str:
    return f"pl.col({lit(name)})"


def cols(names: Iterable[str]) -> str:
    return "[" + ", ".join(col(n) for n in names) + "]"


def chain(base: str, *ops: str) -> str:
    """Render `base.op1().op2()` one op per line for readability."""
    if not ops:
        return base
    return "(\n    " + base + "\n" + "".join(f"    .{op}\n" for op in ops) + ")"
