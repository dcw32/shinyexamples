"""User-facing data type names and their polars equivalents.

Users pick from these names in the Select tool; emitted code uses the polars
source form so scripts stay readable (`pl.Float64`, not `Float64`).
"""

from __future__ import annotations

import polars as pl

DTYPES: dict[str, str] = {
    "string": "pl.String",
    "int": "pl.Int64",
    "float": "pl.Float64",
    "bool": "pl.Boolean",
    "date": "pl.Date",
    "datetime": "pl.Datetime",
    "binary": "pl.Binary",   # WKB geometry columns
}

_POLARS: dict[str, pl.DataType] = {
    "string": pl.String, "int": pl.Int64, "float": pl.Float64, "bool": pl.Boolean,
    "date": pl.Date, "datetime": pl.Datetime("us"), "binary": pl.Binary,
}


def dtype_source(name: str) -> str:
    try:
        return DTYPES[name]
    except KeyError:
        raise ValueError(f"unknown type {name!r}; choose from {sorted(DTYPES)}") from None


def polars_dtype(name: str) -> pl.DataType:
    return _POLARS[name]


def friendly_dtype(dt: pl.DataType) -> str:
    """Map an arbitrary polars dtype back to the closest user-facing name."""
    if dt == pl.String or dt == pl.Categorical or dt == pl.Utf8:
        return "string"
    if dt.is_integer():
        return "int"
    if dt.is_float() or dt == pl.Decimal:
        return "float"
    if dt == pl.Boolean:
        return "bool"
    if dt == pl.Date:
        return "date"
    if isinstance(dt, pl.Datetime):
        return "datetime"
    if dt == pl.Binary:
        return "binary"
    return str(dt).lower()
