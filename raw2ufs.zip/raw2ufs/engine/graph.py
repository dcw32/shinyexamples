"""Workflow graph model and JSON (de)serialisation.

Workflow JSON format (version 1):

{
  "version": 1,
  "name": "Client X SOV to OED",
  "description": "optional free text",
  "nodes": [
    {"id": "n1", "type": "input", "name": "Read SOV", "config": {...}, "ui": {"x": 0, "y": 0}},
    ...
  ],
  "edges": [
    {"from": "n1", "to": "n2"},                    # to_port defaults to "in"
    {"from": "n2", "to": "n5", "to_port": "left"}   # named port (e.g. join)
  ],
  "containers": [                                   # optional visual groups of nodes
    {"id": "c1", "name": "Client X cleaning", "color": "blue", "enabled": true,
     "nodes": ["n1", "n2"], "ui": {"x": 0, "y": 0, "w": 400, "h": 200}}
  ]
}

A disabled container switches its nodes off: they and everything downstream of
them are skipped when running/validating and commented out in exported scripts.
Containers may nest: an outer container's "nodes" lists every node inside it,
nested ones included (nesting is purely geometric in the UI), so a node can
appear in several containers and is off when any of them is disabled.
A node may carry "enabled": false for the same effect on its own; the workflow
may carry "run_outputs": false to switch every Output tool off at once.

Optional "constants": {"Client": {"type": "string", "value": "X"}, "Scale": {"type": "number", "value": 1000}}
are referenced as [$Client] in formulas and ${Client} inside path/text options,
and become plain Python variables K_Client / K_Scale in exported scripts.

"ui" is opaque to the engine - the front end may store anything there.
Relative file paths resolve against Graph.base_dir (the workflow's folder), not
the process working directory; base_dir is set on load and never serialised.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

GRAPH_VERSION = 1
DEFAULT_PORT = "in"


class GraphError(ValueError):
    """Raised for structural problems in a workflow (cycles, dangling edges...)."""


CONST_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
CONST_TYPES = ("string", "number")


@dataclass
class NodeSpec:
    id: str
    type: str
    config: dict[str, Any] = field(default_factory=dict)
    name: str = ""
    ui: dict[str, Any] = field(default_factory=dict)
    enabled: bool = True

    @property
    def var(self) -> str:
        """Python variable name used for this node's LazyFrame in emitted code."""
        safe = re.sub(r"\W", "_", self.id)
        if not safe or safe[0].isdigit():
            safe = "n_" + safe
        return f"df_{safe}"

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"id": self.id, "type": self.type}
        if self.name:
            d["name"] = self.name
        d["config"] = self.config
        if self.ui:
            d["ui"] = self.ui
        if not self.enabled:
            d["enabled"] = False
        return d


@dataclass
class Edge:
    src: str
    dst: str
    to_port: str = DEFAULT_PORT

    def to_dict(self) -> dict[str, Any]:
        d = {"from": self.src, "to": self.dst}
        if self.to_port != DEFAULT_PORT:
            d["to_port"] = self.to_port
        return d


@dataclass
class Container:
    id: str
    name: str = ""
    color: str = "grey"
    enabled: bool = True
    nodes: list[str] = field(default_factory=list)
    ui: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "name": self.name, "color": self.color, "enabled": self.enabled,
                "nodes": list(self.nodes), "ui": self.ui}


@dataclass
class Graph:
    name: str = "workflow"
    description: str = ""
    nodes: dict[str, NodeSpec] = field(default_factory=dict)
    edges: list[Edge] = field(default_factory=list)
    containers: list[Container] = field(default_factory=list)
    constants: dict[str, dict[str, Any]] = field(default_factory=dict)   # name -> {"type", "value"}
    run_outputs: bool = True
    version: int = GRAPH_VERSION
    base_dir: str | None = None          # folder relative paths resolve against; not serialised

    # ---- construction helpers -------------------------------------------------
    def add_node(self, id: str, type: str, config: dict | None = None,
                 name: str = "", ui: dict | None = None, enabled: bool = True) -> NodeSpec:
        if id in self.nodes:
            raise GraphError(f"duplicate node id {id!r}")
        spec = NodeSpec(id=id, type=type, config=config or {}, name=name, ui=ui or {}, enabled=enabled)
        self.nodes[id] = spec
        return spec

    def add_edge(self, src: str, dst: str, to_port: str = DEFAULT_PORT) -> Edge:
        e = Edge(src, dst, to_port)
        self.edges.append(e)
        return e

    def add_container(self, id: str, name: str = "", nodes: list[str] | None = None,
                      color: str = "grey", enabled: bool = True, ui: dict | None = None) -> Container:
        if any(c.id == id for c in self.containers):
            raise GraphError(f"duplicate container id {id!r}")
        c = Container(id=id, name=name, color=color, enabled=enabled, nodes=list(nodes or []), ui=ui or {})
        self.containers.append(c)
        return c

    # ---- queries --------------------------------------------------------------
    def container_of(self, node_id: str) -> Container | None:
        for c in self.containers:
            if node_id in c.nodes:
                return c
        return None

    def set_constant(self, name: str, value: Any, type_: str | None = None) -> None:
        if not CONST_RE.match(name or ""):
            raise GraphError(f"constant name {name!r} must be a valid identifier")
        if type_ is None:
            type_ = "number" if isinstance(value, (int, float)) and not isinstance(value, bool) else "string"
        if type_ not in CONST_TYPES:
            raise GraphError(f"constant type must be one of {CONST_TYPES}")
        if type_ == "number":
            try:
                value = float(value)
                value = int(value) if value == int(value) else value
            except (TypeError, ValueError):
                raise GraphError(f"constant {name!r}: {value!r} is not a number") from None
        else:
            value = "" if value is None else str(value)
        self.constants[name] = {"type": type_, "value": value}

    def constant_values(self) -> dict[str, Any]:
        return {k: v.get("value") for k, v in self.constants.items()}

    def expand(self, text: str) -> str:
        """Replace ${Name} in a path/text option with the constant's value (for display/validation)."""
        vals = self.constant_values()
        return re.sub(r"\$\{(\w+)\}", lambda m: str(vals.get(m.group(1), m.group(0))), text or "")

    def disabled_nodes(self) -> set[str]:
        """Nodes switched off - by their own flag, by a disabled container, or by
        run_outputs=False (every Output tool) - plus everything downstream of them."""
        off = {nid for c in self.containers if not c.enabled for nid in c.nodes if nid in self.nodes}
        off |= {nid for nid, spec in self.nodes.items() if not spec.enabled}
        if not self.run_outputs:
            off |= {nid for nid, spec in self.nodes.items() if spec.type == "output"}
        stack = list(off)
        while stack:
            cur = stack.pop()
            for e in self.edges:
                if e.src == cur and e.dst not in off:
                    off.add(e.dst)
                    stack.append(e.dst)
        return off

    def node(self, id: str) -> NodeSpec:
        try:
            return self.nodes[id]
        except KeyError:
            raise GraphError(f"unknown node id {id!r}") from None

    def inputs_of(self, id: str) -> dict[str, list[str]]:
        """Map of port name -> ordered list of upstream node ids."""
        ports: dict[str, list[str]] = {}
        for e in self.edges:
            if e.dst == id:
                ports.setdefault(e.to_port, []).append(e.src)
        return ports

    def downstream_of(self, id: str) -> list[str]:
        return [e.dst for e in self.edges if e.src == id]

    def topo_order(self) -> list[str]:
        """Kahn's algorithm; raises GraphError on cycles or dangling edges."""
        for e in self.edges:
            if e.src not in self.nodes:
                raise GraphError(f"edge from unknown node {e.src!r}")
            if e.dst not in self.nodes:
                raise GraphError(f"edge to unknown node {e.dst!r}")
        # Ties are broken by position in the node list, so inputs declared next to
        # the node that uses them stay next to it in the emitted script.
        rank = {nid: i for i, nid in enumerate(self.nodes)}
        indeg = {nid: 0 for nid in self.nodes}
        for e in self.edges:
            indeg[e.dst] += 1
        ready = sorted((nid for nid, d in indeg.items() if d == 0), key=rank.get)
        order: list[str] = []
        while ready:
            nid = ready.pop(0)
            order.append(nid)
            for e in self.edges:
                if e.src == nid:
                    indeg[e.dst] -= 1
                    if indeg[e.dst] == 0:
                        ready.append(e.dst)
                        ready.sort(key=rank.get)
        if len(order) != len(self.nodes):
            stuck = sorted(set(self.nodes) - set(order))
            raise GraphError(f"workflow contains a cycle involving {stuck}")
        return order

    def ancestors(self, id: str) -> list[str]:
        """Topologically ordered ancestors of a node, including the node itself."""
        keep: set[str] = set()
        stack = [id]
        while stack:
            cur = stack.pop()
            if cur in keep:
                continue
            keep.add(cur)
            for port_srcs in self.inputs_of(cur).values():
                stack.extend(port_srcs)
        return [n for n in self.topo_order() if n in keep]

    def __iter__(self) -> Iterator[NodeSpec]:
        return iter(self.nodes.values())

    # ---- serialisation --------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        d = {
            "version": self.version,
            "name": self.name,
            "description": self.description,
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [e.to_dict() for e in self.edges],
        }
        if self.containers:
            d["containers"] = [c.to_dict() for c in self.containers]
        if self.constants:
            d["constants"] = {k: dict(v) for k, v in self.constants.items()}
        if not self.run_outputs:
            d["run_outputs"] = False
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Graph":
        version = int(d.get("version", GRAPH_VERSION))
        if version > GRAPH_VERSION:
            raise GraphError(f"workflow version {version} is newer than supported ({GRAPH_VERSION})")
        g = cls(name=d.get("name", "workflow"), description=d.get("description", ""), version=version,
                run_outputs=bool(d.get("run_outputs", True)), base_dir=d.get("base_dir") or None)
        for name, c in (d.get("constants") or {}).items():
            if isinstance(c, dict):
                g.set_constant(name, c.get("value"), c.get("type"))
            else:
                g.set_constant(name, c)
        for n in d.get("nodes", []):
            g.add_node(n["id"], n["type"], n.get("config", {}), n.get("name", ""), n.get("ui", {}),
                       bool(n.get("enabled", True)))
        for e in d.get("edges", []):
            g.add_edge(e["from"], e["to"], e.get("to_port", DEFAULT_PORT))
        for c in d.get("containers", []) or []:
            g.add_container(c["id"], c.get("name", ""), c.get("nodes", []), c.get("color", "grey"),
                            bool(c.get("enabled", True)), c.get("ui", {}))
        return g

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    @classmethod
    def from_json(cls, text: str) -> "Graph":
        return cls.from_dict(json.loads(text))


def load_graph(path: str | Path) -> Graph:
    """Load a workflow; relative paths inside it resolve next to the file."""
    p = Path(path).resolve()
    g = Graph.from_json(p.read_text(encoding="utf-8"))
    g.base_dir = str(p.parent)
    return g


def save_graph(graph: Graph, path: str | Path) -> None:
    Path(path).write_text(graph.to_json(), encoding="utf-8")
