"""Data inspection used by the UI: type inference for Select, column profiles."""

from __future__ import annotations

from typing import Any

import polars as pl

from raw2ufs.engine.dtypes import friendly_dtype

DATE_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%d.%m.%Y", "%Y/%m/%d", "%d-%m-%Y", "%Y%m%d"]
DATETIME_FORMATS = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%d/%m/%Y %H:%M", "%Y-%m-%d %H:%M"]
BOOL_WORDS = {"true", "false", "yes", "no", "y", "n"}


def infer_types(df: pl.DataFrame) -> dict[str, str]:
    """Best user-facing dtype for each column, judged on the rows given.

    Non-text columns keep their type. Text columns become int / float / date /
    datetime / bool when every non-blank value parses as such (after trimming
    and removing internal whitespace, as Select's cast does), otherwise stay text.
    """
    out: dict[str, str] = {}
    for name in df.columns:
        s = df[name]
        if s.dtype != pl.String:
            out[name] = friendly_dtype(s.dtype)
            continue
        vals = s.str.strip_chars().replace("", None).drop_nulls()
        if vals.len() == 0:
            out[name] = "string"
            continue
        out[name] = _infer_text(vals)
    return out


def _all_parse(vals: pl.Series, expr: pl.Expr) -> bool:
    try:
        parsed = vals.to_frame("v").select(expr.alias("p"))["p"]
    except Exception:  # noqa: BLE001
        return False
    return parsed.null_count() == 0


def _infer_text(vals: pl.Series) -> str:
    v = pl.col("v")
    numeric = v.str.replace_all(r"\s", "")   # "12 500" -> 12500, matching what Select's cast does
    if _all_parse(vals, numeric.cast(pl.Int64, strict=False)):
        # 0/1 columns are ints; leave bool to explicit words
        return "int"
    if _all_parse(vals, numeric.cast(pl.Float64, strict=False)):
        return "float"
    if vals.str.to_lowercase().is_in(list(BOOL_WORDS)).all():
        return "bool"
    for fmt in DATE_FORMATS:
        if _all_parse(vals, v.str.to_date(fmt, strict=False)):
            return "date"
    for fmt in DATETIME_FORMATS:
        if _all_parse(vals, v.str.to_datetime(fmt, strict=False)):
            return "datetime"
    return "string"


def profile(lf: pl.LazyFrame) -> dict[str, Any]:
    """Row count plus per-column null/distinct counts and min/max where meaningful."""
    schema = lf.collect_schema()
    aggs: list[pl.Expr] = [pl.len().alias("__rows")]
    for name, dt in schema.items():
        c = pl.col(name)
        aggs.append(c.null_count().alias(f"{name}\x00nulls"))
        aggs.append(c.n_unique().alias(f"{name}\x00distinct"))
        if dt.is_numeric() or dt.is_temporal() or dt == pl.String:
            aggs.append(c.min().cast(pl.String).alias(f"{name}\x00min"))
            aggs.append(c.max().cast(pl.String).alias(f"{name}\x00max"))
        if dt == pl.String:
            aggs.append((c.str.strip_chars() == "").sum().alias(f"{name}\x00blank"))
    row = lf.select(aggs).collect().row(0, named=True)
    rows = row["__rows"]
    cols = []
    for name, dt in schema.items():
        get = lambda k: row.get(f"{name}\x00{k}")  # noqa: E731
        cols.append({
            "name": name, "dtype": friendly_dtype(dt),
            "nulls": get("nulls"), "blank": get("blank"), "distinct": get("distinct"),
            "min": get("min"), "max": get("max"),
        })
    return {"rows": rows, "columns": cols}
