"""Intermediate-result cache ("run to here").

A node's cache key is a hash of everything that determines its output: the
configs of the node and all its ancestors, the edges between them, the size
and mtime of every input file they read, and the polars version. Change any
of those and the key changes, so stale entries are simply never hit.

A cached node is substituted into lazy plans as `pl.scan_parquet(file)`, so
previews and schema lookups downstream of it never touch the original inputs
again. Exported scripts are unaffected - the cache is an app-side concern.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

import polars as pl

from raw2ufs.engine.graph import Graph
from raw2ufs.engine.registry import REGISTRY


def _file_stat(path: str) -> Any:
    try:
        st = os.stat(path)
        return [st.st_size, int(st.st_mtime)]
    except OSError:
        return None


class Cache:
    def __init__(self, root: str | Path | None = None):
        self.root = Path(root) if root else Path(tempfile.gettempdir()) / "raw2ufs_cache"
        self.root.mkdir(parents=True, exist_ok=True)

    # ---- keys ---------------------------------------------------------------
    def key(self, graph: Graph, node_id: str) -> str:
        ids = graph.ancestors(node_id)
        idset = set(ids)
        payload: dict[str, Any] = {
            "polars": pl.__version__,
            "target": node_id,
            "base_dir": graph.base_dir,
            "constants": graph.constants,
            "nodes": [],
            "edges": sorted((e.src, e.dst, e.to_port) for e in graph.edges if e.src in idset and e.dst in idset),
        }
        for nid in ids:
            spec = graph.node(nid)
            entry: dict[str, Any] = {"id": nid, "type": spec.type, "config": spec.config}
            if spec.type == "input":
                entry["file"] = _file_stat(os.path.join(graph.base_dir or os.getcwd(),
                                                        graph.expand(str(spec.config.get("path", "")))))
            payload["nodes"].append(entry)
        blob = json.dumps(payload, sort_keys=True, default=str).encode()
        return hashlib.sha1(blob).hexdigest()[:20]

    def path(self, key: str) -> Path:
        return self.root / f"{key}.parquet"

    def has(self, graph: Graph, node_id: str) -> bool:
        cls = REGISTRY.get(graph.node(node_id).type)
        if cls is None or cls.is_sink:
            return False
        return self.path(self.key(graph, node_id)).exists()

    def status(self, graph: Graph) -> dict[str, bool]:
        out = {}
        for spec in graph:
            try:
                out[spec.id] = self.has(graph, spec.id)
            except Exception:  # noqa: BLE001  (dangling edges etc. - just not cached)
                out[spec.id] = False
        return out

    # ---- materialise --------------------------------------------------------
    def materialise(self, graph: Graph, node_id: str) -> dict[str, Any]:
        """Execute up to node_id (using cached ancestors) and store its result."""
        from raw2ufs.engine.runner import build_plans
        plans = build_plans(graph, upto=node_id, cache=self)
        df = plans[node_id].collect()
        target = self.path(self.key(graph, node_id))
        tmp = target.with_suffix(".tmp.parquet")
        df.write_parquet(tmp)
        os.replace(tmp, target)
        return {"rows": df.height, "columns": df.width, "bytes": target.stat().st_size}

    def clear(self) -> int:
        n = 0
        if self.root.exists():
            for p in self.root.glob("*.parquet"):
                p.unlink(missing_ok=True)
                n += 1
        return n

    def size_bytes(self) -> int:
        return sum(p.stat().st_size for p in self.root.glob("*.parquet")) if self.root.exists() else 0

    def remove_all(self) -> None:
        shutil.rmtree(self.root, ignore_errors=True)
