"""Raw2UFS - low-code data pipeline engine for turning raw schedules of values
into OED/UFS exposure files.

The engine is UI-agnostic: a workflow is a JSON document (see engine/graph.py),
every node type is a small class that *emits polars source code* (see
engine/registry.py), and the runner executes exactly that code. The exported
standalone script is therefore the same code the app ran - by construction.
"""

__version__ = "0.1.0"

from raw2ufs.engine.graph import Graph, load_graph, save_graph  # noqa: F401
from raw2ufs.engine.registry import REGISTRY, get_node  # noqa: F401
from raw2ufs.engine.runner import build_plans, run  # noqa: F401
from raw2ufs.export.to_script import export_script  # noqa: F401

# Importing the node package registers every built-in node type.
import raw2ufs.nodes  # noqa: E402,F401
