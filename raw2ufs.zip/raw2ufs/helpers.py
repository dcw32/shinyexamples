"""Helper functions that emitted code may call.

Every function here is *inlined verbatim* into exported scripts (via
inspect.getsource), so each must be self-contained: import what it needs
inside its own body, depend only on other helpers listed in HELPER_DEPS, and
use the `_r2u_` prefix to avoid clashing with user code.

The runner imports this module directly, so the app and the script run the
exact same functions.
"""

from __future__ import annotations

__all__ = [
    "_r2u_append_fields",
    "_r2u_drop_null_columns",
    "_r2u_drop_null_rows",
    "_r2u_make_points",
    "_r2u_rename_from_first_row",
    "_r2u_spatial_match",
    "_r2u_write_geoparquet",
]

# helper -> other helpers it calls (exporter inlines dependencies first)
HELPER_DEPS: dict[str, list[str]] = {}


def _r2u_append_fields(target, source, prefix="", max_source_rows=1000):
    """Cartesian product: every source column appended to every target row."""
    import polars as pl
    src = source.collect() if isinstance(source, pl.LazyFrame) else source
    if src.height > max_source_rows:
        raise ValueError(f"Append Fields: source has {src.height} rows, above the limit of {max_source_rows}")
    tgt = target.lazy() if isinstance(target, pl.DataFrame) else target
    taken = set(tgt.collect_schema().names())
    renames = {}
    for c in src.columns:
        n = prefix + c
        if n in taken:
            n = "Right_" + n
        renames[c] = n
    return tgt.join(src.rename(renames).lazy(), how="cross")


def _r2u_drop_null_columns(df):
    """Drop columns whose values are all null. Requires a pass over the data."""
    import polars as pl
    eager = df.collect() if isinstance(df, pl.LazyFrame) else df
    keep = [c for c in eager.columns if eager[c].null_count() < eager.height]
    return eager.select(keep).lazy()


def _r2u_drop_null_rows(df):
    """Drop rows where every column is null."""
    import polars as pl
    return df.filter(~pl.all_horizontal(pl.all().is_null()))


def _r2u_rename_from_first_row(df):
    """Use the first data row as column names (blank/duplicate names get _2, _3 ...), then drop it."""
    import polars as pl
    lf = df.lazy() if isinstance(df, pl.DataFrame) else df
    first = lf.head(1).collect()
    old = first.columns
    new, seen = [], {}
    for i, c in enumerate(old):
        v = first[c][0] if first.height else None
        name = str(v).strip() if v is not None and str(v).strip() else c
        base, k = name, 1
        while name in seen:
            k += 1
            name = f"{base}_{k}"
        seen[name] = True
        new.append(name)
    return lf.slice(1).rename(dict(zip(old, new)))


def _r2u_make_points(lon, lat):
    """Build WKB point geometries from longitude/latitude Series. Nulls stay null."""
    import numpy as np
    import polars as pl
    import shapely
    x = lon.cast(pl.Float64).to_numpy()
    y = lat.cast(pl.Float64).to_numpy()
    ok = ~(np.isnan(x) | np.isnan(y))
    wkb = np.full(len(x), None, dtype=object)
    if ok.any():
        wkb[ok] = shapely.to_wkb(shapely.points(x[ok], y[ok]))
    return pl.Series(wkb, dtype=pl.Binary)


def _r2u_spatial_match(points, polygons, point_col, polygon_col, how="left",
                       predicate="within", suffix="_right"):
    """Join point rows to polygon rows using a shapely STRtree spatial predicate.

    `how`: "left" keeps unmatched points with null polygon columns, "inner" drops
    them. A point inside several polygons produces several rows.
    """
    import numpy as np
    import polars as pl
    import shapely
    pts = points.collect() if isinstance(points, pl.LazyFrame) else points
    pols = polygons.collect() if isinstance(polygons, pl.LazyFrame) else polygons
    pt_geom = shapely.from_wkb(pts[point_col].to_numpy())
    pol_geom = shapely.from_wkb(pols[polygon_col].to_numpy())
    tree = shapely.STRtree(pol_geom)
    pt_idx, pol_idx = tree.query(pt_geom, predicate=predicate)
    pts_i = pts.with_row_index("_r2u_pt")
    pols_i = pols.drop(polygon_col).with_row_index("_r2u_pol")
    pairs = pl.DataFrame({
        "_r2u_pt": pt_idx.astype(np.uint32), "_r2u_pol": pol_idx.astype(np.uint32)})
    out = (pts_i.join(pairs, on="_r2u_pt", how=how)
           .join(pols_i, on="_r2u_pol", how="left", suffix=suffix)
           .drop(["_r2u_pt", "_r2u_pol"]))
    return out.lazy()


def _r2u_write_geoparquet(df, path, geometry_col="geometry", crs="EPSG:4326"):
    """Write a DataFrame with a WKB geometry column as GeoParquet 1.1."""
    import json
    import polars as pl
    import shapely
    eager = df.collect() if isinstance(df, pl.LazyFrame) else df
    geoms = shapely.from_wkb(eager[geometry_col].drop_nulls().to_numpy())
    types = sorted({shapely.get_type_id(g) for g in geoms})
    names = {0: "Point", 1: "LineString", 2: "LinearRing", 3: "Polygon",
             4: "MultiPoint", 5: "MultiLineString", 6: "MultiPolygon", 7: "GeometryCollection"}
    meta = {
        "version": "1.1.0",
        "primary_column": geometry_col,
        "columns": {geometry_col: {
            "encoding": "WKB",
            "geometry_types": [names[t] for t in types],
            "crs": crs,
        }},
    }
    if len(geoms):
        meta["columns"][geometry_col]["bbox"] = [float(v) for v in shapely.total_bounds(geoms)]
    eager.write_parquet(path, metadata={"geo": json.dumps(meta)})
