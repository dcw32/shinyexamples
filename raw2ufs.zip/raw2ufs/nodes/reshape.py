"""Aggregation and reshaping nodes: Summarise, Transpose, CrossTab."""

from __future__ import annotations

from typing import Any

from raw2ufs.engine.registry import Field, Node, chain, col, lit, node

AGG_FUNCS = ["count", "count_distinct", "sum", "mean", "median", "min", "max",
             "first", "last", "std", "concat"]


def _agg(func: str, column: str) -> str:
    c = col(column)
    return {
        "count": f"{c}.count()",
        "count_distinct": f"{c}.n_unique()",
        "sum": f"{c}.sum()",
        "mean": f"{c}.mean()",
        "median": f"{c}.median()",
        "min": f"{c}.min()",
        "max": f"{c}.max()",
        "first": f"{c}.first()",
        "last": f"{c}.last()",
        "std": f"{c}.std()",
        "concat": f"{c}.cast(pl.String).str.join(', ')",
    }[func]


@node
class Summarise(Node):
    type = "summarise"
    category = "Reshape"
    description = (
        "Group rows by one or more columns and aggregate others: count, count distinct, "
        "sum, mean, median, min, max, first, last, std, or concat (joins text values with "
        "commas). With no group columns the whole table collapses to one row. Add a "
        "*Row count* column name to get the number of rows per group."
    )
    fields = [
        Field("group_by", "columns", default=[]),
        Field("aggregations", "table", default=[], columns=[
            Field("column", "column", required=True),
            Field("function", "choice", choices=AGG_FUNCS, default="sum"),
            Field("alias", "string", help="Output name; blank = column_function."),
        ]),
        Field("row_count", "string", default="", label="Row count column",
              help="Optional: name of a column holding the number of rows per group."),
    ]

    def validate(self, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        if not cfg["aggregations"] and not cfg["row_count"]:
            problems.append("add at least one aggregation or a row count column")
        return problems

    def summary(self, cfg: dict[str, Any]) -> str:
        aggs = ", ".join(f"{a['function']}({a['column']})" for a in cfg["aggregations"])
        return f"by {cfg['group_by'] or 'nothing'}: {aggs}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        aggs = []
        if cfg["row_count"]:
            aggs.append(f"pl.len().alias({lit(cfg['row_count'])})")
        for a in cfg["aggregations"]:
            alias = a.get("alias") or f"{a['column']}_{a['function']}"
            aggs.append(f"{_agg(a['function'], a['column'])}.alias({lit(alias)})")
        body = "[\n        " + ",\n        ".join(aggs) + ",\n    ]"
        if cfg["group_by"]:
            group = f"group_by({lit(cfg['group_by'])}, maintain_order=True)"
            return f"{out} = {chain(ins['in'], group, f'agg({body})')}\n"
        return f"{out} = {ins['in']}.select({body})\n"


@node
class Transpose(Node):
    type = "transpose"
    category = "Reshape"
    description = (
        "Wide to long: turn several value columns into two columns, one holding the "
        "original column name and one holding the value. *Key columns* are repeated on "
        "every output row. Blank *Value columns* = every non-key column. Tick *As text* "
        "when the value columns have mixed types."
    )
    fields = [
        Field("index", "columns", default=[], label="Key columns"),
        Field("on", "columns", default=[], label="Value columns", help="Blank = all others."),
        Field("variable_name", "string", default="Name"),
        Field("value_name", "string", default="Value"),
        Field("as_text", "bool", default=False, label="As text"),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"keys {cfg['index']} -> [{cfg['variable_name']}], [{cfg['value_name']}]"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        src = ins["in"]
        ops = []
        if cfg["as_text"]:
            keep = lit(cfg["index"])
            ops.append(f"with_columns(pl.exclude({keep}).cast(pl.String))")
        on = lit(cfg["on"]) if cfg["on"] else "None"
        ops.append(f"unpivot(on={on}, index={lit(cfg['index'])}, "
                   f"variable_name={lit(cfg['variable_name'])}, value_name={lit(cfg['value_name'])})")
        return f"{out} = {chain(src, *ops)}\n"


PIVOT_AGGS = ["first", "sum", "mean", "min", "max", "median", "len"]


@node
class CrossTab(Node):
    type = "crosstab"
    label = "Cross Tab"
    category = "Reshape"
    description = (
        "Long to wide: one output row per combination of *Key columns*, and one new "
        "column per distinct value of *Header column*, filled from *Value column* using "
        "the aggregation. The output columns depend on the data, so schema preview "
        "needs a run."
    )
    fields = [
        Field("index", "columns", required=True, label="Key columns"),
        Field("on", "column", required=True, label="Header column"),
        Field("values", "column", required=True, label="Value column"),
        Field("aggregate", "choice", choices=PIVOT_AGGS, default="first"),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"keys {cfg['index']}, headers from [{cfg['on']}], {cfg['aggregate']}([{cfg['values']}])"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        return (f"{out} = {ins['in']}.collect().pivot(\n"
                f"    on={lit(cfg['on'])}, index={lit(cfg['index'])}, values={lit(cfg['values'])},\n"
                f"    aggregate_function={lit(cfg['aggregate'])},\n"
                f").lazy()\n")


__all__ = ["Summarise", "Transpose", "CrossTab"]
