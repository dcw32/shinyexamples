"""Spatial nodes (require shapely). Geometry travels as WKB in a Binary column."""

from __future__ import annotations

from typing import Any

from raw2ufs.engine.registry import Field, Node, lit, node


@node
class CreatePoints(Node):
    type = "create_points"
    label = "Create Points"
    category = "Spatial"
    description = (
        "Build point geometries from latitude and longitude columns into a WKB binary "
        "column (default `geometry`). Rows with a missing coordinate get a null geometry. "
        "Coordinates are assumed to be WGS84 (EPSG:4326)."
    )
    fields = [
        Field("lat", "column", required=True, label="Latitude column"),
        Field("lon", "column", required=True, label="Longitude column"),
        Field("geometry_col", "string", default="geometry", label="Geometry column"),
    ]
    helpers = ["_r2u_make_points"]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"[{cfg['geometry_col']}] from [{cfg['lon']}], [{cfg['lat']}]"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        lon, lat = lit(cfg["lon"]), lit(cfg["lat"])
        return (f"{out} = {ins['in']}.with_columns(\n"
                f"    pl.struct([{lon}, {lat}])\n"
                f"    .map_batches(lambda s: _r2u_make_points(s.struct.field({lon}), s.struct.field({lat})),\n"
                f"                 return_dtype=pl.Binary)\n"
                f"    .alias({lit(cfg['geometry_col'])})\n"
                f")\n")


@node
class SpatialMatch(Node):
    type = "spatial_match"
    label = "Spatial Match"
    category = "Spatial"
    inputs = ["points", "polygons"]
    description = (
        "Point-in-polygon join. Every row on the *points* port is matched against the "
        "polygons on the *polygons* port with a shapely STRtree, and the polygon's "
        "attribute columns are appended. *left* keeps unmatched points with null "
        "attributes, *inner* drops them. A point inside several overlapping polygons "
        "yields one row per polygon. Both geometry columns must be WKB (as produced by "
        "**Create Points** or read from GeoParquet) and share a CRS."
    )
    fields = [
        Field("point_col", "column", default="geometry", port="points", label="Point geometry column"),
        Field("polygon_col", "column", default="geometry", port="polygons", label="Polygon geometry column"),
        Field("how", "choice", choices=["left", "inner"], default="left"),
        Field("predicate", "choice", choices=["within", "intersects"], default="within"),
        Field("suffix", "string", default="_poly", help="Added to clashing polygon column names."),
    ]
    helpers = ["_r2u_spatial_match"]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"{cfg['how']} match, points {cfg['predicate']} polygons"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        return (f"{out} = _r2u_spatial_match(\n"
                f"    {ins['points']}, {ins['polygons']},\n"
                f"    point_col={lit(cfg['point_col'])}, polygon_col={lit(cfg['polygon_col'])},\n"
                f"    how={lit(cfg['how'])}, predicate={lit(cfg['predicate'])}, suffix={lit(cfg['suffix'])},\n"
                f")\n")


__all__ = ["CreatePoints", "SpatialMatch"]
