"""Row/column preparation nodes: Select, Cleanse, Filter, Formula, RecordID, Sort, Unique."""

from __future__ import annotations

import re
from typing import Any

from raw2ufs.engine.dtypes import DTYPES, dtype_source
from raw2ufs.engine.registry import Field, Node, chain, col, cols, lit, node
from raw2ufs.formula import FormulaError, to_polars_source
from raw2ufs.formula import ast as fast
from raw2ufs.formula.emit import _emit, _lit
from raw2ufs.formula.parser import parse as parse_formula


def _num_or_str(value: Any) -> str:
    """Render a filter/lookup value: numbers as numbers, everything else as text (used when the type is unknown)."""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return repr(value)
    s = str(value).strip()
    try:
        return repr(int(s))
    except ValueError:
        pass
    try:
        return repr(float(s))
    except ValueError:
        return repr(s)


def _typed_value(value: Any, dtype: str) -> str:
    """Render a filter value to match the column's declared type."""
    s = "" if value is None else str(value).strip()
    if dtype in ("int", "float"):
        try:
            return repr(int(s)) if dtype == "int" else repr(float(s))
        except ValueError:
            return repr(float(s.replace(" ", "").replace(",", ".")))
    if dtype == "bool":
        return repr(s.lower() in ("true", "1", "yes", "y"))
    if dtype == "date":
        return f"pl.lit({s!r}).str.to_date(strict=False)"
    if dtype == "datetime":
        return f"pl.lit({s!r}).str.to_datetime(strict=False)"
    if dtype == "string":
        return repr(s)
    return _num_or_str(value)


@node
class Select(Node):
    type = "select"
    category = "Prepare"
    description = (
        "Choose which columns to keep, rename them and set their data types. Columns not "
        "listed are dropped unless *Keep other columns* is ticked. Type conversion is "
        "non-strict: values that cannot be converted become null rather than failing "
        "the workflow (use **Filter** with `IsNull` afterwards to find them). Converting "
        "text to int/float ignores internal spaces, so `12 500` becomes 12500."
    )
    fields = [
        Field("columns", "table", required=True, columns=[
            Field("name", "column", required=True),
            Field("rename", "string", help="New name; blank keeps the current name."),
            Field("dtype", "choice", choices=[""] + list(DTYPES), default="",
                  help="Blank keeps the current type."),
        ]),
        Field("keep_others", "bool", default=False, label="Keep other columns"),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"keep {len(cfg['columns'])} columns"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        exprs = []
        renames = {}
        for row in cfg["columns"]:
            e = col(row["name"])
            if row.get("dtype") in ("int", "float"):
                # via text so "12 500" style numbers in text columns convert; harmless for numerics
                e += f".cast(pl.String).str.replace_all(r'\\s', '').cast({dtype_source(row['dtype'])}, strict=False)"
            elif row.get("dtype"):
                e += f".cast({dtype_source(row['dtype'])}, strict=False)"
            new = row.get("rename") or row["name"]
            if cfg["keep_others"]:
                if new != row["name"]:
                    renames[row["name"]] = new
            else:
                if new != row["name"]:
                    e += f".alias({lit(new)})"
            exprs.append(e)
        body = "[\n        " + ",\n        ".join(exprs) + ",\n    ]"
        if cfg["keep_others"]:
            ops = [f"with_columns({body})"]
            if renames:
                ops.append(f"rename({lit(renames)})")
            return f"{out} = {chain(ins['in'], *ops)}\n"
        return f"{out} = {chain(ins['in'], f'select({body})')}\n"


CASES = ["", "upper", "lower", "title"]


@node
class Cleanse(Node):
    type = "cleanse"
    category = "Prepare"
    description = (
        "Apply common clean-up steps to chosen columns (blank = all columns). Text steps "
        "only touch text columns and *Nulls to 0* only numeric ones, so it is safe to run "
        "on a whole table. Steps run in the order listed in the config panel: null "
        "replacement, whitespace, character removal, case. Row/column dropping applies to "
        "the whole table."
    )
    fields = [
        Field("columns", "columns", default=[], help="Blank = every column."),
        Field("null_to_blank", "bool", default=False, label="Nulls to blank (text)"),
        Field("null_to_zero", "bool", default=False, label="Nulls to 0 (numeric)"),
        Field("trim", "bool", default=False, label="Trim leading/trailing whitespace"),
        Field("collapse_whitespace", "bool", default=False,
              label="Tabs, line breaks and repeated spaces to one space"),
        Field("remove_whitespace", "bool", default=False, label="Remove all whitespace"),
        Field("remove_letters", "bool", default=False),
        Field("remove_numbers", "bool", default=False),
        Field("remove_punctuation", "bool", default=False),
        Field("case", "choice", choices=CASES, default="", label="Modify case"),
        Field("drop_null_rows", "bool", default=False, label="Drop rows that are entirely null"),
        Field("drop_null_columns", "bool", default=False, label="Drop columns that are entirely null"),
    ]
    helpers = ["_r2u_drop_null_rows", "_r2u_drop_null_columns"]

    def summary(self, cfg: dict[str, Any]) -> str:
        on = [f.name for f in self.fields if f.kind == "bool" and cfg.get(f.name)]
        if cfg.get("case"):
            on.append(f"case={cfg['case']}")
        return ", ".join(on).replace("_", " ")

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        names = cfg["columns"] or []
        strs = f"(cs.by_name({lit(names)}) & cs.string())" if names else "cs.string()"
        nums = f"(cs.by_name({lit(names)}) & cs.numeric())" if names else "cs.numeric()"
        steps: list[str] = []
        if cfg["null_to_blank"]:
            steps.append(f"with_columns({strs}.fill_null(''))")
        if cfg["null_to_zero"]:
            steps.append(f"with_columns({nums}.fill_null(0))")
        if cfg["collapse_whitespace"]:
            steps.append(f"with_columns({strs}.str.replace_all(r'\\s+', ' '))")
        if cfg["remove_whitespace"]:
            steps.append(f"with_columns({strs}.str.replace_all(r'\\s+', ''))")
        if cfg["remove_letters"]:
            steps.append(f"with_columns({strs}.str.replace_all(r'[^\\W\\d_]+', ''))")
        if cfg["remove_numbers"]:
            steps.append(f"with_columns({strs}.str.replace_all(r'\\d+', ''))")
        if cfg["remove_punctuation"]:
            steps.append(f"with_columns({strs}.str.replace_all(r'[^\\w\\s]+', ''))")
        if cfg["trim"]:
            steps.append(f"with_columns({strs}.str.strip_chars())")
        if cfg["case"] == "upper":
            steps.append(f"with_columns({strs}.str.to_uppercase())")
        elif cfg["case"] == "lower":
            steps.append(f"with_columns({strs}.str.to_lowercase())")
        elif cfg["case"] == "title":
            steps.append(f"with_columns({strs}.str.to_titlecase())")
        code = f"{out} = {chain(ins['in'], *steps)}\n"
        if cfg["drop_null_rows"]:
            code += f"{out} = _r2u_drop_null_rows({out})\n"
        if cfg["drop_null_columns"]:
            code += f"{out} = _r2u_drop_null_columns({out})\n"
        return code


FILTER_OPS = ["=", "<>", "<", "<=", ">", ">=", "contains", "starts with", "ends with",
              "is null", "is not null", "in list"]


@node
class Filter(Node):
    type = "filter"
    category = "Prepare"
    description = (
        "Keep only the rows that meet a condition. *Simple* mode builds the condition "
        "from column / operator / value rows combined with AND or OR; the *Type* column "
        "(filled in from the data when you pick a column) decides whether the value is "
        "compared as a number, text or date. *In list* takes a comma-separated list. *Formula* mode accepts any Raw2UFS formula that returns "
        "TRUE/FALSE, e.g. `[TIV] > 0 AND NOT IsNull([Postcode])`."
    )
    fields = [
        Field("mode", "choice", choices=["simple", "formula"], default="simple"),
        Field("combine", "choice", choices=["and", "or"], default="and",
              help="Simple mode: how the conditions combine."),
        Field("conditions", "table", default=[], columns=[
            Field("column", "column", required=True),
            Field("op", "choice", choices=FILTER_OPS, default="="),
            Field("value", "string"),
            Field("dtype", "choice", choices=[""] + list(DTYPES), default="", label="Type",
                  help="How to read the value; filled in from the column's type."),
        ]),
        Field("formula", "formula", default=""),
    ]

    def validate(self, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        if cfg["mode"] == "simple" and not cfg["conditions"]:
            problems.append("at least one condition is required")
        if cfg["mode"] == "formula":
            if not cfg["formula"].strip():
                problems.append("formula is required")
            else:
                try:
                    to_polars_source(cfg["formula"])
                except FormulaError as e:
                    problems.append(f"formula: {e}")
        return problems

    def summary(self, cfg: dict[str, Any]) -> str:
        if cfg["mode"] == "formula":
            return cfg["formula"]
        return f" {cfg['combine'].upper()} ".join(
            f"[{c['column']}] {c['op']} {c.get('value', '')}".rstrip() for c in cfg["conditions"])

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        if cfg["mode"] == "formula":
            expr = to_polars_source(cfg["formula"])
        else:
            parts = []
            for c in cfg["conditions"]:
                cexpr, op, val = col(c["column"]), c["op"], c.get("value", "")
                dt = c.get("dtype") or ""
                if dt in ("int", "float"):   # compare as numbers even if the column is still text
                    cexpr = f"{cexpr}.cast(pl.Float64, strict=False)"
                elif dt == "date":           # tolerate text columns holding dates
                    cexpr = f"pl.coalesce([{cexpr}.cast(pl.String).str.to_date(strict=False)])"
                elif dt == "datetime":
                    cexpr = f"pl.coalesce([{cexpr}.cast(pl.String).str.to_datetime(strict=False)])"
                if op == "=":
                    parts.append(f"({cexpr} == {_typed_value(val, dt)})")
                elif op == "<>":
                    parts.append(f"({cexpr} != {_typed_value(val, dt)})")
                elif op in ("<", "<=", ">", ">="):
                    parts.append(f"({cexpr} {op} {_typed_value(val, dt)})")
                elif op == "contains":
                    parts.append(f"{cexpr}.str.contains({lit(str(val))}, literal=True)")
                elif op == "starts with":
                    parts.append(f"{cexpr}.str.starts_with({lit(str(val))})")
                elif op == "ends with":
                    parts.append(f"{cexpr}.str.ends_with({lit(str(val))})")
                elif op == "is null":
                    parts.append(f"{cexpr}.is_null()")
                elif op == "is not null":
                    parts.append(f"{cexpr}.is_not_null()")
                elif op == "in list":
                    items = [_typed_value(v, dt) if dt in ("int", "float", "string", "bool") else _num_or_str(v)
                             for v in str(val).split(",") if v.strip()]
                    parts.append(f"{cexpr}.is_in([{', '.join(items)}])")
                else:
                    raise ValueError(f"unknown filter operator {op!r}")
            joiner = " & " if cfg["combine"] == "and" else " | "
            expr = joiner.join(parts)
        return f"{out} = {ins['in']}.filter({expr})\n"


@node
class Formula(Node):
    type = "formula"
    category = "Prepare"
    description = (
        "Create or overwrite columns with a Raw2UFS formula. Rows are evaluated top to "
        "bottom, so a later formula can use a column created above it. Syntax: "
        "`[Column]` references, arithmetic `+ - * / % ^`, comparisons `= <> < <= > >=`, "
        "`AND OR NOT`, `IN ('a','b')`, text in single quotes, "
        "`IF cond THEN a ELSEIF cond THEN b ELSE c ENDIF`, and functions such as "
        "`Upper`, `Trim`, `Left`, `Replace`, `ToNumber`, `IfNull`, `Round`, `ToDate` "
        "(see the Formula functions reference). Optionally cast the result to a type."
    )
    fields = [
        Field("columns", "table", required=True, columns=[
            Field("name", "column", required=True, help="Output column: pick an existing one to overwrite it, or type a new name."),
            Field("formula", "formula", required=True),
            Field("dtype", "choice", choices=[""] + list(DTYPES), default="",
                  help="Optional type for the result."),
        ]),
    ]

    def validate(self, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        for row in cfg.get("columns") or []:
            try:
                to_polars_source(row.get("formula", ""))
            except FormulaError as e:
                problems.append(f"[{row.get('name')}]: {e}")
        return problems

    def summary(self, cfg: dict[str, Any]) -> str:
        return "\n".join(f"[{r['name']}] = {r['formula']}" for r in cfg["columns"])

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        ops = []
        for row in cfg["columns"]:
            e = to_polars_source(row["formula"])
            if row.get("dtype"):
                e = f"({e}).cast({dtype_source(row['dtype'])}, strict=False)"
            ops.append(f"with_columns({e}.alias({lit(row['name'])}))")
        return f"{out} = {chain(ins['in'], *ops)}\n"


@node
class RecordID(Node):
    type = "record_id"
    label = "Record ID"
    category = "Prepare"
    description = (
        "Add a sequential integer column starting at *Start*. With *Group by* columns "
        "the numbering restarts within each group (row order within the group follows "
        "the incoming order, so put a **Sort** in front if it matters)."
    )
    fields = [
        Field("name", "string", default="RecordID", required=True),
        Field("start", "int", default=1),
        Field("group_by", "columns", default=[]),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        g = f" per {cfg['group_by']}" if cfg["group_by"] else ""
        return f"[{cfg['name']}] from {cfg['start']}{g}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        start = int(cfg["start"])
        e = f"pl.int_range({start}, pl.len() + {start}, dtype=pl.Int64)"
        if cfg["group_by"]:
            e += f".over({lit(cfg['group_by'])})"
        return f"{out} = {ins['in']}.with_columns({e}.alias({lit(cfg['name'])}))\n"


@node
class Sort(Node):
    type = "sort"
    category = "Prepare"
    description = "Order rows by one or more columns, each ascending or descending."
    fields = [
        Field("by", "table", required=True, columns=[
            Field("column", "column", required=True),
            Field("descending", "bool", default=False),
        ]),
        Field("nulls_last", "bool", default=True),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        return ", ".join(f"{r['column']} {'desc' if r.get('descending') else 'asc'}" for r in cfg["by"])

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        names = [r["column"] for r in cfg["by"]]
        desc = [bool(r.get("descending")) for r in cfg["by"]]
        return (f"{out} = {ins['in']}.sort({lit(names)}, descending={lit(desc)}, "
                f"nulls_last={lit(bool(cfg['nulls_last']))})\n")


@node
class Unique(Node):
    type = "unique"
    category = "Prepare"
    description = (
        "Remove duplicate rows. With *Columns* set, rows are duplicates when those "
        "columns match and the first (or last) occurrence is kept; blank = whole row."
    )
    fields = [
        Field("columns", "columns", default=[], help="Blank = compare whole rows."),
        Field("keep", "choice", choices=["first", "last", "any"], default="first"),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"on {cfg['columns'] or 'all columns'}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        subset = f"subset={lit(cfg['columns'])}, " if cfg["columns"] else ""
        maintain = ", maintain_order=True" if cfg["keep"] != "any" else ""
        return f"{out} = {ins['in']}.unique({subset}keep={lit(cfg['keep'])}{maintain})\n"


RANGE_RE = re.compile(r"^\s*(\d+)?\s*(-)?\s*(\d+)?\s*$")


def parse_row_ranges(text: str) -> list[tuple[int, int | None]]:
    """'1' -> [(1,1)]; '2-' -> [(2,None)]; '15-20, 30-' -> [(15,20),(30,None)]. 1-based, inclusive."""
    out = []
    for part in (text or "").split(","):
        if not part.strip():
            continue
        m = RANGE_RE.match(part)
        if not m or (m.group(1) is None and m.group(3) is None):
            raise ValueError(f"row range {part.strip()!r} should look like 1, 2-, -10 or 15-20")
        a, dash, b = m.group(1), m.group(2), m.group(3)
        lo = int(a) if a else 1
        hi = (int(b) if b else None) if dash else lo
        if lo < 1 or (hi is not None and hi < lo):
            raise ValueError(f"row range {part.strip()!r} is empty or starts below 1")
        out.append((lo, hi))
    return out


@node
class SelectRecords(Node):
    type = "select_records"
    label = "Select Records"
    category = "Prepare"
    description = (
        "Keep rows by position (1-based, inclusive). Comma-separated ranges: `1` the first "
        "row only, `2-` from the second row to the end, `-10` the first ten, `15-20` rows "
        "15 to 20. Row numbers follow the incoming order, so put a **Sort** in front if it "
        "matters."
    )
    fields = [Field("ranges", "string", required=True, default="1-", label="Row ranges",
                    help="e.g. 1  |  2-  |  15-20, 30-")]

    def validate(self, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        try:
            parse_row_ranges(cfg.get("ranges", ""))
        except ValueError as e:
            problems.append(str(e))
        return problems

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"rows {cfg['ranges']}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        conds = []
        for lo, hi in parse_row_ranges(cfg["ranges"]):
            if hi is None:
                conds.append(f"(pl.col('_row') >= {lo})")
            elif lo == hi:
                conds.append(f"(pl.col('_row') == {lo})")
            else:
                conds.append(f"pl.col('_row').is_between({lo}, {hi})")
        ops = ["with_row_index('_row', offset=1)", "filter(" + " | ".join(conds) + ")", "drop('_row')"]
        return f"{out} = {chain(ins['in'], *ops)}\n"


CURRENT_FIELD = "_CurrentField_"
CURRENT_FIELD_NAME = "_CurrentFieldName_"


def _substitute(e: fast.Expr, column: str) -> fast.Expr:
    """Replace [_CurrentField_] / [_CurrentFieldName_] in a parsed formula for one column."""
    if isinstance(e, fast.Column):
        if e.name == CURRENT_FIELD:
            return fast.Column(column)
        if e.name == CURRENT_FIELD_NAME:
            return fast.String(column)
        return e
    if isinstance(e, fast.Unary):
        return fast.Unary(e.op, _substitute(e.operand, column))
    if isinstance(e, fast.Binary):
        return fast.Binary(e.op, _substitute(e.left, column), _substitute(e.right, column))
    if isinstance(e, fast.In):
        return fast.In(_substitute(e.value, column), [_substitute(o, column) for o in e.options], e.negated)
    if isinstance(e, fast.Call):
        return fast.Call(e.name, [_substitute(a, column) for a in e.args])
    if isinstance(e, fast.If):
        return fast.If([(_substitute(c, column), _substitute(v, column)) for c, v in e.branches],
                       _substitute(e.otherwise, column))
    return e


@node
class MultiFieldFormula(Node):
    type = "multi_field_formula"
    label = "Multi-Field Formula"
    category = "Prepare"
    description = (
        "Apply one formula to several columns at once. Write the formula with "
        "`[_CurrentField_]` standing for each selected column in turn (and "
        "`[_CurrentFieldName_]` for its name as text), e.g. `IfNull([_CurrentField_], 0) * 1000` "
        "or `Trim(Upper([_CurrentField_]))`. Results overwrite the columns, or go to new "
        "columns named with a prefix and/or suffix."
    )
    fields = [
        Field("columns", "columns", required=True),
        Field("formula", "formula", required=True, help="Use [_CurrentField_] for the column being processed."),
        Field("output", "choice", choices=["overwrite", "new columns"], default="overwrite"),
        Field("prefix", "string", default="", help="New columns only."),
        Field("suffix", "string", default="_new", help="New columns only."),
        Field("dtype", "choice", choices=[""] + list(DTYPES), default="", help="Optional type for the results."),
    ]

    def validate(self, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        try:
            tree = parse_formula(cfg.get("formula") or "")
            if CURRENT_FIELD not in fast.columns_used(tree) and CURRENT_FIELD_NAME not in fast.columns_used(tree):
                problems.append(f"formula should use [{CURRENT_FIELD}]")
        except FormulaError as e:
            problems.append(f"formula: {e}")
        if cfg.get("output") == "new columns" and not (cfg.get("prefix") or cfg.get("suffix")):
            problems.append("new columns need a prefix or a suffix")
        return problems

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"{cfg['formula']} on {len(cfg['columns'])} columns"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        tree = parse_formula(cfg["formula"])
        exprs = []
        for c in cfg["columns"]:
            e = _lit(_emit(_substitute(tree, c)))
            if cfg.get("dtype"):
                e = f"({e}).cast({dtype_source(cfg['dtype'])}, strict=False)"
            name = c if cfg["output"] == "overwrite" else f"{cfg['prefix']}{c}{cfg['suffix']}"
            exprs.append(f"{e}.alias({lit(name)})")
        body = "[\n        " + ",\n        ".join(exprs) + ",\n    ]"
        return f"{out} = {chain(ins['in'], f'with_columns({body})')}\n"


@node
class DynamicRename(Node):
    type = "dynamic_rename"
    label = "Dynamic Rename"
    category = "Prepare"
    description = (
        "Rename columns in bulk. *First row* uses the values in the first data row as the "
        "column names and drops that row (for files read with *All columns as text* whose "
        "real header sits below junk rows). *Add prefix/suffix* and *Remove prefix/suffix* "
        "change every column's name (or only the chosen ones). Duplicate or blank names "
        "from the first row get `_2`, `_3` ... appended."
    )
    fields = [
        Field("mode", "choice", choices=["first row", "add prefix/suffix", "remove prefix/suffix"], default="first row"),
        Field("columns", "columns", default=[], help="Prefix/suffix modes only. Blank = every column."),
        Field("prefix", "string", default=""),
        Field("suffix", "string", default=""),
    ]
    helpers = ["_r2u_rename_from_first_row"]

    def summary(self, cfg: dict[str, Any]) -> str:
        if cfg["mode"] == "first row":
            return "names from first row"
        return f"{cfg['mode']} {cfg['prefix']!r}/{cfg['suffix']!r}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        src = ins["in"]
        if cfg["mode"] == "first row":
            return f"{out} = _r2u_rename_from_first_row({src})\n"
        pre, suf = cfg.get("prefix") or "", cfg.get("suffix") or ""
        names = f"{lit(cfg['columns'])}" if cfg.get("columns") else f"{src}.collect_schema().names()"
        if cfg["mode"] == "add prefix/suffix":
            return f"{out} = {src}.rename({{c: {lit(pre)} + c + {lit(suf)} for c in {names}}})\n"
        return (f"{out} = {src}.rename({{c: c.removeprefix({lit(pre)}).removesuffix({lit(suf)}) "
                f"for c in {names}}})\n")


@node
class TextToColumns(Node):
    type = "text_to_columns"
    label = "Text To Columns"
    category = "Prepare"
    description = (
        "Split a text column on a delimiter. *To columns* makes N new columns named "
        "`<root>_1 .. <root>_N`; pieces beyond N are dropped, or kept in the last column "
        "with *Extra pieces = keep in last*. *To rows* makes one row per piece (the other "
        "columns are repeated). *Ignore delimiters inside quotes* keeps `\"a, b\"` "
        "together. Use `\\t` for a tab delimiter."
    )
    fields = [
        Field("column", "column", required=True),
        Field("delimiter", "string", default=",", required=True),
        Field("mode", "choice", choices=["to columns", "to rows"], default="to columns"),
        Field("n_columns", "int", default=2, label="Number of columns", help="To columns only."),
        Field("root", "string", default="", label="Output root name", help="Blank = the column name."),
        Field("extra", "choice", choices=["drop", "keep in last"], default="drop", label="Extra pieces",
              help="To columns only: what happens to text beyond the last column."),
        Field("skip_empty", "bool", default=True, label="Skip empty pieces (to rows)"),
        Field("ignore_quoted", "bool", default=False, label="Ignore delimiters inside quotes"),
        Field("keep_original", "bool", default=True, label="Keep the original column"),
    ]

    def validate(self, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        if cfg["mode"] == "to columns" and int(cfg.get("n_columns") or 0) < 1:
            problems.append("number of columns must be at least 1")
        return problems

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"[{cfg['column']}] on {cfg['delimiter']!r} {cfg['mode']}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        src, c = ins["in"], cfg["column"]
        delim = (cfg["delimiter"] or ",").replace("\\t", "\t")
        root = cfg.get("root") or c
        if cfg.get("ignore_quoted"):
            # tokens are either a quoted run or a run without the delimiter (Rust regex has no look-around)
            import re as _re
            pattern = '"[^"]*"|[^' + _re.escape(delim) + ']+'
            pieces = (f"{col(c)}.str.extract_all({lit(pattern)})"
                      f".list.eval(pl.element().str.strip_chars().str.strip_chars('\"'))")
        else:
            pieces = f"{col(c)}.str.split({lit(delim)})"
        ops: list[str] = []
        if cfg["mode"] == "to rows":
            ops.append(f"with_columns({pieces}.alias({lit(root)}))")
            ops.append(f"explode({lit(root)}, empty_as_null=True)")
            if cfg.get("skip_empty"):
                ops.append(f"filter({col(root)}.is_not_null() & ({col(root)}.str.strip_chars() != ''))")
            if not cfg["keep_original"] and root != c:
                ops.append(f"drop({lit(c)})")
            return f"{out} = {chain(src, *ops)}\n"
        n = int(cfg["n_columns"])
        exprs = []
        for i in range(n):
            name = f"{root}_{i + 1}"
            if i == n - 1 and cfg.get("extra") == "keep in last":
                e = (f"pl.col('_r2u_pieces').list.slice({i}).list.join({lit(delim)})"
                     f".replace('', None).alias({lit(name)})")
            else:
                e = f"pl.col('_r2u_pieces').list.get({i}, null_on_oob=True).alias({lit(name)})"
            exprs.append(e)
        body = "[\n        " + ",\n        ".join(exprs) + ",\n    ]"
        ops.append(f"with_columns({pieces}.alias('_r2u_pieces'))")
        ops.append(f"with_columns({body})")
        ops.append("drop('_r2u_pieces')")
        if not cfg["keep_original"]:
            ops.append(f"drop({lit(c)})")
        return f"{out} = {chain(src, *ops)}\n"


__all__ = ["Select", "Cleanse", "Filter", "Formula", "RecordID", "Sort", "Unique", "SelectRecords",
           "MultiFieldFormula", "DynamicRename", "TextToColumns", "cols"]
