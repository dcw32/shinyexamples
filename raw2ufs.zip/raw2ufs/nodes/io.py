"""Input and Output nodes."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from raw2ufs.engine.registry import Field, Node, chain, lit, node, pathlit

ENCODINGS = ["utf8", "utf8-lossy", "latin-1", "cp1252", "utf-16"]
IN_FORMATS = ["auto", "csv", "xlsx", "parquet", "geoparquet"]
OUT_FORMATS = ["csv", "xlsx", "parquet", "geoparquet"]


_RANGE_RE = re.compile(r"^\s*([A-Za-z]{1,3})(\d+)(?::([A-Za-z]{1,3})(\d+))?\s*$")


def parse_range(text: str) -> dict[str, Any]:
    """'B3:K200' -> header_row 2 (0-based), use_columns 'B:K', n_rows 197. 'B3' -> open-ended."""
    m = _RANGE_RE.match(text or "")
    if not m:
        raise ValueError(f"cell range {text!r} should look like B3 or B3:K200")
    c1, r1, c2, r2 = m.group(1).upper(), int(m.group(2)), (m.group(3) or "").upper(), m.group(4)
    if r1 < 1:
        raise ValueError("row numbers start at 1")
    use_columns = f"{c1}:{c2}" if c2 else (f"{c1}:XFD" if c1 != "A" else None)
    n_rows = int(r2) - r1 if r2 else None
    if n_rows is not None and n_rows < 0:
        raise ValueError("range end row is above the header row")
    return {"header_row": r1 - 1, "use_columns": use_columns, "n_rows": n_rows}


def detect_format(path: str) -> str:
    ext = Path(path).suffix.lower()
    return {".csv": "csv", ".txt": "csv", ".tsv": "csv", ".xlsx": "xlsx", ".xlsm": "xlsx",
            ".xls": "xlsx", ".parquet": "parquet", ".pq": "parquet"}.get(ext, "csv")


@node
class Input(Node):
    type = "input"
    label = "Input"
    category = "Input"
    inputs = []
    description = (
        "Read a file from disk into the workflow. Supports CSV/TXT (any delimiter and "
        "encoding), Excel (a named sheet, with the header on any row), Parquet and "
        "GeoParquet (geometry arrives as a WKB binary column). Tick *All columns as text* "
        "for messy schedules of values and set types later with **Select** - this avoids "
        "polars guessing a numeric type from the first rows and failing further down."
    )
    fields = [
        Field("path", "path", required=True, help="File to read. Relative paths resolve next to the workflow file; ${Name} inserts a constant."),
        Field("format", "choice", choices=IN_FORMATS, default="auto",
              help="auto picks by file extension."),
        Field("encoding", "choice", choices=ENCODINGS, default="utf8",
              help="CSV only. utf8-lossy replaces bad bytes instead of failing."),
        Field("delimiter", "string", default=",", help="CSV only. Use \\t for tab."),
        Field("has_header", "bool", default=True, help="CSV only."),
        Field("skip_rows", "int", default=0, help="CSV only. Rows to skip before the header."),
        Field("sheet", "string", default="", help="Excel only. Sheet name; blank = first sheet."),
        Field("header_row", "int", default=0, help="Excel only. 0-based row holding the column names."),
        Field("range", "string", default="", label="Cell range",
              help="Excel only. e.g. B3:K200 - header in row 3, columns B to K, data to row 200. "
                   "B3 alone means 'from B3 onwards'. Overrides header row."),
        Field("all_strings", "bool", default=False,
              label="All columns as text", help="Read every column as text; no type inference."),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"read {cfg['path']}"

    def validate(self, cfg: dict[str, Any]) -> list[str]:
        problems = super().validate(cfg)
        if cfg.get("range"):
            try:
                parse_range(cfg["range"])
            except ValueError as e:
                problems.append(str(e))
        return problems

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        fmt = cfg["format"] if cfg["format"] != "auto" else detect_format(cfg["path"])
        path = pathlit(cfg["path"])
        if fmt == "csv":
            sep = cfg["delimiter"].replace("\\t", "\t") or ","
            args = [path, f"separator={lit(sep)}", f"has_header={lit(bool(cfg['has_header']))}"]
            if cfg["skip_rows"]:
                args.append(f"skip_rows={int(cfg['skip_rows'])}")
            if cfg["all_strings"]:
                args.append("infer_schema_length=0")
            enc = cfg["encoding"]
            if enc in ("utf8", "utf8-lossy"):
                if enc != "utf8":
                    args.append(f"encoding={lit(enc)}")
                return f"{out} = pl.scan_csv({', '.join(args)})\n"
            args.append(f"encoding={lit(enc)}")
            return f"{out} = pl.read_csv({', '.join(args)}).lazy()\n"
        if fmt == "xlsx":
            args = [path]
            if cfg["sheet"]:
                args.append(f"sheet_name={lit(cfg['sheet'])}")
            read_opts: dict[str, Any] = {}
            if cfg.get("range"):
                rng = parse_range(cfg["range"])
                read_opts["header_row"] = rng["header_row"]
                if rng["use_columns"]:
                    read_opts["use_columns"] = rng["use_columns"]
                if rng["n_rows"] is not None:
                    read_opts["n_rows"] = rng["n_rows"]
            elif cfg["header_row"]:
                read_opts["header_row"] = int(cfg["header_row"])
            if cfg["all_strings"]:
                read_opts["dtypes"] = "string"
            if read_opts:
                args.append(f"read_options={lit(read_opts)}")
            return f"{out} = pl.read_excel({', '.join(args)}).lazy()\n"
        if fmt in ("parquet", "geoparquet"):
            return f"{out} = pl.scan_parquet({path})\n"
        raise ValueError(f"unsupported input format {fmt!r}")


@node
class Output(Node):
    type = "output"
    label = "Output"
    category = "Output"
    is_sink = True
    description = (
        "Write the incoming data to a file: CSV, Excel, Parquet or GeoParquet. "
        "*Format tag* labels what the file is (for example `OED-Loc` or `OED-Acc`) so "
        "downstream tools and validators know how to treat it; it is recorded in the "
        "workflow and in the exported script but does not change the file contents."
    )
    fields = [
        Field("path", "path", required=True, help="Destination file. Missing folders are created; ${Name} inserts a constant."),
        Field("format", "choice", choices=OUT_FORMATS, default="csv"),
        Field("format_tag", "string", default="", label="Format tag",
              help="Free label such as OED-Loc, OED-Acc, UFS-Loc."),
        Field("delimiter", "string", default=",", help="CSV only."),
        Field("geometry_col", "column", default="geometry", help="GeoParquet only. WKB geometry column."),
        Field("crs", "string", default="EPSG:4326", help="GeoParquet only. CRS of the geometry column."),
    ]
    helpers = ["_r2u_write_geoparquet"]

    def summary(self, cfg: dict[str, Any]) -> str:
        tag = f" [{cfg['format_tag']}]" if cfg.get("format_tag") else ""
        return f"write {cfg['format']} to {cfg['path']}{tag}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        src, path, fmt = ins["in"], pathlit(cfg["path"]), cfg["format"]
        mkdir = f"os.makedirs(os.path.dirname(os.path.abspath({path})), exist_ok=True)\n"
        if fmt == "csv":
            sep = cfg["delimiter"].replace("\\t", "\t") or ","
            extra = f", separator={lit(sep)}" if sep != "," else ""
            return mkdir + f"{src}.collect().write_csv({path}{extra})\n"
        if fmt == "xlsx":
            return mkdir + f"{src}.collect().write_excel({path})\n"
        if fmt == "parquet":
            return mkdir + f"{src}.collect().write_parquet({path})\n"
        if fmt == "geoparquet":
            return mkdir + (f"_r2u_write_geoparquet({src}, {path}, geometry_col={lit(cfg['geometry_col'])}, "
                            f"crs={lit(cfg['crs'])})\n")
        raise ValueError(f"unsupported output format {fmt!r}")


__all__ = ["Input", "Output", "chain"]
