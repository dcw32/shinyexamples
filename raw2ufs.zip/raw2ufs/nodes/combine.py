"""Nodes that combine several data streams: Join, Union."""

from __future__ import annotations

from typing import Any

from raw2ufs.engine.registry import Field, Node, chain, lit, node

JOIN_TYPES = ["inner", "left", "right", "full", "semi", "anti"]


@node
class Join(Node):
    type = "join"
    category = "Combine"
    inputs = ["left", "right"]
    description = (
        "Combine two streams on one or more key pairs. Key columns may have different "
        "names on each side but must have the same type (use **Select** to cast first). "
        "Join types: *inner* keeps matches only; *left* keeps every left row; *right* "
        "keeps every right row; *full* keeps everything; *semi* keeps left rows that have "
        "a match (no right columns); *anti* keeps left rows with no match. Right-side "
        "columns whose names clash with left-side ones are renamed with the *Right prefix* "
        "(`Right_Name`). *Output fields* optionally keeps only the listed columns, in that "
        "order, with renames; leave it empty to keep everything."
    )
    fields = [
        Field("how", "choice", choices=JOIN_TYPES, default="left"),
        Field("keys", "table", required=True, columns=[
            Field("left", "column", required=True, port="left"),
            Field("right", "column", required=True, port="right"),
        ]),
        Field("right_prefix", "string", default="Right_", label="Right prefix",
              help="Put in front of right-hand column names that clash with left-hand ones."),
        Field("fields", "table", default=[], label="Output fields", columns=[
            Field("column", "column", required=True, port="out", help="a joined column (Right_ names for clashes)"),
            Field("rename", "string", help="blank keeps the name"),
        ]),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        keys = ", ".join(f"{k['left']}={k['right']}" for k in cfg["keys"])
        return f"{cfg['how']} join on {keys}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        left_on = [k["left"] for k in cfg["keys"]]
        right_on = [k["right"] for k in cfg["keys"]]
        prefix = cfg.get("right_prefix") or "Right_"
        code = (f"{out} = {ins['left']}.join(\n"
                f"    {ins['right']},\n"
                f"    left_on={lit(left_on)},\n"
                f"    right_on={lit(right_on)},\n"
                f"    how={lit(cfg['how'])},\n"
                f"    suffix='__right',\n"
                f")\n"
                f"# clashing right-hand columns become {prefix}<name>\n"
                f"{out} = {out}.rename({{c: {lit(prefix)} + c[:-7] for c in {out}.collect_schema().names() if c.endswith('__right')}})\n")
        if cfg.get("fields"):
            exprs = []
            for f in cfg["fields"]:
                e = f"pl.col({lit(f['column'])})"
                if f.get("rename") and f["rename"] != f["column"]:
                    e += f".alias({lit(f['rename'])})"
                exprs.append(e)
            body = "[\n        " + ",\n        ".join(exprs) + ",\n    ]"
            code += f"{out} = {out}.select({body})\n"
        return code


@node
class AppendFields(Node):
    type = "append_fields"
    label = "Append Fields"
    category = "Combine"
    inputs = ["target", "source"]
    description = (
        "Append every column of a small *source* table to every row of the *target* "
        "table (a cartesian product). Typical use: attach a one-row table of parameters "
        "or totals to each record. Refuses to run when the source has more rows than the "
        "limit, because the result size is target rows × source rows."
    )
    fields = [
        Field("max_source_rows", "int", default=1000, label="Source row limit",
              help="Safety cap on the number of source rows."),
        Field("prefix", "string", default="", help="Put in front of the appended column names (also fixes clashes)."),
    ]
    helpers = ["_r2u_append_fields"]

    def summary(self, cfg: dict[str, Any]) -> str:
        return "cartesian product with source"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        return (f"{out} = _r2u_append_fields({ins['target']}, {ins['source']}, "
                f"prefix={lit(cfg.get('prefix') or '')}, max_source_rows={int(cfg['max_source_rows'])})\n")


@node
class Union(Node):
    type = "union"
    category = "Combine"
    variadic = True
    description = (
        "Stack the rows of two or more streams. *By name* lines up columns by name and "
        "fills missing ones with null (the usual choice when files have slightly "
        "different layouts); *By position* requires identical column order and names. "
        "Compatible numeric types are widened automatically."
    )
    fields = [
        Field("match", "choice", choices=["by name", "by position"], default="by name"),
    ]

    def summary(self, cfg: dict[str, Any]) -> str:
        return f"stack {cfg['match']}"

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        how = "diagonal_relaxed" if cfg["match"] == "by name" else "vertical_relaxed"
        frames = ", ".join(ins["in"])
        return f"{out} = pl.concat([{frames}], how={lit(how)})\n"


__all__ = ["Join", "Union", "AppendFields"]
