"""Built-in node library. Importing this package registers every node type.

Add a new node by dropping a module here that defines `@node` classes and
importing it below (or, for third-party extensions, importing it anywhere
before the graph is compiled).
"""

from raw2ufs.nodes import io, prepare, combine, reshape, spatial, annotate  # noqa: F401
