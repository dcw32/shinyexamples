"""Nodes that carry no data: Comment."""

from __future__ import annotations

from typing import Any

from raw2ufs.engine.registry import Field, Node, node


@node
class Comment(Node):
    type = "comment"
    category = "Annotate"
    inputs = []
    is_sink = True
    description = (
        "A sticky note on the canvas. It has no ports and does nothing to data; its text is "
        "written into the exported script as a comment block at that point, so notes made "
        "while building a workflow travel with the code."
    )
    fields = [Field("text", "text", default="", label="Note")]

    def summary(self, cfg: dict[str, Any]) -> str:
        first = (cfg.get("text") or "").strip().split("\n")[0]
        return first[:80]

    def emit(self, cfg: dict[str, Any], ins: dict[str, Any], out: str) -> str:
        lines = (cfg.get("text") or "").rstrip().split("\n") or [""]
        return "".join(f"# {line}".rstrip() + "\n" for line in lines)
