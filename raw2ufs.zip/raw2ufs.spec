# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec: one-folder build with two executables sharing the same bundle.

    pyinstaller raw2ufs.spec --noconfirm

dist/Raw2UFS/
    Raw2UFS(.exe)        windowed desktop app (pywebview); also `--serve` for browser mode
    raw2ufs-cli(.exe)    console CLI: run / export / validate / schema / preview / nodes / docs
"""

import sys
from pathlib import Path

from PyInstaller.utils.hooks import collect_all, collect_submodules

ROOT = Path(SPECPATH)

datas = [
    (str(ROOT / "ui" / "index.html"), "ui"),             # the front end
    (str(ROOT / "raw2ufs" / "helpers.py"), "raw2ufs"),   # source text inlined into exported scripts
]
binaries = []
hiddenimports = [
    "raw2ufs.nodes.io", "raw2ufs.nodes.prepare", "raw2ufs.nodes.combine", "raw2ufs.nodes.reshape",
    "raw2ufs.nodes.spatial", "raw2ufs.nodes.annotate",
    "fastexcel", "xlsxwriter",
]
hiddenimports += collect_submodules("raw2ufs")
hiddenimports += ["polars", "numpy", "shapely"]

# Optional packages: bundle everything they ship when present, skip quietly when not.
for pkg in ("webview", "clr_loader", "pythonnet", "shapely", "fastexcel"):
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hiddenimports += h
    except Exception:  # noqa: BLE001
        pass

if sys.platform == "win32":
    hiddenimports += ["webview.platforms.winforms", "webview.platforms.edgechromium", "clr"]
elif sys.platform == "darwin":
    hiddenimports += ["webview.platforms.cocoa"]
else:
    hiddenimports += ["webview.platforms.gtk", "webview.platforms.qt"]

# Optional heavyweight packages polars/numpy can talk to but Raw2UFS never uses.
excludes = ["pytest", "playwright", "PyInstaller", "tkinter", "matplotlib", "IPython", "jupyter",
            "pyarrow", "pandas", "scipy", "PIL", "pillow", "cryptography", "lxml", "openpyxl",
            "hypothesis", "sqlalchemy", "altair", "great_tables", "deltalake", "pydantic", "torch"]

a = Analysis(
    [str(ROOT / "launcher.py")],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=sorted(set(hiddenimports)),
    excludes=excludes,
    noarchive=False,
)
pyz = PYZ(a.pure)

gui = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="Raw2UFS",
    console=False,               # windowed: no console for the desktop app
    icon=None,
)
cli = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="raw2ufs-cli",
    console=True,
)
coll = COLLECT(gui, cli, a.binaries, a.datas, strip=False, upx=False, name="Raw2UFS")
