#!/usr/bin/env bash
# Build the one-folder distribution for the current OS (Linux/macOS): dist/Raw2UFS/
set -e
python -m PyInstaller raw2ufs.spec --noconfirm
echo "Built dist/Raw2UFS/Raw2UFS (desktop, or --serve) and dist/Raw2UFS/raw2ufs-cli"
