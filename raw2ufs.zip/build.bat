@echo off
REM Build the Windows one-folder distribution: dist\Raw2UFS\Raw2UFS.exe and raw2ufs-cli.exe
REM Run from a Python environment that has the project installed:
REM     pip install -e ".[spatial,excel-out,ui,build]"
python -m PyInstaller raw2ufs.spec --noconfirm
if errorlevel 1 exit /b 1
echo.
echo Built dist\Raw2UFS\Raw2UFS.exe  (desktop)  and  dist\Raw2UFS\raw2ufs-cli.exe  (command line)
echo Smoke test:  dist\Raw2UFS\raw2ufs-cli.exe run examples\sov_to_oed.json
