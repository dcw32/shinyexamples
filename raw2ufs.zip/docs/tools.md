# Raw2UFS tool reference

Every tool in a workflow becomes one code block in the exported script, tagged `# Raw2UFS_<TOOL>: <node id> "<node name>" - <summary>`. Data flows between tools as polars LazyFrames named `df_<node id>`.

## Input

### Input  `Raw2UFS_INPUT`

Read a file from disk into the workflow. Supports CSV/TXT (any delimiter and encoding), Excel (a named sheet, with the header on any row), Parquet and GeoParquet (geometry arrives as a WKB binary column). Tick *All columns as text* for messy schedules of values and set types later with **Select** - this avoids polars guessing a numeric type from the first rows and failing further down.

Input ports: none. One output.

Options:

- `path` (*path*, **required**): File to read. Relative paths resolve next to the workflow file; ${Name} inserts a constant.
- `format` (*choice*, one of `auto`, `csv`, `xlsx`, `parquet`, `geoparquet`, default `auto`): auto picks by file extension.
- `encoding` (*choice*, one of `utf8`, `utf8-lossy`, `latin-1`, `cp1252`, `utf-16`, default `utf8`): CSV only. utf8-lossy replaces bad bytes instead of failing.
- `delimiter` (*string*, default `,`): CSV only. Use \t for tab.
- `has_header` (*bool*, default `True`): CSV only.
- `skip_rows` (*int*): CSV only. Rows to skip before the header.
- `sheet` (*string*): Excel only. Sheet name; blank = first sheet.
- `header_row` (*int*): Excel only. 0-based row holding the column names.
- `range` (*string*): Excel only. e.g. B3:K200 - header in row 3, columns B to K, data to row 200. B3 alone means 'from B3 onwards'. Overrides header row.
- `all_strings` (*bool*): Read every column as text; no type inference.

## Prepare

### Cleanse  `Raw2UFS_CLEANSE`

Apply common clean-up steps to chosen columns (blank = all columns). Text steps only touch text columns and *Nulls to 0* only numeric ones, so it is safe to run on a whole table. Steps run in the order listed in the config panel: null replacement, whitespace, character removal, case. Row/column dropping applies to the whole table.

Input ports: `in`. One output.

Options:

- `columns` (*columns*): Blank = every column.
- `null_to_blank` (*bool*)
- `null_to_zero` (*bool*)
- `trim` (*bool*)
- `collapse_whitespace` (*bool*)
- `remove_whitespace` (*bool*)
- `remove_letters` (*bool*)
- `remove_numbers` (*bool*)
- `remove_punctuation` (*bool*)
- `case` (*choice*, one of `upper`, `lower`, `title` or blank)
- `drop_null_rows` (*bool*)
- `drop_null_columns` (*bool*)

### Dynamic Rename  `Raw2UFS_DYNAMIC_RENAME`

Rename columns in bulk. *First row* uses the values in the first data row as the column names and drops that row (for files read with *All columns as text* whose real header sits below junk rows). *Add prefix/suffix* and *Remove prefix/suffix* change every column's name (or only the chosen ones). Duplicate or blank names from the first row get `_2`, `_3` ... appended.

Input ports: `in`. One output.

Options:

- `mode` (*choice*, one of `first row`, `add prefix/suffix`, `remove prefix/suffix`, default `first row`)
- `columns` (*columns*): Prefix/suffix modes only. Blank = every column.
- `prefix` (*string*)
- `suffix` (*string*)

### Filter  `Raw2UFS_FILTER`

Keep only the rows that meet a condition. *Simple* mode builds the condition from column / operator / value rows combined with AND or OR; the *Type* column (filled in from the data when you pick a column) decides whether the value is compared as a number, text or date. *In list* takes a comma-separated list. *Formula* mode accepts any Raw2UFS formula that returns TRUE/FALSE, e.g. `[TIV] > 0 AND NOT IsNull([Postcode])`.

Input ports: `in`. One output.

Options:

- `mode` (*choice*, one of `simple`, `formula`, default `simple`)
- `combine` (*choice*, one of `and`, `or`, default `and`): Simple mode: how the conditions combine.
- `conditions` (*table*)
  Each row has:
  - `column` (*column*, **required**)
  - `op` (*choice*, one of `=`, `<>`, `<`, `<=`, `>`, `>=`, `contains`, `starts with`, `ends with`, `is null`, `is not null`, `in list`, default `=`)
  - `value` (*string*)
  - `dtype` (*choice*, one of `string`, `int`, `float`, `bool`, `date`, `datetime`, `binary` or blank): How to read the value; filled in from the column's type.
- `formula` (*formula*)

### Formula  `Raw2UFS_FORMULA`

Create or overwrite columns with a Raw2UFS formula. Rows are evaluated top to bottom, so a later formula can use a column created above it. Syntax: `[Column]` references, arithmetic `+ - * / % ^`, comparisons `= <> < <= > >=`, `AND OR NOT`, `IN ('a','b')`, text in single quotes, `IF cond THEN a ELSEIF cond THEN b ELSE c ENDIF`, and functions such as `Upper`, `Trim`, `Left`, `Replace`, `ToNumber`, `IfNull`, `Round`, `ToDate` (see the Formula functions reference). Optionally cast the result to a type.

Input ports: `in`. One output.

Options:

- `columns` (*table*, **required**)
  Each row has:
  - `name` (*column*, **required**): Output column: pick an existing one to overwrite it, or type a new name.
  - `formula` (*formula*, **required**)
  - `dtype` (*choice*, one of `string`, `int`, `float`, `bool`, `date`, `datetime`, `binary` or blank): Optional type for the result.

### Multi-Field Formula  `Raw2UFS_MULTI_FIELD_FORMULA`

Apply one formula to several columns at once. Write the formula with `[_CurrentField_]` standing for each selected column in turn (and `[_CurrentFieldName_]` for its name as text), e.g. `IfNull([_CurrentField_], 0) * 1000` or `Trim(Upper([_CurrentField_]))`. Results overwrite the columns, or go to new columns named with a prefix and/or suffix.

Input ports: `in`. One output.

Options:

- `columns` (*columns*, **required**)
- `formula` (*formula*, **required**): Use [_CurrentField_] for the column being processed.
- `output` (*choice*, one of `overwrite`, `new columns`, default `overwrite`)
- `prefix` (*string*): New columns only.
- `suffix` (*string*, default `_new`): New columns only.
- `dtype` (*choice*, one of `string`, `int`, `float`, `bool`, `date`, `datetime`, `binary` or blank): Optional type for the results.

### Record ID  `Raw2UFS_RECORD_ID`

Add a sequential integer column starting at *Start*. With *Group by* columns the numbering restarts within each group (row order within the group follows the incoming order, so put a **Sort** in front if it matters).

Input ports: `in`. One output.

Options:

- `name` (*string*, default `RecordID`, **required**)
- `start` (*int*, default `1`)
- `group_by` (*columns*)

### Select  `Raw2UFS_SELECT`

Choose which columns to keep, rename them and set their data types. Columns not listed are dropped unless *Keep other columns* is ticked. Type conversion is non-strict: values that cannot be converted become null rather than failing the workflow (use **Filter** with `IsNull` afterwards to find them). Converting text to int/float ignores internal spaces, so `12 500` becomes 12500.

Input ports: `in`. One output.

Options:

- `columns` (*table*, **required**)
  Each row has:
  - `name` (*column*, **required**)
  - `rename` (*string*): New name; blank keeps the current name.
  - `dtype` (*choice*, one of `string`, `int`, `float`, `bool`, `date`, `datetime`, `binary` or blank): Blank keeps the current type.
- `keep_others` (*bool*)

### Select Records  `Raw2UFS_SELECT_RECORDS`

Keep rows by position (1-based, inclusive). Comma-separated ranges: `1` the first row only, `2-` from the second row to the end, `-10` the first ten, `15-20` rows 15 to 20. Row numbers follow the incoming order, so put a **Sort** in front if it matters.

Input ports: `in`. One output.

Options:

- `ranges` (*string*, default `1-`, **required**): e.g. 1  |  2-  |  15-20, 30-

### Sort  `Raw2UFS_SORT`

Order rows by one or more columns, each ascending or descending.

Input ports: `in`. One output.

Options:

- `by` (*table*, **required**)
  Each row has:
  - `column` (*column*, **required**)
  - `descending` (*bool*)
- `nulls_last` (*bool*, default `True`)

### Text To Columns  `Raw2UFS_TEXT_TO_COLUMNS`

Split a text column on a delimiter. *To columns* makes N new columns named `<root>_1 .. <root>_N`; pieces beyond N are dropped, or kept in the last column with *Extra pieces = keep in last*. *To rows* makes one row per piece (the other columns are repeated). *Ignore delimiters inside quotes* keeps `"a, b"` together. Use `\t` for a tab delimiter.

Input ports: `in`. One output.

Options:

- `column` (*column*, **required**)
- `delimiter` (*string*, default `,`, **required**)
- `mode` (*choice*, one of `to columns`, `to rows`, default `to columns`)
- `n_columns` (*int*, default `2`): To columns only.
- `root` (*string*): Blank = the column name.
- `extra` (*choice*, one of `drop`, `keep in last`, default `drop`): To columns only: what happens to text beyond the last column.
- `skip_empty` (*bool*, default `True`)
- `ignore_quoted` (*bool*)
- `keep_original` (*bool*, default `True`)

### Unique  `Raw2UFS_UNIQUE`

Remove duplicate rows. With *Columns* set, rows are duplicates when those columns match and the first (or last) occurrence is kept; blank = whole row.

Input ports: `in`. One output.

Options:

- `columns` (*columns*): Blank = compare whole rows.
- `keep` (*choice*, one of `first`, `last`, `any`, default `first`)

## Combine

### Append Fields  `Raw2UFS_APPEND_FIELDS`

Append every column of a small *source* table to every row of the *target* table (a cartesian product). Typical use: attach a one-row table of parameters or totals to each record. Refuses to run when the source has more rows than the limit, because the result size is target rows × source rows.

Input ports: `target`, `source`. One output.

Options:

- `max_source_rows` (*int*, default `1000`): Safety cap on the number of source rows.
- `prefix` (*string*): Put in front of the appended column names (also fixes clashes).

### Join  `Raw2UFS_JOIN`

Combine two streams on one or more key pairs. Key columns may have different names on each side but must have the same type (use **Select** to cast first). Join types: *inner* keeps matches only; *left* keeps every left row; *right* keeps every right row; *full* keeps everything; *semi* keeps left rows that have a match (no right columns); *anti* keeps left rows with no match. Right-side columns whose names clash with left-side ones are renamed with the *Right prefix* (`Right_Name`). *Output fields* optionally keeps only the listed columns, in that order, with renames; leave it empty to keep everything.

Input ports: `left`, `right`. One output.

Options:

- `how` (*choice*, one of `inner`, `left`, `right`, `full`, `semi`, `anti`, default `left`)
- `keys` (*table*, **required**)
  Each row has:
  - `left` (*column*, **required**, from port `left`)
  - `right` (*column*, **required**, from port `right`)
- `right_prefix` (*string*, default `Right_`): Put in front of right-hand column names that clash with left-hand ones.
- `fields` (*table*)
  Each row has:
  - `column` (*column*, **required**, from port `out`): a joined column (Right_ names for clashes)
  - `rename` (*string*): blank keeps the name

### Union  `Raw2UFS_UNION`

Stack the rows of two or more streams. *By name* lines up columns by name and fills missing ones with null (the usual choice when files have slightly different layouts); *By position* requires identical column order and names. Compatible numeric types are widened automatically.

Input ports: `in` (many). One output.

Options:

- `match` (*choice*, one of `by name`, `by position`, default `by name`)

## Reshape

### Cross Tab  `Raw2UFS_CROSSTAB`

Long to wide: one output row per combination of *Key columns*, and one new column per distinct value of *Header column*, filled from *Value column* using the aggregation. The output columns depend on the data, so schema preview needs a run.

Input ports: `in`. One output.

Options:

- `index` (*columns*, **required**)
- `on` (*column*, **required**)
- `values` (*column*, **required**)
- `aggregate` (*choice*, one of `first`, `sum`, `mean`, `min`, `max`, `median`, `len`, default `first`)

### Summarise  `Raw2UFS_SUMMARISE`

Group rows by one or more columns and aggregate others: count, count distinct, sum, mean, median, min, max, first, last, std, or concat (joins text values with commas). With no group columns the whole table collapses to one row. Add a *Row count* column name to get the number of rows per group.

Input ports: `in`. One output.

Options:

- `group_by` (*columns*)
- `aggregations` (*table*)
  Each row has:
  - `column` (*column*, **required**)
  - `function` (*choice*, one of `count`, `count_distinct`, `sum`, `mean`, `median`, `min`, `max`, `first`, `last`, `std`, `concat`, default `sum`)
  - `alias` (*string*): Output name; blank = column_function.
- `row_count` (*string*): Optional: name of a column holding the number of rows per group.

### Transpose  `Raw2UFS_TRANSPOSE`

Wide to long: turn several value columns into two columns, one holding the original column name and one holding the value. *Key columns* are repeated on every output row. Blank *Value columns* = every non-key column. Tick *As text* when the value columns have mixed types.

Input ports: `in`. One output.

Options:

- `index` (*columns*)
- `on` (*columns*): Blank = all others.
- `variable_name` (*string*, default `Name`)
- `value_name` (*string*, default `Value`)
- `as_text` (*bool*)

## Spatial

### Create Points  `Raw2UFS_CREATE_POINTS`

Build point geometries from latitude and longitude columns into a WKB binary column (default `geometry`). Rows with a missing coordinate get a null geometry. Coordinates are assumed to be WGS84 (EPSG:4326).

Input ports: `in`. One output.

Options:

- `lat` (*column*, **required**)
- `lon` (*column*, **required**)
- `geometry_col` (*string*, default `geometry`)

### Spatial Match  `Raw2UFS_SPATIAL_MATCH`

Point-in-polygon join. Every row on the *points* port is matched against the polygons on the *polygons* port with a shapely STRtree, and the polygon's attribute columns are appended. *left* keeps unmatched points with null attributes, *inner* drops them. A point inside several overlapping polygons yields one row per polygon. Both geometry columns must be WKB (as produced by **Create Points** or read from GeoParquet) and share a CRS.

Input ports: `points`, `polygons`. One output.

Options:

- `point_col` (*column*, default `geometry`, from port `points`)
- `polygon_col` (*column*, default `geometry`, from port `polygons`)
- `how` (*choice*, one of `left`, `inner`, default `left`)
- `predicate` (*choice*, one of `within`, `intersects`, default `within`)
- `suffix` (*string*, default `_poly`): Added to clashing polygon column names.

## Output

### Output  `Raw2UFS_OUTPUT`

Write the incoming data to a file: CSV, Excel, Parquet or GeoParquet. *Format tag* labels what the file is (for example `OED-Loc` or `OED-Acc`) so downstream tools and validators know how to treat it; it is recorded in the workflow and in the exported script but does not change the file contents.

Input ports: `in`. Writes a file; no output.

Options:

- `path` (*path*, **required**): Destination file. Missing folders are created; ${Name} inserts a constant.
- `format` (*choice*, one of `csv`, `xlsx`, `parquet`, `geoparquet`, default `csv`)
- `format_tag` (*string*): Free label such as OED-Loc, OED-Acc, UFS-Loc.
- `delimiter` (*string*, default `,`): CSV only.
- `geometry_col` (*column*, default `geometry`): GeoParquet only. WKB geometry column.
- `crs` (*string*, default `EPSG:4326`): GeoParquet only. CRS of the geometry column.

## Annotate

### Comment  `Raw2UFS_COMMENT`

A sticky note on the canvas. It has no ports and does nothing to data; its text is written into the exported script as a comment block at that point, so notes made while building a workflow travel with the code.

Input ports: none. Writes a file; no output.

Options:

- `text` (*text*)

## Formula functions

Used by **Formula** and **Filter** (formula mode). Column references are written `[Column Name]`, text in single quotes. Operators: `+ - * / % ^`, comparisons `= <> < <= > >=`, logic `AND OR NOT`, membership `IN ('a', 'b')`, and `IF cond THEN a ELSEIF cond THEN b ELSE c ENDIF`. Function names are not case-sensitive.

- `Upper(text)` - Convert to upper case.
- `Lower(text)` - Convert to lower case.
- `Title(text)` - Convert to Title Case.
- `Trim(text)` - Remove leading and trailing whitespace.
- `LTrim(text)` - Remove leading whitespace.
- `RTrim(text)` - Remove trailing whitespace.
- `Length(text)` - Number of characters.
- `Left(text, n)` - First n characters.
- `Right(text, n)` - Last n characters.
- `Substring(text, start, length)` - Characters from 0-based `start`, `length` long.
- `Contains(text, part)` - True if `part` occurs in text (case-sensitive).
- `StartsWith(text, prefix)` - True if text starts with prefix.
- `EndsWith(text, suffix)` - True if text ends with suffix.
- `Replace(text, find, replacement)` - Replace every occurrence of `find` (plain text).
- `RegexReplace(text, pattern, replacement)` - Replace every regex match.
- `RegexMatch(text, pattern)` - True if the regex matches anywhere in text.
- `PadLeft(text, width, char)` - Left-pad with `char` to `width` characters.
- `PadRight(text, width, char)` - Right-pad with `char` to `width` characters.
- `Concat(a, b, ...)` - Join values as text (null if any part is null).
- `ToString(value)` - Convert to text.
- `ToNumber(value)` - Convert to a decimal number; unparseable values become null.
- `ToInt(value)` - Convert to a whole number; unparseable values become null.
- `ToDate(text, format)` - Parse text to a date using a strftime format such as '%Y-%m-%d'.
- `ToDateTime(text, format)` - Parse text to a date-time using a strftime format.
- `IIF(condition, x, y)` - x where the condition is true, otherwise y (a compact IF ... THEN ... ELSE ... ENDIF).
- `Switch(value, default, case1, result1, ..., caseN, resultN)` - Compare `value` with each case in turn and return the matching result; `default` when none match.
- `IsNull(value)` - True where the value is null.
- `IsEmpty(value)` - True where the value is null or an empty string.
- `IfNull(value, fallback)` - The value, or `fallback` where it is null.
- `Coalesce(a, b, ...)` - First non-null value.
- `Null()` - A null value.
- `Abs(x)` - Absolute value.
- `Round(x, decimals)` - Round to `decimals` places (default 0).
- `Floor(x)` - Round down.
- `Ceil(x)` - Round up.
- `Sqrt(x)` - Square root.
- `Pow(x, y)` - x to the power y.
- `Mod(x, y)` - Remainder of x / y.
- `Min(a, b, ...)` - Smallest of the values, per row.
- `Max(a, b, ...)` - Largest of the values, per row.
- `Year(date)` - Year of a date.
- `Month(date)` - Month of a date (1-12).
- `Day(date)` - Day of month.
- `DateDiffDays(later, earlier)` - Whole days between two dates.
