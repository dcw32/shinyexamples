# Raw2UFS - how the code base fits together

A guide for people. The machine-oriented companion is `CODEBASE.md`; the tool
reference is `tools.md` (generated); open work is in `TODO.md`.

## What it is

Raw2UFS turns raw schedules of values (Excel/CSV exports of insured locations,
plus lookup tables and GeoParquet zone polygons) into OED/UFS exposure files.
You build a workflow on a canvas from tools such as Input, Cleanse, Select,
Formula, Join and Output; the engine runs it with polars; and you can export
the whole thing as a plain Python script that needs nothing but polars.

## The three ideas that shape everything

**A workflow is a JSON file.** `nodes` (tools with a `type` and a `config`),
`edges` (connections between ports) and optional `containers` (visual groups
that can be switched off). The UI edits that file, the engine runs it, the
exporter turns it into a script. Nothing else is stored anywhere.

**A tool emits polars source code; it never runs polars itself.** Every tool is
a small class whose `emit()` returns Python text such as
`df_pick = df_tidy.select([...])`. The runner `exec`s those blocks one after
another; the exporter writes the same blocks to a `.py` file. Because they are
literally the same code, the app and the script cannot disagree, and a tool is
written exactly once.

**The UI knows nothing about individual tools.** Each tool declares its config
as a list of `Field`s (kind, label, default, choices...). The inspector renders
a panel from that list. Adding a tool needs zero front-end changes.

## Walking through a run

1. `ui/index.html` (or the CLI) hands the workflow JSON to `ui/api.py`.
2. `Graph.from_dict` (`engine/graph.py`) builds the in-memory graph and can
   give a topological order, ancestors of a node, and the set of nodes that
   are disabled by containers.
3. `compile_graph` (`engine/runner.py`) walks the nodes in order, fills in
   config defaults, validates, resolves which upstream variable feeds each
   port, and asks the tool to `emit()` its code. Result: a list of `Block`s.
4. `build_plans` executes the blocks in a namespace that has `pl`, `cs`, `os`
   and the helpers. Each block assigns a polars **LazyFrame** to `df_<id>` -
   no data is read yet. If a node's result is in the cache
   (`engine/cache.py`) its block is replaced by `pl.scan_parquet(cached)`.
5. `schema()` asks the lazy plan for its columns (free), `preview()` collects
   the first rows, `run()` executes the sink blocks (Output writes files). The
   UI runs it on a worker thread (`Api.start_run` / `job_status` /
   `cancel_job`) so the canvas stays live and per-tool timings appear as
   they complete; cancel takes effect before the next tool.
6. When a block fails, `attribute()` finds the tool actually at fault: polars
   is lazy, so a bad formula only raises when the Output downstream collects.
   The runner tries each upstream plan on its own (`collect_schema()`, then
   `head(1).collect()`) and blames the first that fails; the `RunError` carries
   `node_id` (culprit, red on the canvas) and `surfaced_at` (the tool that
   raised, lighter red). `explain()` trims the polars message to its first
   line, adds a hint, and for a missing column lists the available ones with
   a nearest match. Python warnings raised while a block runs (polars,
   fastexcel, shapely) are captured and shown under that tool in the run log.
7. `export_script` (`export/to_script.py`) writes the same blocks to a file
   with a `# Raw2UFS_<TOOL>` tag per block, inlines any helper functions the
   code calls, and comments out blocks that are disabled.

## Directory map

```
raw2ufs/
  engine/
    graph.py      Graph, NodeSpec, Edge, Container; JSON in/out; topo order; disabled_nodes()
    registry.py   Node base class, Field spec, @node decorator, REGISTRY, lit()/col()/chain() helpers
    runner.py     compile_graph -> Blocks; build_plans / schema / preview / run
    cache.py      Cache: parquet per node keyed on everything upstream (run-to-here)
    analysis.py   infer_types (for Select), profile (nulls/distinct/min/max)
    dtypes.py     user-facing type names <-> polars types
  formula/
    lexer.py parser.py ast.py   the Alteryx-style formula language
    emit.py                     AST -> polars expression source; FUNCTIONS table
  nodes/
    io.py        Input, Output          prepare.py  Select, SelectRecords, Cleanse, Filter, Formula,
                                                    MultiFieldFormula, DynamicRename, TextToColumns,
                                                    RecordID, Sort, Unique
    combine.py   Join, Union, AppendFields          reshape.py  Summarise, Transpose, CrossTab
    spatial.py   CreatePoints, SpatialMatch        annotate.py  Comment
  helpers.py     functions inlined into exported scripts (spatial, geoparquet, null-row drops)
  export/
    to_script.py standalone polars script          docs.py  tools.md generator
  cli.py         run / export / validate / schema / preview / nodes / docs
ui/
  index.html     the whole front end: palette, canvas, inspector, bottom panes (vanilla JS)
  api.py         the JSON contract the front end calls (also usable by any other front end)
  app.py         pywebview desktop window       server.py  stdlib HTTP server for browser mode
examples/        sov_to_oed.json + make_sample_data.py (messy sample inputs)
tests/           engine, formula, cache, export (engine == script golden test), playwright UI
docs/            tools.md (generated), OVERVIEW.md, CODEBASE.md, TODO.md, ui.png
```

## Conventions worth knowing

- Relative paths in a workflow resolve against `BASE_DIR`: the workflow's
  folder (`Graph.base_dir`, set on load, never serialised) in the app and CLI,
  the script's own folder once exported. Nothing ever `chdir`s, so several
  workflows can be open at once.
- Workflow constants (`graph.constants`) are `[$Name]` in formulas and
  `${Name}` in path/text options; emitted as `K_Name` Python variables. The
  runner puts them in the execution namespace, the exporter writes them at the
  top of the script, and the CLI can override them with `--set`.
- Three ways to switch things off, all feeding `Graph.disabled_nodes()`: a
  container's `enabled`, a node's own `enabled`, and the workflow's
  `run_outputs` (every Output at once). Disabled = skipped by run/validate,
  commented out in the script, downstream nodes included.
- Every tool's output variable is `df_<node id>` (`NodeSpec.var` sanitises the
  id). Rename a node's id in the UI and the script variable follows.
- Type conversion is non-strict: unconvertible values become null rather than
  failing. Text -> int/float strips internal spaces (`12 500`).
- Geometry travels as a WKB `Binary` column; only shapely is needed.
- Containers can nest (a node can be in several, one inside another); a
  container's `nodes` always lists every tool inside it, nested ones
  included, so `Graph.disabled_nodes()` needs no special case for nesting -
  disabling any ancestor container disables a node and everything
  downstream. Nesting itself is a UI-only, geometric notion (box containment
  by area) - nothing about it is stored beyond the flat `nodes` list.
- The cache key includes the size and mtime of every input file upstream, so
  it invalidates itself; nothing ever needs clearing for correctness.
- The formula language is parsed to an AST; user text is never `eval`ed.
  The emitted polars source is what the engine `eval`s - our own output.

## How to add a new tool, step by step

Suppose we want a **Head** tool that keeps the first N rows.

**1. Pick a module.** Row/column preparation lives in `raw2ufs/nodes/prepare.py`;
combining streams in `combine.py`; aggregation in `reshape.py`; spatial in
`spatial.py`. A new family gets a new file plus one import line in
`raw2ufs/nodes/__init__.py`.

**2. Write the class.**

```python
from raw2ufs.engine.registry import Field, Node, node

@node
class Head(Node):
    type = "head"                 # stable id used in workflow JSON and the script tag (Raw2UFS_HEAD)
    label = "Head"                # palette name (defaults to the type, title-cased)
    category = "Prepare"          # palette section; order is CATEGORY_ORDER in registry.py
    description = (               # markdown; shown in the inspector and docs/tools.md
        "Keep only the first *N* rows. Useful for testing a mapping on a sample."
    )
    inputs = ["in"]               # port names; ["left", "right"] for two inputs;
                                  # variadic = True lets the last port take many connections
    fields = [
        Field("n", "int", default=100, required=True, label="Rows to keep",
              help="Rows beyond this are dropped."),
    ]

    def summary(self, cfg):       # one line for the node card and the script comment
        return f"first {cfg['n']} rows"

    def emit(self, cfg, ins, out):
        return f"{out} = {ins['in']}.head({int(cfg['n'])})\n"
```

`cfg` arrives with defaults filled in. `ins` maps each port name to the
upstream variable name (a list of names for a variadic port). `out` is the
variable your code must assign a `pl.LazyFrame` to. Return plain Python
source; use `lit()` / `col()` from the registry to render literals and column
references safely, `pathlit()` for file paths (resolves against `BASE_DIR` and
expands `${Constant}`), `strlit()` for text options that may contain
`${Constant}`, and `chain()` to lay out method chains one per line.

**3. Choose field kinds** from `FIELD_KINDS` in `registry.py`:
`string`, `text` (multi-line), `int`, `float`, `bool`, `choice` (+ `choices`),
`path`, `column` (a picker fed by the upstream schema of `port`), `columns`
(multi-pick), `formula`, `dtype`, `table` (rows of sub-fields via `columns=[...]`),
`json`. The UI renders every one of these already.

**4. Add validation if needed.** Override `validate(cfg)` and call
`super().validate(cfg)` first; return a list of human-readable problems. They
appear in red on the node and in the inspector.

**5. Need a helper function in the script?** Put it in `raw2ufs/helpers.py`
with the `_r2u_` prefix, make it self-contained (import inside the function),
add it to `__all__`, and list it in the tool's `helpers = [...]`. The exporter
inlines it only when the emitted code actually calls it.

**6. Sinks.** A tool that writes files instead of producing a frame sets
`is_sink = True` and its code need not assign `out` (see `Output`).

**7. Test it.** Add a case to `tests/test_nodes.py` using the `single()` helper
(input CSV -> your node -> collected frame). Because the engine only ever runs
emitted code, this also proves the exported script for that tool.

**8. Regenerate the reference.** `python -m raw2ufs docs -o docs/tools.md`.

That is all: the palette, the inspector panel, validation, the script tag and
the docs pick the tool up from the registry. No UI code changes.

## Adding a formula function

`raw2ufs/formula/emit.py` has a `FUNCTIONS` table. One line registers a
function: name, signature for the docs, description, arity, and a renderer
that turns already-emitted argument sources into polars source. Use `_lit(a)`
when the argument must be an expression and `_raw(a)` when polars wants a
plain Python value (counts, patterns).

## Building the Windows executable

`raw2ufs.spec` + `build.bat` (or `build.sh`) produce `dist/Raw2UFS/` with a
windowed `Raw2UFS.exe` and a console `raw2ufs-cli.exe`. `launcher.py` is the
shared entry point: a CLI command as the first argument runs the CLI,
`--serve` runs browser mode, otherwise the pywebview window opens. Two things
are frozen-specific and worth knowing: `ui/paths.py` finds `index.html` under
`sys._MEIPASS`, and the script exporter reads helper source from the bundled
`raw2ufs/helpers.py` file because `inspect.getsource` has no `.py` to read in
a bundle.

## Running things

```bash
pip install -e ".[spatial,excel-out,ui,dev]"      # or uv sync --all-extras
python examples/make_sample_data.py
python -m ui                # desktop; python -m ui --serve for the browser
python -m raw2ufs run examples/sov_to_oed.json
python -m raw2ufs export examples/sov_to_oed.json -o examples/sov_to_oed.py
pytest                      # engine tests + headless browser UI tests
```
