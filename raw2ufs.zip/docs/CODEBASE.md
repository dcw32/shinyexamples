---
project: raw2ufs
version: 0.1.0
updated: 2026-09-10
language: python>=3.10
runtime_deps: [polars>=1.20, fastexcel>=0.12]
optional_deps: {spatial: [shapely>=2.0, numpy], excel-out: [xlsxwriter], ui: [pywebview>=5], dev: [pytest, pyarrow, playwright]}
entry_points: {cli: "python -m raw2ufs <cmd>", desktop_ui: "python -m ui", browser_ui: "python -m ui --serve [--port 8765]", frozen: "launcher.py -> dist/Raw2UFS/{Raw2UFS,raw2ufs-cli}(.exe) via raw2ufs.spec"}
tests: {command: pytest, count: 75, files: [tests/test_formula.py, tests/test_graph.py, tests/test_nodes.py, tests/test_cache.py, tests/test_export.py, tests/test_ui.py]}
human_docs: [docs/OVERVIEW.md, docs/tools.md, docs/TODO.md, README.md]
---

# CODEBASE

Machine-oriented summary. Sections are stable; tables are the contract.

## INVARIANTS

- `I1` A workflow is fully described by its JSON document (schema in WORKFLOW_JSON).
- `I2` A node's `emit()` returns Python source; the runner `exec`s it; the exporter writes it verbatim. App and script execute identical code.
- `I3` Every node's output variable is `df_<sanitised id>` (`NodeSpec.var`). Sinks (`is_sink=True`) assign nothing.
- `I4` Relative file paths resolve against `BASE_DIR` (`Graph.base_dir` = workflow folder, set on load, not serialised; exported script sets `BASE_DIR` to its own folder). Nodes emit `os.path.join(BASE_DIR, path)`. No chdir anywhere.
- `I5` Type casts are non-strict (`strict=False`); text->int/float strips whitespace via `.cast(pl.String).str.replace_all(r'\s','')`.
- `I6` Geometry columns are `pl.Binary` holding WKB. Only shapely (no geopandas) is used.
- `I7` A node belongs to at most one container. `Graph.disabled_nodes()` = members of containers with `enabled=false` plus all transitive descendants; these are skipped by compile/run/validate and emitted commented-out by the exporter.
- `I8` Formula text is parsed (never `eval`ed); only emitter output (our own polars source) is `eval`ed.
- `I9` Cache key = sha1(polars version, target id, ancestor ids/types/configs, ancestor edges, input file [size, int(mtime)]). Cached node -> `pl.scan_parquet(path)` in place of its code.
- `I10` The UI has no per-tool code; panels render from `Field` specs. Adding a tool = one `@node` class.
- `I11` Constants: `graph.constants = {name: {type: string|number, value}}`; formulas reference `[$Name]` -> `pl.lit(K_Name)`; path/text options reference `${Name}` -> `str(K_Name)` concatenation (`registry.strlit`). Runner namespace and exported script define `K_<name>`. Unknown references are validation errors (`runner._K_REF`).
- `I12` Off switches: `Container.enabled`, `NodeSpec.enabled` (serialised only when false), `Graph.run_outputs` (serialised only when false; disables all `output` nodes). All feed `Graph.disabled_nodes()` which adds descendants.
- `I13` The API is stateless except for the cache; the front end sends `base_dir` inside the graph dict. Several workflows can be open (UI tabs).
- `I14` Frozen-safe: helper source for exported scripts is read from the bundled `raw2ufs/helpers.py` (parsed with `ast`) when `inspect.getsource` fails; the front end is located via `ui/paths.py`.
- `I15` Theme: all colours are CSS variables on `:root`; `:root[data-theme="dark"]` overrides them; container pastels have light/dark sets (`CONTAINER_COLORS_LIGHT/DARK`); choice persisted in `localStorage['raw2ufs.theme']`, default follows `prefers-color-scheme`.

## MODULES

| path | role | key symbols |
|---|---|---|
| raw2ufs/__init__.py | package import registers all nodes | `__version__`, re-exports Graph, REGISTRY, run, export_script |
| raw2ufs/engine/graph.py | workflow model + JSON | `Graph(name, description, nodes, edges, containers, constants, run_outputs, version, base_dir)`, `.set_constant(name,value,type)`, `.constant_values()`, `.expand(text)`, `NodeSpec(id,type,config,name,ui,enabled).var`, `Edge(src,dst,to_port)`, `Container(id,name,color,enabled,nodes,ui)`, `Graph.topo_order()`, `.ancestors(id)`, `.inputs_of(id)->{port:[src]}`, `.disabled_nodes()`, `.container_of(id)`, `.to_dict/.from_dict/.to_json/.from_json`, `load_graph(path)`, `save_graph(g,path)`, `GraphError` |
| raw2ufs/engine/registry.py | node base + registry | `Node` (class attrs: type,label,category,description,inputs,variadic,is_sink,fields,helpers; methods: emit(cfg,ins,out)->str, validate(cfg)->list[str], summary(cfg)->str, cfg_with_defaults, to_dict), `Field(name,kind,label,help,required,default,choices,port,columns)`, `FIELD_KINDS`, `@node`, `REGISTRY`, `get_node(type)`, `all_nodes()`, `CATEGORY_ORDER`, codegen helpers `lit(v)`, `strlit(text)` (${Name} -> K_Name), `pathlit(path)` (os.path.join(BASE_DIR, ...)), `col(name)`, `cols(names)`, `chain(base,*ops)`, `NodeConfigError` |
| raw2ufs/engine/runner.py | compile + execute | `Block(spec,node,code,helpers,disabled)`, `compile_graph(graph, only=None, include_disabled=False)->list[Block]`, `build_plans(graph, upto=None, cache=None)->{id: LazyFrame}`, `schema(graph,id,cache)`, `preview(graph,id,n,cache)->DataFrame`, `run(graph,on_node,constants=None,should_stop=None)`, `RunCancelled`, `_namespace(graph,overrides)` (pl, cs, os, BASE_DIR, K_*), `RunError(spec,msg,surfaced_at).node_id/.surfaced_at`, `attribute(graph, failed_spec, ns, exc)->RunError` (walks ancestors: `collect_schema()` then `head(1).collect()`; first failing plan is the culprit), `explain(exc, available_columns)` (first line of the polars message + hint; missing column -> nearest match + available list). `on_node(spec, status, detail)` statuses: start / warning (detail = `Category: message`, Python warnings captured per block with `warnings.catch_warnings(record=True)`, deduplicated) / error (detail = message + traceback) / done |
| raw2ufs/engine/cache.py | run-to-here cache | `Cache(root=tempdir/raw2ufs_cache)`: `key(graph,id)`, `path(key)`, `has`, `status(graph)->{id:bool}`, `materialise(graph,id)->{rows,columns,bytes}`, `clear()`, `size_bytes()` |
| raw2ufs/engine/analysis.py | data inspection | `infer_types(df)->{col: dtype_name}`, `profile(lf)->{rows, columns:[{name,dtype,nulls,blank,distinct,min,max}]}` |
| raw2ufs/engine/dtypes.py | type names | `DTYPES` (string,int,float,bool,date,datetime,binary -> polars source), `dtype_source(name)`, `polars_dtype(name)`, `friendly_dtype(pl_dtype)` |
| raw2ufs/formula/lexer.py | tokens | `tokenize(text)->list[Token]`, `FormulaError(msg,pos)`, `KEYWORDS` |
| raw2ufs/formula/parser.py | recursive descent | `parse(text)->ast.Expr` (precedence: OR < AND < NOT < compare/IN < +- < */% < unary- < ^ < primary) |
| raw2ufs/formula/ast.py | AST nodes | `Number,String,Bool,Null,Column,Const,Unary,Binary,In,Call,If`, `columns_used(expr)` |
| raw2ufs/formula/emit.py | codegen | `FUNCTIONS: {name: Func(name,signature,description,min_args,max_args,render)}`, `to_polars_source(text)->str`, `compile_formula(text)->pl.Expr` |
| raw2ufs/nodes/io.py | Input, Output | `parse_range("B3:K200")->{header_row,use_columns,n_rows}`, `detect_format(path)` |
| raw2ufs/nodes/prepare.py | Select, SelectRecords, Cleanse, Filter, Formula, MultiFieldFormula, DynamicRename, TextToColumns, RecordID, Sort, Unique | `FILTER_OPS`, `CASES`, `parse_row_ranges`, `CURRENT_FIELD` |
| raw2ufs/nodes/combine.py | Join, Union, AppendFields | `JOIN_TYPES` |
| raw2ufs/nodes/reshape.py | Summarise, Transpose, CrossTab | `AGG_FUNCS`, `PIVOT_AGGS` |
| raw2ufs/nodes/spatial.py | CreatePoints, SpatialMatch | uses helpers `_r2u_make_points`, `_r2u_spatial_match` |
| raw2ufs/nodes/annotate.py | Comment | emits `# text` lines only |
| raw2ufs/helpers.py | inlined script helpers | `__all__`: `_r2u_append_fields(target,source,prefix,max_source_rows)`, `_r2u_drop_null_columns`, `_r2u_drop_null_rows`, `_r2u_make_points(lon,lat)`, `_r2u_rename_from_first_row(df)`, `_r2u_spatial_match(points,polygons,point_col,polygon_col,how,predicate,suffix)`, `_r2u_write_geoparquet(df,path,geometry_col,crs)`; `HELPER_DEPS` |
| raw2ufs/export/to_script.py | standalone script | `export_script(graph, source=None)->str` |
| raw2ufs/export/docs.py | tool reference | `tools_markdown()->str` |
| raw2ufs/cli.py | CLI | subcommands `run, export [-o], validate, schema [node], preview node [-n], nodes, docs [-o]`; workflow commands accept `--set NAME=VALUE` (repeatable) |
| ui/api.py | JSON API | class `Api(cache_dir=None)` - see API table |
| ui/server.py | dev HTTP | `serve(host,port,api,background)`; `POST /api/<method> {"args":[...]}`; `GET /` -> index.html |
| ui/app.py | desktop | `main(debug)`: pywebview window with `js_api=Api()` |
| launcher.py | frozen entry point | CLI command as first arg -> `raw2ufs.cli.main`; `--serve` -> `ui.server.serve`; else `ui.app.main` |
| raw2ufs.spec | PyInstaller spec | one-folder COLLECT with two EXEs (windowed `Raw2UFS`, console `raw2ufs-cli`); datas: ui/index.html, raw2ufs/helpers.py; excludes pyarrow/pandas/scipy/... |
| ui/paths.py | resource location | `UI_DIR` = `sys._MEIPASS/ui` when frozen else the package folder |
| ui/index.html | front end | single file; globals `graph, catalogue, multi, selected, selectedContainer, view, problems, cached, history/future, pinned, preview`; key fns `render, renderInspector, fieldHtml, bindFields, validate, doPreview, doProfile, doRunTo, doRun, groupSelection, ungroup, insertPayload, undo, redo, renderPalette, showMenu, showRecentMenu, togglePin, renderPreviewGrid` |

## WORKFLOW_JSON

```
{
  "version": 1,
  "name": str, "description": str,
  "nodes": [ {"id": str, "type": str, "name"?: str, "config": {field: value}, "ui"?: {"x": num, "y": num}} ],
  "edges": [ {"from": node_id, "to": node_id, "to_port"?: str} ],           # to_port default "in"
  "containers"?: [ {"id": str, "name": str, "color": color_name, "enabled": bool, "nodes": [node_id], "ui": {"x","y","w","h"}} ],
  "constants"?: { name: {"type": "string"|"number", "value": any} },
  "run_outputs"?: false,                       # only written when false
  "base_dir"?: str                             # transport only (UI -> API); never written to disk
}
node: {"id", "type", "name"?, "config", "ui"?, "enabled"?: false}   # enabled only written when false
color_name in {grey, green, blue, purple, amber, cyan, red, yellow, pink}
Validity: node ids unique; edges reference existing nodes; DAG; each non-variadic port has exactly one incoming edge; variadic port >= 1.
```

## FIELD_KINDS

| kind | value type | UI widget | notes |
|---|---|---|---|
| string | str | text input | |
| text | str | textarea | multi-line |
| int / float | number | number input | |
| bool | bool | checkbox | |
| choice | str | select | from `choices` |
| path | str | text + browse | native dialog under pywebview |
| column | str | input + datalist | options = upstream schema of `port`; free text allowed |
| columns | list[str] | chips + checklist + add box | |
| formula | str | textarea | validated by `to_polars_source` |
| dtype | str | select | from `DTYPES` |
| table | list[dict] | rows of sub-fields (`columns=[Field...]`) | `+ Row`, `+ All columns` when first sub-field is `column`, `Infer types` on Select |
| json | any | textarea | raw JSON |

## NODES

| type | category | ports | output | config fields |
|---|---|---|---|---|
| input | Input | - | frame | path, format(auto/csv/xlsx/parquet/geoparquet), encoding, delimiter, has_header, skip_rows, sheet, header_row, range, all_strings |
| cleanse | Prepare | in | frame | columns, null_to_blank, null_to_zero, trim, collapse_whitespace, remove_whitespace, remove_letters, remove_numbers, remove_punctuation, case, drop_null_rows, drop_null_columns |
| filter | Prepare | in | frame | mode(simple/formula), combine(and/or), conditions[{column,op,value,dtype}], formula (dtype auto-filled by the UI from the schema; numeric/date compares cast the column) |
| formula | Prepare | in | frame | columns[{name,formula,dtype}] (sequential) |
| record_id | Prepare | in | frame | name, start, group_by |
| select | Prepare | in | frame | columns[{name,rename,dtype}], keep_others |
| select_records | Prepare | in | frame | ranges ("1", "2-", "-10", "15-20", comma-separated) |
| dynamic_rename | Prepare | in | frame | mode(first row / add prefix/suffix / remove prefix/suffix), columns, prefix, suffix |
| text_to_columns | Prepare | in | frame | column, delimiter, mode(to columns/to rows), n_columns, root, extra(drop/keep in last), skip_empty, ignore_quoted, keep_original |
| multi_field_formula | Prepare | in | frame | columns, formula ([_CurrentField_], [_CurrentFieldName_]), output(overwrite/new columns), prefix, suffix, dtype |
| sort | Prepare | in | frame | by[{column,descending}], nulls_last |
| unique | Prepare | in | frame | columns, keep(first/last/any) |
| join | Combine | left, right | frame | how(inner/left/right/full/semi/anti), keys[{left,right}], right_prefix (default Right_), fields[{column (port "out" = joined columns, computed by the UI),rename}] |
| append_fields | Combine | target, source | frame | max_source_rows, prefix (cartesian product via helper) |
| union | Combine | in (variadic) | frame | match(by name/by position) |
| crosstab | Reshape | in | frame (eager pivot) | index, on, values, aggregate |
| summarise | Reshape | in | frame | group_by, aggregations[{column,function,alias}], row_count |
| transpose | Reshape | in | frame | index, on, variable_name, value_name, as_text |
| create_points | Spatial | in | frame | lat, lon, geometry_col |
| spatial_match | Spatial | points, polygons | frame | point_col, polygon_col, how(left/inner), predicate(within/intersects), suffix |
| output | Output | in | sink | path, format(csv/xlsx/parquet/geoparquet), format_tag, delimiter, geometry_col, crs |
| comment | Annotate | - | sink (no-op) | text |

Full option semantics: docs/tools.md (generated by `python -m raw2ufs docs`).

## EXPORTED_SCRIPT_FORMAT

```
"""<name>\n\n<description>\n\nGenerated by Raw2UFS <ver> on <date> from <file>.\n...Requires: <deps>"""
import os
import polars as pl
[import polars.selectors as cs]
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
[# Constants  K_<name> = value ...]
[# Helper functions (inlined from raw2ufs.helpers)  def _r2u_...]
# Workflow
# Raw2UFS_<TYPE>: <id> "<name>" - <summary>          # one block per node, topo order
<code assigning df_<id>>
# Raw2UFS_<TYPE>: <id> "<name>" - DISABLED (<reason>) - <summary>   # disabled: code lines prefixed "# "
```
Block boundary = blank line + `# Raw2UFS_` tag line. Editing rule for tools/AI: keep tags; add steps between blocks; downstream blocks reference `df_<id>` names.

## API (ui/api.py) - all args/returns JSON

| method | args | returns |
|---|---|---|
| catalogue | - | [Node.to_dict()] |
| dtypes | - | [name] |
| formula_functions | - | [{name,signature,description}] |
| choose_file | save:bool, suggested:str | path or null (null in browser mode) |
| new_workflow | - | graph dict (with base_dir = cwd) |
| open_workflow | path | {ok,path,graph (with base_dir),base_dir} or error |
| save_workflow | graph, path | {ok,path,base_dir} |
| status | - | {cwd,version,cache_dir,cache_bytes} |
| excel_info | path, sheet="", n=12, base_dir="" | {ok,sheets,sheet,rows} |
| validate | graph | {ok, graph:[msg], nodes:{id:[msg]}, disabled:[id]} |
| schema | graph, node_id | {ok, columns:[{name,dtype}]} |
| preview | graph, node_id, n=100 | {ok, columns, rows, height} |
| infer_types | graph, node_id, n=2000 | {ok, types:{col:dtype}} |
| profile | graph, node_id | {ok, rows, columns:[{name,dtype,nulls,blank,distinct,min,max}]} |
| run_to | graph, node_id | {ok, rows, columns, bytes} |
| cache_status | graph | {ok, cached:{id:bool}, bytes} |
| clear_cache | - | {ok, removed} |
| run | graph | {ok, log:[{id,type,name,status,detail}], error?, node_id?, surfaced_at?} (synchronous; status includes "warning" entries, detail = message) |
| start_run | graph, upto=None | {ok, job_id} - worker thread; upto -> run-to-here (cache.materialise) |
| job_status | job_id | {ok, state(running/done/error/cancelled), log:[{id,type,name,status,started,seconds,warnings:[str]}], error, node_id, surfaced_at, elapsed, result} |
| cancel_job | job_id | {ok} - stops before the next tool |
| script | graph, source="" | {ok, text} |
| export | graph, path, source="" | {ok, path} |
Error shape: `{ok:false, error, error_type, node_id?}`.
`status` also returns `api_version` (bump when the front end starts depending on a changed method - the page compares it at boot and shows "backend is out of date" instead of a bare "unknown method") and `methods` (the live method list; `startJob` falls back to synchronous `run`/`run_to` when `start_run` is absent).

## UI_STATE_AND_INPUT (index.html)

- Tabs: `tabs[]` of Workspace objects; `stash()`/`unstash(t)` move the per-workflow globals (`WS_KEYS`) in and out; `openInTab`, `switchTab`, `closeTab`; autosaved to `localStorage['raw2ufs.tabs']`. Ctrl+Tab cycles.
- Selection: `multi:Set<node_id>`, `selected` (single), `selectedEdge` (index), `selectedContainer` (id); `showConstants` shows the constants panel instead. Marquee = left-drag on empty canvas (Shift adds). Shift+click toggles.
- Keys: Delete, Esc, Ctrl+A/C/X/V/D, Ctrl+G group, Ctrl+Shift+G ungroup, Ctrl+Z/Y undo/redo, Ctrl+S save, `/` palette search, Space+drag pan.
- Mouse: wheel pans, Shift+wheel horizontal, Ctrl+wheel zoom, middle/Alt drag pan; drag from output dot (or within 14px of it) to an input dot (snap within 18px).
- Undo: JSON snapshots (`history`,`future`, cap 100); `markDirty(coalesce)` - typing coalesces within 1s.
- Persistence: autosave to `localStorage['raw2ufs.autosave']` + `['raw2ufs.path']`; dirty flag guards New/Open/unload.
- Layers: containers z0 < edges svg z1 < nodes z2. Container membership recomputed after node/container drag from node centre (`updateMembership(ids, {except, fit})`).
- Containers can nest: a container's `nodes` lists every tool inside it, nested ones included (nesting is purely geometric - box containment + area, never stored structure). `containersOfNode(id)` -> all containers holding a node; `containerOfNode(id)` -> the innermost (smallest area); `childContainers(c)` / `parentContainer(c)` derive the tree from `nodes` subset + smaller/larger `ui` box; `topLevel(cs)` filters a set down to the outermost members. Dragging a container's header carries `childContainers` along (`cdrag.kids`); resizing or member-dragging re-derives membership via `updateMembership`, which never touches a container currently being dragged (`except`). `groupSelection()` on a selection an existing container already fully encloses nests inside it (grows that container to fit) rather than stealing its tools. Engine side needs no change - `Graph.disabled_nodes()` already unions every container's node set, so a node in an off ancestor is off regardless of nesting depth.
- Context menu (`showMenu(x,y,items)`, closed on any outside mousedown/wheel/blur/Esc): right-click on `#canvas` routes by `ev.target.closest('.node'|'.container'|'path[data-i]')`, falling through to an empty-canvas menu (paste at point, add note, select all, fit, auto layout, open recent).
- Recent files: `localStorage['raw2ufs.recent']` (path, name, timestamp; capped at 12), appended on open/save (`addRecent`); toolbar `#btn-recent` and the canvas menu's "Open recent…" both call `showRecentMenu`. `openPath(p)` is the shared open-by-path helper (reuses an already-open tab). Dropping a `.json` file on the canvas calls `openDroppedWorkflow`: pywebview gives a full path (opens directly); the browser server can only read the file's bytes client-side, so it opens un-pathed and prompts to Save so relative input/output paths resolve against a real folder.
- Preview grid (`preview` global: `{target,cols,rows,sortCol,dir,n,label}`): `renderPreviewGrid()` renders `gridHtml(cols, sortedRows(), {sortable, foot})`, binds header-click sort (asc -> desc -> none, client-side on the already-fetched rows, no re-fetch) and cell-click copy (`navigator.clipboard.writeText`, falls back to a status message). "Show more rows" re-fetches at 5x current `n`. **Pin**: `pinned` (a node id) + `pinDirty` (set by `scheduleValidate(affectsPinned)` whenever an edit touches the pinned node or anything upstream of it); `refreshPinned()` runs after each `validate()` and re-fetches quietly once the graph is valid again. Both are per-tab (`WS_KEYS`).

## ADD_TOOL_CHECKLIST

1. `@node class X(Node)` in `raw2ufs/nodes/<family>.py` with `type, category, description, inputs, fields, emit`; optional `validate, summary, helpers, is_sink, variadic`.
2. New file -> import in `raw2ufs/nodes/__init__.py`.
3. Helper functions -> `raw2ufs/helpers.py` (`_r2u_` prefix, self-contained imports, in `__all__`).
4. Test in `tests/test_nodes.py`.
5. `python -m raw2ufs docs -o docs/tools.md`.
