# Raw2UFS - to do and ideas

Status at 2026-09-10 (evening): engine, formula language, 20 tools, standalone
script export, cache, nested containers, constants, tabs, right-click menus,
recent files, a sortable/pinnable preview grid, and a working canvas UI. 85 tests green. Everything
below is open. Rough order of value at the top of each section.

## Requested 2026-09-10 (with design notes)

### Workflow-level features

- [x] **Multiple workflows open in tabs.** Feasible; mostly a front-end change
      because all per-workflow state already lives in a handful of globals
      (`graph, view, multi, selected, selectedContainer, history/future, dirty,
      currentPath, problems, cached`). Bundle those into a `Workspace` object,
      keep an array of them, and swap on tab click; the palette, inspector and
      bottom panes re-render from the active one. Cross-tab copy/paste works
      for free (the clipboard is a plain object).
      *Real issue to solve first:* the API resolves relative paths by
      `os.chdir` to the workflow's folder, which is process-global - two open
      workflows in different folders would fight. Fix: stop chdir-ing; carry
      `base_dir` with every API call (or store it on the graph) and have
      Input/Output resolve relative paths against it at emit time. The CLI
      and exported script keep their current behaviour. Second issue:
      autosave/`localStorage` becomes a list keyed by path. The cache is
      content-keyed so it is already safe to share.
- [x] **Workflow constants.** Named string/number values stored on the
      workflow (`"constants": {"Client": {"type": "string", "value": "X"}}`),
      editable in a panel, referenced as `[$Client]` in formulas and `${Client}`
      inside path/string fields. Emitted as a `# Constants` block of plain
      Python variables at the top of the exported script (AI-friendly), and
      overridable from the CLI (`--set Client=Y`) for batch runs.
- [x] **Deactivate outputs individually and at workflow level.** Per-node
      `enabled` flag (an Output tool with a toggle in its header, greyed when
      off; generalise later to "bypass" for any tool) plus a workflow-level
      "outputs: run / skip all" switch on the toolbar. Both feed
      `Graph.disabled_nodes()`, so run/validate/export handle them exactly like
      disabled containers (commented-out blocks in the script).

### New tools (Alteryx equivalents in polars terms)

- [x] **Join: output field selection + rename.** Table of output columns from
      both sides with keep/rename; clashing right-hand names default to
      `Right_<name>` (Alteryx convention) rather than a `_right` suffix.
      Implementation: join, then a generated `select([...alias...])`.
- [x] **Select Records** (row ranges): `"1"` first row, `"2-"` second to end,
      `"15-20"`, comma-separated list. Implementation: `with_row_index` (1-based)
      + filter on the union of ranges. Works lazily.
- [ ] **Multi-Row Formula.** Update an existing column or create a new one;
      `[Row-1:Col]` / `[Row+2:Col]` references, number of rows to look back/
      forward, optional group-by, and a rule for rows that don't exist
      (null, 0/empty, or nearest valid row). Implementation: extend the lexer
      with a `RowRef` token -> `pl.col("Col").shift(k).over(groups)`, fill via
      `fill_null(0)` / `forward_fill`/`backward_fill`. *Limitation to design
      for:* Alteryx lets the formula reference its own previous output
      (`[Row-1:NewField]`, e.g. running balances); polars cannot express that
      with `shift`, so that case needs a small Python loop helper
      (`_r2u_multirow_recursive`) inlined into the script, or a restriction to
      the common cumulative cases (`cum_sum`, `cum_count`).
- [x] **Dynamic Rename.** First row -> names (helper collects one row, then
      `slice(1)`), add/remove prefix/suffix. Rename-from-lookup-table input
      not done.
- [x] **Text To Columns.** To columns (`Root_1..N`, extra pieces dropped or
      kept in the last), to rows (`explode`, skip empty), ignore delimiters
      inside double quotes (regex token extraction - Rust regex has no
      look-around, so parentheses/brackets/single quotes are not handled).
- [x] **Append Fields.** Cartesian join of a small Source onto every Target
      row (`join(how="cross")`), with a guard/warning above N source rows.
- [x] **Multi-Field Formula.** One formula applied to each selected column,
      written with `[_CurrentField_]` (and `[_CurrentFieldName_]` for the
      name); overwrite in place or write to `<prefix>name<suffix>`.
      Implementation: parse once, substitute the placeholder per column at
      emit time -> one `with_columns([...])`.
- [ ] **Tile.** Assign rows to tiles by: equal record count (`ntile` via
      `rank("ordinal")`), equal sum (cumulative-sum cut points), smart tile
      (std-dev bands around the mean), unique values, or manual cut points
      (`pl.Expr.cut`). Outputs `Tile_Num` and `Tile_SequenceNum`; optional
      group-by.

### Formula language

- [x] `IIF(condition, x, y)` -> `when/then/otherwise` (one line in FUNCTIONS).
- [x] `Switch(value, default, case1, result1, ..., caseN, resultN)` ->
      chained `when(value == case).then(result)...otherwise(default)`
      (variadic renderer; validate an even number of case/result args).
- [ ] `IF ... THEN ... ELSEIF ... THEN ... ELSE ... ENDIF` already supported;
      add the same construct as a statement in Multi-Row/Multi-Field formulas
      once those tools exist.

## Known issues

- [ ] Drag-and-drop of files onto the canvas only yields the file *name* in
      browser mode (`--serve`) and, on Linux at least, in pywebview too. Fix
      options: pywebview `pywebviewFullPath` on Windows/WebView2 (untested), or
      fall back to opening the native file dialog on drop.
- [x] Containers grow when a member is dragged towards their edge; "Fit to
      tools" button shrinks/grows to the members.
- [x] Marquee: a band enclosing containers selects their tools; exactly one
      container and nothing else selects the container itself.
- [ ] `fit` on open is very small for wide workflows; consider fitting to the
      first ~8 columns of nodes instead of everything.
- [x] Filter (simple mode): a *Type* per condition, auto-filled from the
      schema when a column is picked; numeric/date comparisons cast the column
      side too, so they work on still-text columns.
- [ ] Infer types marks "111 57"-style postcodes as int; consider a hint that
      leading-zero or space-separated codes stay text.
- [ ] pywebview wheel would not build in the dev sandbox (proxy_tools); verify
      `python -m ui` on Windows and on Dave's Linux box, including file dialogs
      and `pywebviewFullPath`.

## Errors and warnings

- [x] Error attribution: a lazy error raised at a sink is walked back to the
      first upstream plan that fails on its own (`runner.attribute`); the UI
      marks the culprit red and the surfacing tool lighter red. Limitation:
      errors that appear only deep in the data (`head(1)` passes) stay on the
      sink; a "run with checks" mode materialising each node via the cache
      would make attribution exact.
- [x] polars messages translated (`runner.explain`): first line only, hint per
      error class, missing column -> nearest match + available columns.
- [x] Python warnings raised while a block runs go to the run log under the
      tool (`on_node(..., "warning", ...)`), CLI prints them too.
- [ ] Static warnings hook `Node.warnings(cfg, input_schemas)` shown amber on
      the node: join key type mismatch, unknown column reference, numeric
      compare on text, large Append Fields source, Text To Columns name clash.
- [ ] Data-quality checks: `Node.checks(cfg, ins, out)` returning polars
      expressions - evaluated on the preview sample automatically (nulls
      introduced by casts, unmatched/multiplied join rows, dropped pieces,
      empty outputs) and on the full run behind a "Run with checks" toggle
      (materialise each node through the cache, then count). Never part of
      the exported script.

## Front end

- [ ] Resizable panes (inspector width, bottom pane height, palette width).
- [ ] Align / distribute the selection (left, top, spread horizontally).
- [x] Nested containers: a container's `nodes` lists every tool inside it,
      nested ones included (nesting is geometric - derived from box
      containment + size, not stored structure), so the engine's existing
      union-of-disabled-containers rule needs no change. Dragging an outer
      container's header carries nested containers along; grouping a
      selection that an existing container already fully encloses grows that
      container to fit the new one instead of stealing its tools.
- [ ] Node bypass (a per-node "pass data through unchanged" switch) - the
      per-node *enabled* flag exists now (skips the node and its descendants);
      bypass would keep downstream running.
- [x] Join output-field picker offers the joined columns (left + right minus
      keys, `Right_` prefix on clashes) via a synthetic `out` port.
- [ ] Edge routing when nodes overlap; edge labels with row counts after a run.
- [x] Right-click context menu: node (preview, profile, run to here, pin,
      duplicate, copy, delete, group, remove from container, enable/disable),
      container (enable/disable, fit to tools, duplicate, copy, ungroup,
      delete with tools), edge (delete connection), empty canvas (paste here,
      add note here, select all, fit to view, auto layout, open recent).
- [ ] Keyboard navigation of nodes (arrow keys) and Enter to open inspector field.
- [x] Recent files list (toolbar dropdown + canvas-menu "Open recent…",
      `localStorage`, updated on open/save) and open-by-drop of a `.json`
      workflow onto the canvas (pywebview: opens by its full path; browser
      mode: reads the file client-side, opens un-pathed, and asks for a save
      so relative paths resolve).
- [x] Preview grid: click a header to sort the fetched rows (client-side, no
      re-fetch), click a cell to copy it, "show more rows" re-fetches at 5x;
      Pin button keeps the preview on a chosen node and it re-fetches after
      each validate when something upstream of it changed (and is valid).
- [x] Dark theme (all colours already go through CSS variables).
- [ ] Toolbar overflow menu for narrow windows.

## Engine and tools

- [ ] **Try a real SOV.** Expected gaps: multi-row headers (merge two header
      rows into one name), header-row auto-detection, currency + units node
      (kSEK -> SEK), coverage split (Building/Contents/BI in one column with a
      type column -> wide), peril columns, Excel dates stored as serial numbers.
- [ ] Column mapper tool: source -> target column table preloaded with the OED
      Loc/Acc field lists, fuzzy suggestions, "unmapped" report. Later: an
      LLM-assisted suggestion button (parked by design).
- [ ] OED validator as a separate script over `format_tag`-ged outputs
      (required fields, code lists, types) - vendor the ODS spec as CSV.
- [ ] OED "profile" on Output: enforce column order/types for OED-Loc/Acc/
      ReinsInfo/ReinsScope.
- [ ] Lookup/replace tool (value mapping table inline, without a Join).
- [ ] Sample / Head tool; Row count assertion tool ("fail if fewer than N rows").
- [ ] Multi-file Input (glob a folder, add a source-file column).
- [ ] SQL Input (`pl.read_database`, connection string + query).
- [ ] Formula: `Today()`, `DateAdd`, `Split`/`GetPart`, regex capture groups,
      `Switch(...)` shorthand; better error positions (column/caret).
- [ ] Cleanse: thousands separators / decimal comma option; unicode normalise.
- [ ] Join: warn when key types differ (pre-validate via schema) and offer a cast.
- [ ] Cache: size cap + LRU, streaming sink for very large frames, per-workflow
      cache folder option, show cache hits in the run log.
- [x] Runs (and Run to here) happen on a worker thread: `start_run` /
      `job_status` / `cancel_job`; live log with per-node timings; Run button
      becomes Cancel. Cancel takes effect before the next tool (a polars
      collect in flight cannot be interrupted).
- [ ] Workflow-level parameters (e.g. `${client}` in paths) passed on the CLI.
- [ ] Schema propagation for CrossTab without a full run (sample-based).

## Packaging, docs, skill

- [x] PyInstaller build (`raw2ufs.spec`, `build.bat`): windowed `Raw2UFS.exe` +
      console `raw2ufs-cli.exe`, one folder. Linux build smoke-tested by
      Claude; **Windows build to be verified on Dave's VM** (pywebview /
      WebView2, file dialogs, drag-drop full paths).
- [ ] Turn `docs/tools.md` + `docs/OVERVIEW.md` into a Claude skill so an AI can
      read/write workflow JSON and edit exported scripts by their tags.
- [ ] Analyst-facing user guide with screenshots per tool.
- [ ] Version the workflow JSON (`version: 2` when fields change) with a
      migration hook in `Graph.from_dict`.
- [ ] CI: run pytest (engine + playwright) on push.

## Nice to have

- [ ] Workflow diff (two JSON files -> what changed, per tool).
- [ ] "Explain this workflow" - generate a plain-English summary from the graph.
- [ ] Macro / sub-workflow tool (reuse a saved workflow as one node).
- [ ] Map preview for geometry columns (points on a basemap) in the bottom pane.
