"""Where the front-end files live - works from source and from a PyInstaller bundle."""

from __future__ import annotations

import sys
from pathlib import Path

if getattr(sys, "frozen", False):          # PyInstaller: data files sit under sys._MEIPASS
    UI_DIR = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent)) / "ui"
else:
    UI_DIR = Path(__file__).resolve().parent
