"""Desktop shell: a pywebview window hosting ui/index.html with Api as the JS bridge."""

from __future__ import annotations

from pathlib import Path

from ui.api import Api
from ui.paths import UI_DIR as HERE


def main(debug: bool = False) -> None:
    import webview  # imported here so `--serve` mode works without pywebview installed

    api = Api()
    window = webview.create_window(
        "Raw2UFS", str(HERE / "index.html"), js_api=api,
        width=1400, height=900, min_size=(900, 600),
    )
    api.window = window
    webview.start(debug=debug)
