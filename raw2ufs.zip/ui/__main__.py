import argparse

p = argparse.ArgumentParser(prog="ui", description="Raw2UFS front end")
p.add_argument("--serve", action="store_true", help="serve in the browser instead of a desktop window")
p.add_argument("--port", type=int, default=8765)
p.add_argument("--debug", action="store_true", help="pywebview devtools")
args = p.parse_args()

if args.serve:
    from ui.server import serve
    serve(port=args.port)
else:
    from ui.app import main
    main(debug=args.debug)
