"""Raw2UFS front end.

    python -m ui             # desktop window (needs pywebview)
    python -m ui --serve     # http://127.0.0.1:8765 in any browser (dev / fallback)

The UI is one HTML file (ui/index.html) talking to the engine through the
methods of ui.api.Api - the same methods over pywebview's JS bridge or over
the tiny HTTP server in ui/server.py. Nothing in the engine knows the UI exists.
"""
