"""Minimal stdlib HTTP server exposing ui.api.Api for browser-based development.

POST /api/<method>  body: {"args": [...]}  ->  JSON result
GET  /              ->  ui/index.html
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from ui.api import Api
from ui.paths import UI_DIR as HERE


def make_handler(api: Api):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):  # quieter
            pass

        def _send(self, code: int, body: bytes, ctype: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                self._send(200, (HERE / "index.html").read_bytes(), "text/html; charset=utf-8")
            else:
                self._send(404, b"not found", "text/plain")

        def do_POST(self):
            if not self.path.startswith("/api/"):
                return self._send(404, b"not found", "text/plain")
            method = self.path[len("/api/"):]
            length = int(self.headers.get("Content-Length", 0))
            payload = json.loads(self.rfile.read(length) or b"{}")
            fn = getattr(api, method, None)
            if fn is None or method.startswith("_"):
                msg = json.dumps({"error": f"unknown method '{method}' - the running backend is older than "
                                           "this page; restart python -m ui (or rebuild the exe)"})
                return self._send(404, msg.encode(), "application/json")
            try:
                result = fn(*payload.get("args", []))
            except Exception as e:  # noqa: BLE001
                result = {"ok": False, "error": f"{type(e).__name__}: {e}"}
            self._send(200, json.dumps(result, default=str).encode(), "application/json")

    return Handler


def serve(host: str = "127.0.0.1", port: int = 8765, api: Api | None = None, background: bool = False):
    api = api or Api()
    httpd = ThreadingHTTPServer((host, port), make_handler(api))
    print(f"Raw2UFS UI at http://{host}:{port}")
    if background:
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        return httpd
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return httpd
