"""The API the front end calls. Every method takes and returns plain JSON.

Graphs travel as dicts (the workflow JSON), never as engine objects, so this
layer is also the contract a future browser/FastAPI front end would use.

The API is stateless apart from the result cache: the front end sends the
workflow dict with a `base_dir` key (the folder of the file it was opened from)
on every call, so several workflows can be open at once without interfering.
"""

from __future__ import annotations

import os
import threading
import time
import traceback
import uuid
from pathlib import Path
from typing import Any

import raw2ufs  # noqa: F401  registers nodes
from raw2ufs.engine.analysis import infer_types, profile
from raw2ufs.engine.cache import Cache
from raw2ufs.engine.dtypes import friendly_dtype
from raw2ufs.engine.graph import Graph, GraphError
from raw2ufs.engine.registry import REGISTRY, all_nodes
from raw2ufs.engine.runner import RunCancelled, RunError, _K_REF, _port_vars, build_plans, preview, run, schema
from raw2ufs.export.to_script import export_script


# Bump when the front end starts depending on a new/changed Api method. The page
# compares this with its own expectation at boot and says "restart the backend"
# instead of failing later with "unknown method".
API_VERSION = 2


def _err(e: Exception) -> dict[str, Any]:
    return {"ok": False, "error": str(e), "error_type": type(e).__name__,
            "node_id": getattr(e, "node_id", None)}


class Api:
    """Instantiated once; pywebview exposes its public methods as window.pywebview.api.*"""

    def __init__(self, cache_dir: str | None = None) -> None:
        self.window = None          # set by ui.app when running under pywebview
        self.cache = Cache(cache_dir)
        self.jobs: dict[str, dict[str, Any]] = {}     # background runs, see start_run

    # ---- catalogue --------------------------------------------------------
    def catalogue(self) -> list[dict[str, Any]]:
        return [c.to_dict() for c in all_nodes()]

    def dtypes(self) -> list[str]:
        from raw2ufs.engine.dtypes import DTYPES
        return list(DTYPES)

    def formula_functions(self) -> list[dict[str, str]]:
        from raw2ufs.formula.emit import FUNCTIONS
        return [{"name": f.name, "signature": f.signature, "description": f.description}
                for f in FUNCTIONS.values()]

    # ---- files ------------------------------------------------------------
    def choose_file(self, save: bool = False, suggested: str = "") -> str | None:
        """Native file dialog under pywebview; None in browser mode (UI falls back to a text box)."""
        if self.window is None:
            return None
        import webview
        if save:
            res = self.window.create_file_dialog(webview.SAVE_DIALOG, save_filename=suggested)
        else:
            res = self.window.create_file_dialog(webview.OPEN_DIALOG)
        if not res:
            return None
        return res if isinstance(res, str) else res[0]

    def new_workflow(self) -> dict[str, Any]:
        d = Graph(name="Untitled workflow").to_dict()
        d["base_dir"] = os.getcwd()          # until it is saved somewhere
        return d

    def open_workflow(self, path: str) -> dict[str, Any]:
        try:
            p = Path(path).resolve()
            g = Graph.from_json(p.read_text(encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            return _err(e)
        d = g.to_dict()
        d["base_dir"] = str(p.parent)        # relative paths resolve next to the workflow
        return {"ok": True, "path": str(p), "graph": d, "base_dir": str(p.parent)}

    def save_workflow(self, graph: dict[str, Any], path: str) -> dict[str, Any]:
        try:
            p = Path(path).resolve()
            g = Graph.from_dict(graph)
            p.write_text(g.to_json(), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            return _err(e)
        return {"ok": True, "path": str(p), "base_dir": str(p.parent)}

    def status(self) -> dict[str, Any]:
        methods = sorted(n for n in dir(self) if not n.startswith("_") and callable(getattr(self, n)))
        return {"cwd": os.getcwd(), "version": raw2ufs.__version__, "api_version": API_VERSION, "methods": methods,
                "cache_dir": str(self.cache.root), "cache_bytes": self.cache.size_bytes()}

    def excel_info(self, path: str, sheet: str = "", n: int = 12, base_dir: str = "") -> dict[str, Any]:
        """Sheet names plus the first rows of one sheet, raw (no header), for picking the header row."""
        import fastexcel
        import polars as pl
        try:
            path = os.path.join(base_dir or os.getcwd(), path)
            names = fastexcel.read_excel(path).sheet_names
            target = sheet if sheet in names else (names[0] if names else None)
            rows: list[list[Any]] = []
            if target:
                df = pl.read_excel(path, sheet_name=target, has_header=False,
                                   read_options={"dtypes": "string", "n_rows": int(n)})
                rows = [[_cell(v) for v in r] for r in df.iter_rows()]
        except Exception as e:  # noqa: BLE001
            return _err(e)
        return {"ok": True, "sheets": names, "sheet": target, "rows": rows}

    # ---- engine -----------------------------------------------------------
    def validate(self, graph: dict[str, Any]) -> dict[str, Any]:
        """Per-node config problems plus structural problems; never raises."""
        problems: dict[str, list[str]] = {}
        try:
            g = Graph.from_dict(graph)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "graph": [str(e)], "nodes": {}}
        graph_problems: list[str] = []
        try:
            g.topo_order()
        except GraphError as e:
            graph_problems.append(str(e))
        off = g.disabled_nodes()
        for spec in g:
            if spec.id in off:
                continue                      # switched off: neither validated nor run
            cls = REGISTRY.get(spec.type)
            if cls is None:
                problems[spec.id] = [f"unknown tool type {spec.type!r}"]
                continue
            node = cls()
            cfg = node.cfg_with_defaults(spec.config)
            msgs = node.validate(cfg)
            if not msgs:
                try:      # unknown [$Name] / ${Name} references show up in the emitted code
                    code = node.emit(cfg, _port_vars(g, spec, node), spec.var)
                    unknown = sorted(set(_K_REF.findall(code)) - set(g.constants))
                    if unknown:
                        msgs.append("unknown constant(s): " + ", ".join(unknown) + " (see Constants)")
                except Exception:  # noqa: BLE001  - port problems are reported below
                    pass
            ports = g.inputs_of(spec.id)
            for i, port in enumerate(node.inputs):
                n = len(ports.get(port, []))
                last = i == len(node.inputs) - 1
                if node.variadic and last:
                    if n == 0:
                        msgs.append(f"port '{port}' needs at least one connection")
                elif n != 1:
                    msgs.append(f"port '{port}' needs exactly one connection (has {n})")
            for port in set(ports) - set(node.inputs):
                msgs.append(f"connection into unknown port '{port}'")
            if msgs:
                problems[spec.id] = msgs
        return {"ok": not problems and not graph_problems, "graph": graph_problems, "nodes": problems,
                "disabled": sorted(off)}

    def schema(self, graph: dict[str, Any], node_id: str) -> dict[str, Any]:
        try:
            sch = schema(Graph.from_dict(graph), node_id, cache=self.cache)
        except Exception as e:  # noqa: BLE001
            return _err(e)
        return {"ok": True, "columns": [{"name": k, "dtype": friendly_dtype(v)} for k, v in sch.items()]}

    def preview(self, graph: dict[str, Any], node_id: str, n: int = 100) -> dict[str, Any]:
        try:
            df = preview(Graph.from_dict(graph), node_id, n=int(n), cache=self.cache)
        except Exception as e:  # noqa: BLE001
            return _err(e)
        rows = []
        for row in df.iter_rows():
            rows.append([_cell(v) for v in row])
        return {"ok": True,
                "columns": [{"name": c, "dtype": friendly_dtype(df.schema[c])} for c in df.columns],
                "rows": rows, "height": df.height}

    def infer_types(self, graph: dict[str, Any], node_id: str, n: int = 2000) -> dict[str, Any]:
        """Suggested dtype per column at a node, judged on its first n rows."""
        try:
            df = preview(Graph.from_dict(graph), node_id, n=int(n), cache=self.cache)
            return {"ok": True, "types": infer_types(df)}
        except Exception as e:  # noqa: BLE001
            return _err(e)

    def profile(self, graph: dict[str, Any], node_id: str) -> dict[str, Any]:
        """Row count and per-column null/blank/distinct/min/max at a node (full pass over the data)."""
        try:
            g = Graph.from_dict(graph)
            plans = build_plans(g, upto=node_id, cache=self.cache)
            res = profile(plans[node_id])
        except Exception as e:  # noqa: BLE001
            return _err(e)
        res["ok"] = True
        return res

    def run_to(self, graph: dict[str, Any], node_id: str) -> dict[str, Any]:
        """Execute up to a node and cache its result; later previews/schemas start from the cache."""
        try:
            info = self.cache.materialise(Graph.from_dict(graph), node_id)
        except Exception as e:  # noqa: BLE001
            return _err(e)
        info["ok"] = True
        return info

    def cache_status(self, graph: dict[str, Any]) -> dict[str, Any]:
        try:
            return {"ok": True, "cached": self.cache.status(Graph.from_dict(graph)),
                    "bytes": self.cache.size_bytes()}
        except Exception as e:  # noqa: BLE001
            return _err(e)

    def clear_cache(self) -> dict[str, Any]:
        return {"ok": True, "removed": self.cache.clear()}

    # ---- background jobs ------------------------------------------------
    def start_run(self, graph: dict[str, Any], upto: str | None = None) -> dict[str, Any]:
        """Run the workflow (or run-to-here for `upto`) on a worker thread; poll with job_status."""
        try:
            g = Graph.from_dict(graph)
        except Exception as e:  # noqa: BLE001
            return _err(e)
        job_id = uuid.uuid4().hex[:12]
        job: dict[str, Any] = {"id": job_id, "state": "running", "log": [], "error": None, "node_id": None,
                               "started": time.time(), "finished": None, "stop": threading.Event(), "result": None, "surfaced_at": None,
                               "upto": upto}
        self.jobs[job_id] = job

        def on_node(spec, status, detail):
            now = time.time()
            if status == "start":
                job["log"].append({"id": spec.id, "type": spec.type, "name": spec.name, "status": "running",
                                   "started": now, "seconds": None, "detail": "", "warnings": []})
                return
            for entry in reversed(job["log"]):
                if entry["id"] == spec.id:
                    if status == "warning":
                        entry["warnings"].append(detail)
                        break
                    entry["status"] = "done" if status == "done" else "error"
                    entry["seconds"] = round(now - entry["started"], 2)
                    entry["detail"] = detail if status != "done" else ""
                    break

        def work():
            try:
                if upto:
                    on_node(g.node(upto), "start", "")
                    job["result"] = self.cache.materialise(g, upto)
                    on_node(g.node(upto), "done", "")
                else:
                    run(g, on_node=on_node, should_stop=job["stop"].is_set)
                job["state"] = "done"
            except RunCancelled:
                job["state"] = "cancelled"
            except RunError as e:
                job["state"] = "error"; job["error"] = str(e); job["node_id"] = e.node_id
                job["surfaced_at"] = e.surfaced_at
            except Exception as e:  # noqa: BLE001
                job["state"] = "error"; job["error"] = f"{type(e).__name__}: {e}"
                job["trace"] = traceback.format_exc()
            finally:
                job["finished"] = time.time()

        threading.Thread(target=work, name=f"raw2ufs-run-{job_id}", daemon=True).start()
        return {"ok": True, "job_id": job_id}

    def job_status(self, job_id: str) -> dict[str, Any]:
        job = self.jobs.get(job_id)
        if not job:
            return {"ok": False, "error": "unknown job"}
        end = job["finished"] or time.time()
        return {"ok": True, "state": job["state"], "log": job["log"], "error": job["error"],
                "node_id": job["node_id"], "surfaced_at": job["surfaced_at"], "elapsed": round(end - job["started"], 2),
                "result": job["result"], "upto": job["upto"]}

    def cancel_job(self, job_id: str) -> dict[str, Any]:
        job = self.jobs.get(job_id)
        if not job:
            return {"ok": False, "error": "unknown job"}
        job["stop"].set()
        return {"ok": True, "note": "stops before the next tool; a tool already running finishes first"}

    def run(self, graph: dict[str, Any]) -> dict[str, Any]:
        log: list[dict[str, str]] = []

        def on_node(spec, status, detail):
            log.append({"id": spec.id, "type": spec.type, "name": spec.name, "status": status,
                        "detail": detail})

        try:
            run(Graph.from_dict(graph), on_node=on_node)
        except RunError as e:
            return {"ok": False, "log": log, "error": str(e), "node_id": e.node_id, "surfaced_at": e.surfaced_at}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "log": log, "error": f"{type(e).__name__}: {e}",
                    "trace": traceback.format_exc()}
        return {"ok": True, "log": log}

    def script(self, graph: dict[str, Any], source: str = "") -> dict[str, Any]:
        try:
            text = export_script(Graph.from_dict(graph), source=source or None)
        except Exception as e:  # noqa: BLE001
            return _err(e)
        return {"ok": True, "text": text}

    def export(self, graph: dict[str, Any], path: str, source: str = "") -> dict[str, Any]:
        res = self.script(graph, source)
        if not res["ok"]:
            return res
        try:
            Path(path).write_text(res["text"], encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            return _err(e)
        return {"ok": True, "path": str(Path(path).resolve())}


def _cell(v: Any) -> Any:
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, (bytes, bytearray)):
        return f"<{len(v)} bytes>"
    return str(v)
