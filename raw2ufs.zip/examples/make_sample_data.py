"""Generate small, deliberately messy sample inputs for the example workflow.

    python examples/make_sample_data.py

Creates in examples/data/:
    sov_main.xlsx        - schedule of values with two title rows above the header
    sov_extra.csv        - a second schedule, latin-1 encoded, semicolon separated
    occupancy_lookup.csv - raw occupancy text -> OED occupancy code
    zones.parquet        - GeoParquet polygons (three made-up rating zones over Sweden)
"""

from __future__ import annotations

import json
from pathlib import Path

import polars as pl
import shapely

HERE = Path(__file__).parent / "data"
HERE.mkdir(exist_ok=True)

main = pl.DataFrame({
    "Site ref": ["A-001", "A-002", "A-003", "A-004", "A-005", None],
    "Street": ["  Sveavägen 10 ", "Kungsgatan 5", "Storgatan 1\n", "Hamngatan 2", "Vasagatan 8", None],
    "Post code": ["111 57", "11143", "852 30", "41106", "111 20", None],
    "Country": ["SE", "se", "SE", "SE ", "SE", None],
    "Lat": ["59.3387", "59.3345", "62.3908", "57.7072", None, None],
    "Lon": ["18.0592", "18.0632", "17.3069", "11.9668", None, None],
    "Building (kSEK)": ["12 500", "3 200", "800", "45 000", "1 100", None],
    "Contents (kSEK)": ["2 000", "500", None, "9 000", "300", None],
    "BI (kSEK)": ["1 000", None, "100", "5 000", None, None],
    "Deductible": ["1%", "1%", "50 000", "2%", "25 000", None],
    "Occupancy": ["Office", " retail ", "Warehouse", "OFFICE", "Hotel", None],
})

# Excel with two title rows above the header (header is row index 2).
import xlsxwriter  # noqa: E402

wb = xlsxwriter.Workbook(str(HERE / "sov_main.xlsx"))
ws = wb.add_worksheet("SOV")
ws.write(0, 0, "Client X - Schedule of Values")
ws.write(1, 0, "Values in kSEK, as at 2026-01-01")
for j, c in enumerate(main.columns):
    ws.write(2, j, c)
for i, row in enumerate(main.iter_rows()):
    for j, v in enumerate(row):
        if v is not None:
            ws.write(3 + i, j, v)
wb.close()

extra = pl.DataFrame({
    "Site ref": ["B-001", "B-002"],
    "Street": ["Drottninggatan 3", "Östra Hamngatan 7"],
    "Post code": ["11151", "41109"],
    "Country": ["SE", "SE"],
    "Lat": ["59.3300", "57.7060"],
    "Lon": ["18.0650", "11.9700"],
    "Building (kSEK)": ["2 400", "6 700"],
    "Contents (kSEK)": ["400", "1 200"],
    "BI (kSEK)": [None, "900"],
    "Deductible": ["1%", "100 000"],
    "Occupancy": ["Retail", "Café"],
})
(HERE / "sov_extra.csv").write_bytes(extra.write_csv(separator=";").encode("latin-1"))

pl.DataFrame({
    "OccupancyRaw": ["OFFICE", "RETAIL", "WAREHOUSE", "HOTEL", "CAFÉ", "RESIDENTIAL"],
    "OccupancyCode": [1100, 1101, 1150, 1105, 1102, 1050],
}).write_csv(HERE / "occupancy_lookup.csv")

zones = {
    "ZoneName": ["Stockholm", "Gothenburg", "Sundsvall"],
    "ZoneCode": ["SE-01", "SE-02", "SE-03"],
    "geometry": [
        shapely.box(17.5, 59.0, 18.5, 59.7),
        shapely.box(11.5, 57.4, 12.3, 58.0),
        shapely.box(17.0, 62.0, 17.6, 62.6),
    ],
}
df = pl.DataFrame({
    "ZoneName": zones["ZoneName"], "ZoneCode": zones["ZoneCode"],
    "geometry": pl.Series([shapely.to_wkb(g) for g in zones["geometry"]], dtype=pl.Binary),
})
meta = {"version": "1.1.0", "primary_column": "geometry",
        "columns": {"geometry": {"encoding": "WKB", "geometry_types": ["Polygon"], "crs": "EPSG:4326"}}}
df.write_parquet(HERE / "zones.parquet", metadata={"geo": json.dumps(meta)})
print(f"sample data written to {HERE}")
